#pragma once

#include <cstdint>
#include <mutex>
#include <optional>
#include <string>
#include <tuple>

#include "perception_interfaces/msg/FusionOutput.hpp"
#include "robot_control/core/robot_control_configs.hpp"
#include "robot_control/services/service_base.hpp"
#include "segar/segar.h"
#include "tp_master_interfaces/msg/TpFunctionState.hpp"

namespace robot_control {
namespace services {

struct TargetInfo {
    std::tuple<double, double, double> position;
    double confidence;
    std::tuple<double, double> velocity;
    double last_seen;
    std::string user_id;
};

class PerceptionService : public ServiceBase {
   public:
    static constexpr double CONFIDENCE_THRESHOLD = 0.3;

    PerceptionService(bool simulated = false);
    ~PerceptionService() override;

    void init(std::shared_ptr<rti::segar::Node> node);

    bool _doInitialize() override;
    void _doShutdown() override;

    bool startActivationTracking(const std::string& user_id);
    bool stopTracking();
    bool faceAuthenticated() const;

    bool isPerceptionFeedbackFresh(int64_t timeout_ms = core::FollowConfigs::kPerceptionTimeoutMs) const;
    std::optional<TargetInfo> getTargetInfo() const {
        std::lock_guard<std::mutex> lock(_mutex);
        return _target;
    }

   private:
    bool _isPerceptionFeedbackFresh(int64_t timeout_ms) const;
    void _onPerceptionTrackedObjects(const std::shared_ptr<perception_interfaces::msg::FusionOutput>& msg);

    std::shared_ptr<rti::segar::Reader<perception_interfaces::msg::FusionOutput>> _perception_sub;
    std::shared_ptr<rti::segar::Node> _node;

    mutable std::mutex _mutex;
    std::optional<TargetInfo> _target;
    bool _face_authenticated;
    double _last_perception_feedback_time;
};

}  // namespace services
}  // namespace robot_control
