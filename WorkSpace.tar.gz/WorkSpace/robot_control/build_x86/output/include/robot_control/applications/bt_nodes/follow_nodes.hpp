#pragma once

#include <memory>
#include <string>

#include "robot_control/applications/framework/bt_nodes.hpp"
#include "robot_control/core/blackboard.hpp"
#include "robot_control/services/navigation_service.hpp"
#include "robot_control/services/perception_service.hpp"

namespace robot_control {
namespace applications {
namespace bt_nodes {

class InitializeFollowParams : public framework::ActionNode {
   public:
    InitializeFollowParams(const std::string& name, const BT::NodeConfig& config,
                           std::shared_ptr<core::Blackboard> blackboard);
    core::NodeStatus execute() override;
    static BT::PortsList providedPorts() {
        return {};
    }

   private:
    std::string _logger_name = "InitializeFollowParams";
};

class StartFollowTask : public framework::ActionNode {
   public:
    StartFollowTask(const std::string& name, const BT::NodeConfig& config,
                    std::shared_ptr<core::Blackboard> blackboard);
    core::NodeStatus execute() override;
    static BT::PortsList providedPorts() {
        return {};
    }

   private:
    std::string _logger_name = "StartFollowTask";
};

class CheckNavigationStatus : public framework::ConditionNode {
   public:
    CheckNavigationStatus(const std::string& name, const BT::NodeConfig& config,
                          std::shared_ptr<core::Blackboard> blackboard);
    bool check() override;
    static BT::PortsList providedPorts() {
        return {};
    }

   private:
    std::string _logger_name = "CheckNavigationStatus";
};

class CheckStopConditions : public framework::ConditionNode {
   public:
    CheckStopConditions(const std::string& name, const BT::NodeConfig& config,
                        std::shared_ptr<core::Blackboard> blackboard);
    bool check() override;
    static BT::PortsList providedPorts() {
        return {};
    }

   private:
    std::string _logger_name = "CheckStopConditions";
};

class UpdateProgress : public framework::ActionNode {
   public:
    UpdateProgress(const std::string& name, const BT::NodeConfig& config, std::shared_ptr<core::Blackboard> blackboard);
    core::NodeStatus execute() override;
    static BT::PortsList providedPorts() {
        return {};
    }

   private:
    int _tickCount;
    std::string _logger_name = "UpdateProgress";
};

class CleanupFollowTask : public framework::ActionNode {
   public:
    CleanupFollowTask(const std::string& name, const BT::NodeConfig& config,
                      std::shared_ptr<core::Blackboard> blackboard);
    core::NodeStatus execute() override;
    static BT::PortsList providedPorts() {
        return {};
    }

   private:
    std::string _logger_name = "CleanupFollowTask";
};

// --- FSM State Management Nodes ---

class FollowFsmIs : public framework::ConditionNode {
   public:
    FollowFsmIs(const std::string& name, const BT::NodeConfig& config, std::shared_ptr<core::Blackboard> blackboard);
    bool check() override;
    static BT::PortsList providedPorts();
};

class TransitionToFollow : public framework::ActionNode {
   public:
    TransitionToFollow(const std::string& name, const BT::NodeConfig& config,
                       std::shared_ptr<core::Blackboard> blackboard);
    core::NodeStatus execute() override;
    static BT::PortsList providedPorts() {
        return {};
    }
};

class TransitionToLost : public framework::ActionNode {
   public:
    TransitionToLost(const std::string& name, const BT::NodeConfig& config,
                     std::shared_ptr<core::Blackboard> blackboard);
    core::NodeStatus execute() override;
    static BT::PortsList providedPorts() {
        return {};
    }
};

class TransitionToTrapped : public framework::ActionNode {
   public:
    TransitionToTrapped(const std::string& name, const BT::NodeConfig& config,
                        std::shared_ptr<core::Blackboard> blackboard);
    core::NodeStatus execute() override;
    static BT::PortsList providedPorts() {
        return {};
    }
};

class TransitionToIdle : public framework::ActionNode {
   public:
    TransitionToIdle(const std::string& name, const BT::NodeConfig& config,
                     std::shared_ptr<core::Blackboard> blackboard);
    core::NodeStatus execute() override;
    static BT::PortsList providedPorts() {
        return {};
    }
};

class TransitionToActivation : public framework::ActionNode {
   public:
    TransitionToActivation(const std::string& name, const BT::NodeConfig& config,
                           std::shared_ptr<core::Blackboard> blackboard);
    core::NodeStatus execute() override;
    static BT::PortsList providedPorts() {
        return {};
    }
};

class TransitionToFault : public framework::ActionNode {
   public:
    TransitionToFault(const std::string& name, const BT::NodeConfig& config,
                      std::shared_ptr<core::Blackboard> blackboard);
    core::NodeStatus execute() override;
    static BT::PortsList providedPorts() {
        return {};
    }
};

class IdleStateExit : public framework::ActionNode {
   public:
    IdleStateExit(const std::string& name, const BT::NodeConfig& config, std::shared_ptr<core::Blackboard> blackboard);
    core::NodeStatus execute() override;
    static BT::PortsList providedPorts() {
        return {BT::InputPort<std::string>("fail_reason_key")};
    }
};

class PublishFollowEvent : public framework::ActionNode {
   public:
    PublishFollowEvent(const std::string& name, const BT::NodeConfig& config,
                       std::shared_ptr<core::Blackboard> blackboard);
    core::NodeStatus execute() override;
    static BT::PortsList providedPorts();
};

class CheckTargetTimeout : public framework::ConditionNode {
   public:
    CheckTargetTimeout(const std::string& name, const BT::NodeConfig& config,
                       std::shared_ptr<core::Blackboard> blackboard);
    bool check() override;
    static BT::PortsList providedPorts();
};

class CheckIsTrapped : public framework::ConditionNode {
   public:
    CheckIsTrapped(const std::string& name, const BT::NodeConfig& config, std::shared_ptr<core::Blackboard> blackboard);
    bool check() override;
    static BT::PortsList providedPorts() {
        return {};
    }
};

/**
 * @brief DetectFaceAndUserAction is a stateful action node that handles face recognition
 * and user tracking before starting a follow task.
 *
 * It transitions from RUNNING to SUCCESS once a face is authenticated, or to FAILURE
 * if perception is unavailable or fails.
 */
class DetectFaceAndUserAction : public BT::StatefulActionNode {
   public:
    DetectFaceAndUserAction(const std::string& name, const BT::NodeConfig& config,
                            std::shared_ptr<core::Blackboard> blackboard);

    BT::NodeStatus onStart() override;
    BT::NodeStatus onRunning() override;
    void onHalted() override;
    static BT::PortsList providedPorts() {
        return {};
    }

   private:
    std::shared_ptr<core::Blackboard> _blackboard;
    std::string _requested_user;
    std::string _logger_name = "DetectFaceAndUserAction";
};

}  // namespace bt_nodes
}  // namespace applications
}  // namespace robot_control
