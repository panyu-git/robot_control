#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

BUILD_DIR="build_x86"
INSTALL_DIR="${1:-/opt/robot_lab/communications}"
INSTALL_DIR="${INSTALL_DIR%/}"

export COMM_SYSTEM_ROOT="${INSTALL_DIR}"

if [[ "${INSTALL_DIR}" == "/opt/robot_lab/communications" ]]; then
  echo "need sudo to build"
  exec sudo -E "${SCRIPT_DIR}/build.sh" "${BUILD_DIR}" "${INSTALL_DIR}"
else
  echo "not need sudo to build"
  exec "${SCRIPT_DIR}/build.sh" "${BUILD_DIR}" "${INSTALL_DIR}"
fi
