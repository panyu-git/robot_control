# FunctionScheduler Design and Usage

`FunctionScheduler` is a lightweight orchestrator for `Function` runtime lifecycle.
The scheduler now uses **Bundle as the scheduling unit**:

- A bundle can contain one or more functions.
- Functions in the same bundle are ordered and dependent.
- A single function submit is equivalent to a one-item bundle.

## Goals

- Run one function at a time.
- Support bundle-level priority preemption.
- Support dependent execution in a bundle (`A -> B -> C`).
- Keep pause/resume behavior for preempted bundles.
- Persist and restore scheduler state using JSON.

## Core Data Structures

- `running_bundle_`: currently executing bundle and current index.
- `paused_function_stack_`: paused bundles stack (LIFO).
- `waiting_function_queue_`: waiting bundles list, sorted by bundle effective priority.
- `pause_contexts_`: serialized pause context indexed by `function_id`.
- `function_factories_`: factory map used by deserialization.

Bundle model:

- `functions`: ordered list of functions.
- `current_index`: currently active function index in this bundle.
- `effective_priority`: max scheduler priority among all functions in this bundle.

## Scheduling Rules

1. **Submit single function**
   - `submitFunction(fn)` is internally treated as `submitFunctionBundle({fn})`.

2. **Submit bundle**
   - If no running bundle exists, first function in the bundle starts immediately.
   - If bundle priority `>=` running bundle priority, scheduler preempts running bundle:
     - current running function is paused and context saved;
     - current bundle goes to paused stack;
     - new bundle starts.
   - Otherwise bundle enters waiting queue by priority.

3. **Complete current function**
   - If running bundle has next function, scheduler enters next function in the same bundle.
   - If no next function, bundle is finished and scheduler promotes next bundle.

4. **Fail current function**
   - Remaining functions in the same bundle are dropped.
   - Scheduler promotes next bundle.

5. **Promotion policy**
   - Between paused stack top and waiting queue head, higher bundle priority wins.
   - Resumed paused bundle uses `onResume(context)`.
   - Fresh waiting bundle uses `onEnter`.

## Flow Diagram

```mermaid
flowchart TD
    A[submitFunctionBundle] --> B{running bundle exists}
    B -- No --> C[start bundle first function]
    B -- Yes --> D{new bundle priority ge running bundle priority}
    D -- Yes --> E[pause running current function and save context]
    E --> F[push running bundle to paused stack]
    F --> G[start new bundle first function]
    D -- No --> H[insert bundle into waiting queue by effective priority]

    I[completeCurrentFunction] --> J{bundle has next function}
    J -- Yes --> K[start next function in same bundle]
    J -- No --> L[promote next bundle]

    M[failCurrentFunction] --> N[drop remaining functions in current bundle]
    N --> L
```

## Serialization Contract

Primary fields:

- `running_bundle`
- `paused_bundles` (top-first order)
- `waiting_bundles`

Each bundle includes:

- `bundle_id`
- `current_index`
- `effective_priority`
- `functions` (serialized function list)

Backward compatibility:

- Legacy fields `running_function` / `paused_functions` / `waiting_functions` are still dumped and can still be loaded.

## Usage Example

```cpp
framework::FunctionScheduler scheduler;

scheduler.registerFunctionFactory("FOLLOW", follow_factory);
scheduler.registerFunctionFactory("PHOTO", photo_factory);

// Single function submit == one-item bundle
scheduler.submitFunction(follow_fn);

// Dependent bundle: follow success -> photo
scheduler.submitFunctionBundle({follow_fn, photo_fn});

// Report completion/failure from upper layer tick result
scheduler.completeCurrentFunction();
scheduler.failCurrentFunction();
```

## Thread Safety

- All public scheduler APIs guard internal state with `mutex_`.
- Read APIs return snapshots instead of mutable references.

