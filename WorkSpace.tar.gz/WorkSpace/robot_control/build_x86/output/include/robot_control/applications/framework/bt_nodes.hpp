#pragma once

#include <memory>
#include <string>

#include "behaviortree_cpp/behavior_tree.h"
#include "behaviortree_cpp/bt_factory.h"
#include "robot_control/core/blackboard.hpp"
#include "robot_control/core/enums.hpp"

namespace robot_control {
namespace applications {
namespace framework {

// Base class for custom nodes that need access to the robot's blackboard
class ActionNode : public BT::SyncActionNode {
   public:
    ActionNode(const std::string& name, const BT::NodeConfig& config, std::shared_ptr<core::Blackboard> blackboard)
        : BT::SyncActionNode(name, config), _blackboard(blackboard) {}

    virtual ~ActionNode() = default;

    // Derived classes should implement this instead of tick()
    virtual core::NodeStatus execute() = 0;

   protected:
    // Implementation of the tick() method from BT::SyncActionNode
    BT::NodeStatus tick() override {
        auto status = execute();
        switch (status) {
            case core::NodeStatus::SUCCESS:
                return BT::NodeStatus::SUCCESS;
            case core::NodeStatus::FAILURE:
                return BT::NodeStatus::FAILURE;
            case core::NodeStatus::RUNNING:
                return BT::NodeStatus::RUNNING;
            default:
                return BT::NodeStatus::FAILURE;
        }
    }

    std::shared_ptr<core::Blackboard> _blackboard;
};

class StatefulActionNode : public BT::StatefulActionNode {
   public:
    StatefulActionNode(const std::string& name, const BT::NodeConfig& config,
                       std::shared_ptr<core::Blackboard> blackboard)
        : BT::StatefulActionNode(name, config), _blackboard(blackboard) {}

    virtual ~StatefulActionNode() = default;

    virtual core::NodeStatus onStartAction() = 0;
    virtual core::NodeStatus onRunningAction() = 0;
    virtual void onHaltedAction() = 0;

   protected:
    BT::NodeStatus onStart() override {
        auto status = onStartAction();
        return toBTStatus(status);
    }

    BT::NodeStatus onRunning() override {
        auto status = onRunningAction();
        return toBTStatus(status);
    }

    void onHalted() override {
        onHaltedAction();
    }

    BT::NodeStatus toBTStatus(core::NodeStatus status) {
        switch (status) {
            case core::NodeStatus::SUCCESS:
                return BT::NodeStatus::SUCCESS;
            case core::NodeStatus::FAILURE:
                return BT::NodeStatus::FAILURE;
            case core::NodeStatus::RUNNING:
                return BT::NodeStatus::RUNNING;
            default:
                return BT::NodeStatus::FAILURE;
        }
    }

    std::shared_ptr<core::Blackboard> _blackboard;
};

class ConditionNode : public BT::ConditionNode {
   public:
    ConditionNode(const std::string& name, const BT::NodeConfig& config, std::shared_ptr<core::Blackboard> blackboard)
        : BT::ConditionNode(name, config), _blackboard(blackboard) {}

    virtual ~ConditionNode() = default;

    // Derived classes should implement this instead of tick()
    virtual bool check() = 0;

   protected:
    // Implementation of the tick() method from BT::ConditionNode
    BT::NodeStatus tick() override {
        return check() ? BT::NodeStatus::SUCCESS : BT::NodeStatus::FAILURE;
    }

    std::shared_ptr<core::Blackboard> _blackboard;
};

// Simplified nodes for backward compatibility or simple logic
class SuccessNode : public BT::SyncActionNode {
   public:
    SuccessNode(const std::string& name, const BT::NodeConfig& config) : BT::SyncActionNode(name, config) {}
    BT::NodeStatus tick() override {
        return BT::NodeStatus::SUCCESS;
    }
    static BT::PortsList providedPorts() {
        return {};
    }
};

class FailureNode : public BT::SyncActionNode {
   public:
    FailureNode(const std::string& name, const BT::NodeConfig& config) : BT::SyncActionNode(name, config) {}
    BT::NodeStatus tick() override {
        return BT::NodeStatus::FAILURE;
    }
    static BT::PortsList providedPorts() {
        return {};
    }
};

class RunningNode : public BT::ConditionNode {
   public:
    RunningNode(const std::string& name, const BT::NodeConfig& config) : BT::ConditionNode(name, config) {}
    BT::NodeStatus tick() override {
        return BT::NodeStatus::RUNNING;
    }
    static BT::PortsList providedPorts() {
        return {};
    }
};

/**
 * @brief SetRobotBlackboard node sets a value in the robot's custom blackboard.
 * It is specialized to handle our custom Blackboard instead of the BT::Blackboard.
 */
class SetRobotBlackboard : public ActionNode {
   public:
    SetRobotBlackboard(const std::string& name, const BT::NodeConfig& config,
                       std::shared_ptr<core::Blackboard> blackboard);
    core::NodeStatus execute() override;
    static BT::PortsList providedPorts();
};

}  // namespace framework
}  // namespace applications
}  // namespace robot_control
