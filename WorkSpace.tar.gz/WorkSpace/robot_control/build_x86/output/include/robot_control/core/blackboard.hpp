#pragma once

#include <any>
#include <map>
#include <mutex>
#include <shared_mutex>
#include <string>

namespace robot_control {
namespace core {

class Blackboard {
   public:
    // Get custom data
    template <typename T>
    T get(const std::string& key, const T& default_value) const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        auto it = custom_data_.find(key);
        if (it != custom_data_.end()) {
            if (const T* val = std::any_cast<T>(&it->second)) {
                return *val;
            }
        }
        return default_value;
    }

    // Set custom data
    template <typename T>
    void set(const std::string& key, const T& value) {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        custom_data_[key] = value;
    }

    // Delete a key
    bool deleteKey(const std::string& key) {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        return custom_data_.erase(key) > 0;
    }

    // Check if key exists
    bool has(const std::string& key) const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        return custom_data_.find(key) != custom_data_.end();
    }

    // Delete keys by prefix
    void deleteByPrefix(const std::string& prefix) {
        if (prefix.empty()) return;
        std::unique_lock<std::shared_mutex> lock(mutex_);
        auto it = custom_data_.lower_bound(prefix);
        while (it != custom_data_.end() && it->first.compare(0, prefix.length(), prefix) == 0) {
            it = custom_data_.erase(it);
        }
    }

    // Reset blackboard
    void reset() {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        custom_data_.clear();
    }

    // Convert to dictionary (simplified representation)
    std::map<std::string, std::any> toDict() const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        std::map<std::string, std::any> result;

        // Add custom data
        result.insert(custom_data_.begin(), custom_data_.end());
        return result;
    }

   private:
    mutable std::shared_mutex mutex_;
    std::map<std::string, std::any> custom_data_;
};

/**
 * @brief A scoped view of the blackboard to avoid key collisions
 */
class LocalBlackboardView {
   public:
    LocalBlackboardView(Blackboard& parent, const std::string& prefix)
        : parent_(parent), prefix_(prefix.empty() || prefix.back() == '/' ? prefix : prefix + "/") {}

    template <typename T>
    T get(const std::string& key, const T& default_value) const {
        return parent_.get<T>(prefix_ + key, default_value);
    }

    template <typename T>
    void set(const std::string& key, const T& value) {
        parent_.set<T>(prefix_ + key, value);
    }

    bool has(const std::string& key) const {
        return parent_.has(prefix_ + key);
    }

    bool deleteKey(const std::string& key) {
        return parent_.deleteKey(prefix_ + key);
    }

    void deleteByPrefix(const std::string& prefix) {
        parent_.deleteByPrefix(prefix_ + prefix);
    }

    // Get the current prefix
    const std::string& prefix() const {
        return prefix_;
    }

    void setPrefix(const std::string& prefix) {
        prefix_ = prefix.empty() || prefix.back() == '/' ? prefix : prefix + "/";
    }

   private:
    Blackboard& parent_;
    std::string prefix_;
};

}  // namespace core
}  // namespace robot_control
