#include "robot_control/applications/bt_nodes/follow_nodes.hpp"

#include <ctime>

#include "robot_control/core/enums.hpp"
#include "robot_control/core/events.hpp"
#include "robot_control/core/robot_control_configs.hpp"
#include "robot_control/utils/logic_utils.hpp"

namespace robot_control {
namespace applications {
namespace bt_nodes {

// InitializeFollowParams
InitializeFollowParams::InitializeFollowParams(const std::string& name, const BT::NodeConfig& config,
                                               std::shared_ptr<core::Blackboard> blackboard)
    : ActionNode(name, config, blackboard) {}

core::NodeStatus InitializeFollowParams::execute() {
    std::string follow_mode = _blackboard->get<std::string>(core::BlackboardKeys::TASK_FOLLOW_MODE, "human");
    double follow_distance = _blackboard->get<double>(core::BlackboardKeys::TASK_FOLLOW_DISTANCE, 1.0);
    double follow_speed = _blackboard->get<double>(core::BlackboardKeys::TASK_FOLLOW_SPEED, 1.0);

    _blackboard->set("follow_distance", follow_distance);
    _blackboard->set("follow_speed", follow_speed);
    _blackboard->set("follow_mode", follow_mode);

    return core::NodeStatus::SUCCESS;
}

// StartFollowTask
StartFollowTask::StartFollowTask(const std::string& name, const BT::NodeConfig& config,
                                 std::shared_ptr<core::Blackboard> blackboard)
    : ActionNode(name, config, blackboard) {}

core::NodeStatus StartFollowTask::execute() {
    auto user_id = _blackboard->get<std::string>("follow_target_user_id", "");
    std::string follow_mode = _blackboard->get<std::string>(core::BlackboardKeys::TASK_FOLLOW_MODE, "human");
    double follow_distance = _blackboard->get<double>(core::BlackboardKeys::TASK_FOLLOW_DISTANCE, 1.0);
    double follow_speed = _blackboard->get<double>(core::BlackboardKeys::TASK_FOLLOW_SPEED, 1.0);

    LOG_INFO("[" << _logger_name << "] Requesting startFollow via blackboard: user_id=" << user_id
                 << ", mode=" << follow_mode << ", dist=" << follow_distance << ", speed=" << follow_speed);

    // Request start follow via blackboard
    _blackboard->set("navigation_cmd", std::string("start_follow"));
    _blackboard->set("navigation_follow_mode", follow_mode);
    _blackboard->set("navigation_follow_distance", follow_distance);
    _blackboard->set("navigation_follow_speed", follow_speed);
    _blackboard->set("navigation_target_user", user_id);

    // Assume dispatch is successful for the BT node's perspective
    // The actual result will be tracked via nav_status in subsequent ticks
    _blackboard->set("follow_start_time", utils::LogicUtils::GetCurrentTimeSec());

    return core::NodeStatus::SUCCESS;
}

// CheckNavigationStatus
CheckNavigationStatus::CheckNavigationStatus(const std::string& name, const BT::NodeConfig& config,
                                             std::shared_ptr<core::Blackboard> blackboard)
    : ConditionNode(name, config, blackboard) {}

bool CheckNavigationStatus::check() {
    // Read from Blackboard
    auto status_int = _blackboard->get<int>("nav_status", static_cast<int>(core::NavigationStatus::IDLE));
    auto status = static_cast<core::NavigationStatus>(status_int);

    // 只要任务在运行就算成功
    return (status == core::NavigationStatus::RUNNING);
}

// CheckStopConditions
CheckStopConditions::CheckStopConditions(const std::string& name, const BT::NodeConfig& config,
                                         std::shared_ptr<core::Blackboard> blackboard)
    : ConditionNode(name, config, blackboard) {}

bool CheckStopConditions::check() {
    if (_blackboard->get<bool>(core::BlackboardKeys::CMD_STOP_REQUEST, false)) {
        return false;
    }
    return true;
}

// UpdateProgress
UpdateProgress::UpdateProgress(const std::string& name, const BT::NodeConfig& config,
                               std::shared_ptr<core::Blackboard> blackboard)
    : ActionNode(name, config, blackboard), _tickCount(0) {}

core::NodeStatus UpdateProgress::execute() {
    _tickCount++;

    auto start_time = _blackboard->get<double>("follow_start_time", 0.0);
    double duration_sec = utils::LogicUtils::GetCurrentTimeSec() - start_time;

    auto progress = _blackboard->get<std::map<std::string, std::any>>("engine_progress", {});
    progress["follow_ticks"] = _tickCount;
    progress["follow_duration"] = duration_sec;
    _blackboard->set("engine_progress", progress);

    return core::NodeStatus::SUCCESS;
}

// CleanupFollowTask
CleanupFollowTask::CleanupFollowTask(const std::string& name, const BT::NodeConfig& config,
                                     std::shared_ptr<core::Blackboard> blackboard)
    : ActionNode(name, config, blackboard) {}

core::NodeStatus CleanupFollowTask::execute() {
    // Set cleanup request on blackboard.
    // The FollowFunction wrapper will monitor this or handle it on exit.
    _blackboard->set("follow_cleanup_requested", true);
    _blackboard->deleteKey("follow_start_time");
    return core::NodeStatus::SUCCESS;
}

// FollowFsmIs
FollowFsmIs::FollowFsmIs(const std::string& name, const BT::NodeConfig& config,
                         std::shared_ptr<core::Blackboard> blackboard)
    : ConditionNode(name, config, blackboard) {}

bool FollowFsmIs::check() {
    auto phase_str = getInput<std::string>("phase").value();
    auto current_phase = _blackboard->get<core::FollowPhase>("follow_phase", core::FollowPhase::IDLE);

    bool match = false;
    if (phase_str == "idle")
        match = (current_phase == core::FollowPhase::IDLE);
    else if (phase_str == "activation")
        match = (current_phase == core::FollowPhase::ACTIVATION);
    else if (phase_str == "follow")
        match = (current_phase == core::FollowPhase::FOLLOW);
    else if (phase_str == "lost")
        match = (current_phase == core::FollowPhase::LOST);
    else if (phase_str == "trapped")
        match = (current_phase == core::FollowPhase::TRAPPED);
    else if (phase_str == "fault")
        match = (current_phase == core::FollowPhase::FAULT);

    if (!match) {
        LOG_DEBUG_NAMED("FollowFsmIs",
                        "Phase mismatch: expected=" << phase_str << ", current=" << static_cast<int>(current_phase));
    }
    return match;
}

BT::PortsList FollowFsmIs::providedPorts() {
    return {BT::InputPort<std::string>("phase")};
}

// TransitionToFollow
TransitionToFollow::TransitionToFollow(const std::string& name, const BT::NodeConfig& config,
                                       std::shared_ptr<core::Blackboard> blackboard)
    : ActionNode(name, config, blackboard) {}

core::NodeStatus TransitionToFollow::execute() {
    LOG_INFO_NAMED("TransitionToFollow", "Transitioning follow_phase to FOLLOW");
    _blackboard->set("follow_phase", core::FollowPhase::FOLLOW);
    return core::NodeStatus::SUCCESS;
}

// TransitionToLost
TransitionToLost::TransitionToLost(const std::string& name, const BT::NodeConfig& config,
                                   std::shared_ptr<core::Blackboard> blackboard)
    : ActionNode(name, config, blackboard) {}

core::NodeStatus TransitionToLost::execute() {
    _blackboard->set("follow_phase", core::FollowPhase::LOST);
    return core::NodeStatus::SUCCESS;
}

// TransitionToTrapped
TransitionToTrapped::TransitionToTrapped(const std::string& name, const BT::NodeConfig& config,
                                         std::shared_ptr<core::Blackboard> blackboard)
    : ActionNode(name, config, blackboard) {}

core::NodeStatus TransitionToTrapped::execute() {
    _blackboard->set("follow_phase", core::FollowPhase::TRAPPED);
    return core::NodeStatus::SUCCESS;
}

// TransitionToIdle
TransitionToIdle::TransitionToIdle(const std::string& name, const BT::NodeConfig& config,
                                   std::shared_ptr<core::Blackboard> blackboard)
    : ActionNode(name, config, blackboard) {}

core::NodeStatus TransitionToIdle::execute() {
    LOG_INFO_NAMED("TransitionToIdle", "Transitioning follow_phase to IDLE");
    _blackboard->set("follow_phase", core::FollowPhase::IDLE);
    return core::NodeStatus::SUCCESS;
}

// TransitionToActivation
TransitionToActivation::TransitionToActivation(const std::string& name, const BT::NodeConfig& config,
                                               std::shared_ptr<core::Blackboard> blackboard)
    : ActionNode(name, config, blackboard) {}

core::NodeStatus TransitionToActivation::execute() {
    LOG_INFO_NAMED("TransitionToActivation", "Transitioning follow_phase to ACTIVATION");
    _blackboard->set("follow_phase", core::FollowPhase::ACTIVATION);
    return core::NodeStatus::SUCCESS;
}

// TransitionToFault
TransitionToFault::TransitionToFault(const std::string& name, const BT::NodeConfig& config,
                                     std::shared_ptr<core::Blackboard> blackboard)
    : ActionNode(name, config, blackboard) {}

core::NodeStatus TransitionToFault::execute() {
    LOG_INFO_NAMED("TransitionToFault", "Transitioning follow_phase to FAULT");
    _blackboard->set("follow_phase", core::FollowPhase::FAULT);
    return core::NodeStatus::SUCCESS;
}

// IdleStateExit
IdleStateExit::IdleStateExit(const std::string& name, const BT::NodeConfig& config,
                             std::shared_ptr<core::Blackboard> blackboard)
    : ActionNode(name, config, blackboard) {}

core::NodeStatus IdleStateExit::execute() {
    std::string reason_key;
    if (getInput("fail_reason_key", reason_key) && !reason_key.empty()) {
        std::string reason = _blackboard->get<std::string>(reason_key, "");
        if (!reason.empty()) {
            LOG_WARN_NAMED("IdleStateExit", "Exiting with FAILURE, reason found in [" << reason_key << "]: " << reason);
            return core::NodeStatus::FAILURE;
        }
    }

    LOG_INFO_NAMED("IdleStateExit", "Exiting with SUCCESS (no failure reason found)");
    return core::NodeStatus::SUCCESS;
}

// PublishFollowEvent
PublishFollowEvent::PublishFollowEvent(const std::string& name, const BT::NodeConfig& config,
                                       std::shared_ptr<core::Blackboard> blackboard)
    : ActionNode(name, config, blackboard) {}

core::NodeStatus PublishFollowEvent::execute() {
    auto event_type_str = getInput<std::string>("event_type").value();
    auto message = getInput<std::string>("message").value_or("");

    core::EventType type;
    if (event_type_str == "lost_hint") {
        type = core::EventType::FEEDBACK_FOLLOW_LOST;
    } else if (event_type_str == "lost_exit") {
        type = core::EventType::FEEDBACK_FOLLOW_LOST_EXIT;
    } else {
        return core::NodeStatus::FAILURE;
    }

    core::Event event(type, "FollowBT");
    event.data["message"] = message;
    event.data["session_id"] = std::to_string(_blackboard->get<int>("follow_activation_session_id", 0));
    core::EventBus::getInstance().publish(event);

    return core::NodeStatus::SUCCESS;
}

BT::PortsList PublishFollowEvent::providedPorts() {
    return {BT::InputPort<std::string>("event_type"), BT::InputPort<std::string>("message")};
}

// CheckTargetTimeout
CheckTargetTimeout::CheckTargetTimeout(const std::string& name, const BT::NodeConfig& config,
                                       std::shared_ptr<core::Blackboard> blackboard)
    : ConditionNode(name, config, blackboard) {}

bool CheckTargetTimeout::check() {
    double max_sec = getInput<double>("max_sec").value_or(60.0);

    // Improvement B: Read from Blackboard instead of Service
    if (_blackboard->has("target_lost_duration")) {
        double current_timeout = _blackboard->get<double>("target_lost_duration", 0.0);
        return (current_timeout < max_sec);
    }
    return true;
}

BT::PortsList CheckTargetTimeout::providedPorts() {
    return {BT::InputPort<double>("max_sec", 60.0, "Maximum allowed target lost duration in seconds")};
}

// CheckIsTrapped
CheckIsTrapped::CheckIsTrapped(const std::string& name, const BT::NodeConfig& config,
                               std::shared_ptr<core::Blackboard> blackboard)
    : ConditionNode(name, config, blackboard) {}

bool CheckIsTrapped::check() {
    // Basic implementation: check if navigation has failed or if there are specific trapped conditions.
    // For now, return false as a placeholder.
    return false;
}

// DetectFaceAndUserAction
DetectFaceAndUserAction::DetectFaceAndUserAction(const std::string& name, const BT::NodeConfig& config,
                                                 std::shared_ptr<core::Blackboard> blackboard)
    : BT::StatefulActionNode(name, config), _blackboard(std::move(blackboard)) {}

BT::NodeStatus DetectFaceAndUserAction::onStart() {
    _requested_user = _blackboard->get<std::string>("follow_requested_user_id", "");
    if (_requested_user.empty()) {
        _requested_user = "default_user";
        _blackboard->set("follow_requested_user_id", _requested_user);
    }

    LOG_DEBUG("DetectFaceAndUser: onStart, user_id=" << _requested_user);

    // Read status from blackboard instead of direct service call
    auto nav_status = static_cast<core::NavigationStatus>(
        _blackboard->get<int>("nav_status", static_cast<int>(core::NavigationStatus::IDLE)));

    if (nav_status == core::NavigationStatus::IDLE) {
        // Request perception to start tracking via blackboard
        _blackboard->set("perception_cmd", std::string("start_activation_tracking"));
        _blackboard->set("perception_target_user", _requested_user);
    }

    if (_blackboard->get<bool>("face_authenticated", false)) {
        _blackboard->set("follow_target_user_id", _requested_user);
        _blackboard->set("follow_activation_fail_reason", std::string(""));
        LOG_INFO("DetectFaceAndUser: face authenticated on start");
        return BT::NodeStatus::SUCCESS;
    }

    return BT::NodeStatus::RUNNING;
}

BT::NodeStatus DetectFaceAndUserAction::onRunning() {
    if (_blackboard->get<bool>("face_authenticated", false)) {
        _blackboard->set("follow_target_user_id", _requested_user);
        _blackboard->set("follow_activation_fail_reason", std::string(""));
        LOG_INFO("DetectFaceAndUser: face authenticated during running");
        return BT::NodeStatus::SUCCESS;
    }

    auto nav_status = static_cast<core::NavigationStatus>(
        _blackboard->get<int>("nav_status", static_cast<int>(core::NavigationStatus::IDLE)));

    if (nav_status == core::NavigationStatus::FAILED) {
        _blackboard->set("follow_activation_fail_reason", std::string("no_face"));
        // Request navigation stop via blackboard if needed
        _blackboard->set("navigation_cmd", std::string("stop"));
        LOG_WARN("DetectFaceAndUser: navigation status FAILED, retrying activation tracking");
        _blackboard->set("perception_cmd", std::string("start_activation_tracking"));
    }

    return BT::NodeStatus::RUNNING;
}

void DetectFaceAndUserAction::onHalted() {
    LOG_DEBUG("DetectFaceAndUser: onHalted");
}

}  // namespace bt_nodes
}  // namespace applications
}  // namespace robot_control
