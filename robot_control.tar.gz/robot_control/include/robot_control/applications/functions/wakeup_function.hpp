#pragma once

#include <chrono>
#include <functional>
#include <map>
#include <memory>
#include <optional>
#include <rclcpp/rclcpp.hpp>
#include <string>

#include "robot_control/applications/framework/function_base.hpp"
#include "robot_control/applications/interfaces/robot_context.hpp"
#include "robot_control/core/events.hpp"

namespace robot_control {
namespace applications {
namespace functions {

class WakeupFunction : public framework::Function {
   public:
    WakeupFunction(std::shared_ptr<core::Blackboard> blackboard, const interfaces::RobotContext& context);
    virtual ~WakeupFunction() = default;

    core::FunctionType functionType() const override {
        return core::FunctionType::WAKEUP;
    }

    core::FunctionPriority priority() const override {
        return core::FunctionPriority::NORMAL;
    }

    void onEnter(const std::optional<std::map<std::string, std::any>>& context = std::nullopt) override;
    std::optional<std::map<std::string, std::any>> onExit() override;

    core::FunctionStatus preTick() override;
    core::FunctionStatus postTick() override;

    // Wakeup commands
    bool startWakeup(const std::string& target_yaw, const std::string& max_angular_velocity = "0.5",
                     const std::string& timeout = "", const std::string& task_id = "", const std::string& user_id = "");
    bool stopWakeup();
    void resetWakeupState();

    // Status checks
    bool isWakeupComplete() const;
    bool isWakeupFailed() const;
    bool isWakeupTimeout() const;
    double getWakeupElapsedTime() const;

    // Callback for wakeup completion
    using WakeupCallback = std::function<void(bool success, const std::string& message)>;
    void setWakeupCallback(WakeupCallback callback);

   private:
    void _publishInteraction(const std::string& message);
    void _publishFeedback(core::EventType type, const std::string& message = "");
    void _onWakeupComplete(bool success, const std::string& message);
    core::FunctionStatus _checkUserCommands();
    void _handleInternalCommands();

    double _getWakeupElapsedTime() const;

    // Wakeup state and parameters
    mutable std::mutex _mutex;
    const interfaces::RobotContext& _context;
    rclcpp::Node::SharedPtr _node;

    // Wakeup parameters
    std::string _target_yaw;
    std::string _max_angular_velocity;
    std::string _timeout;
    std::string _task_id;
    std::string _user_id;

    // Callback
    WakeupCallback _wakeup_callback;

    std::string _logger_name = "WakeupFunction";
};

}  // namespace functions
}  // namespace applications
}  // namespace robot_control