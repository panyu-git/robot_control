#include "robot_control/services/sensor_data_service.hpp"

#include <chrono>
#include <cstring>

#include "robot_control/common/logging.hpp"

namespace robot_control {
namespace services {

SensorDataService::SensorDataService(bool simulated)
    : ServiceBase("SensorDataService", simulated),
      _subscribe_topic("/mcu/data"),
      _publish_topic("/mcu/command"),
      _cmd_id(0),
      _wheel_raw(0),
      _grip_raw(0),
      _lock_raw(0),
      _motor_raw(0),
      _lock_motor(0),
      _version(0) {}

SensorDataService::~SensorDataService() {
    _doShutdown();
}

void SensorDataService::init(std::shared_ptr<rti::segar::Node> node) {
    _node = node;
    if (_node) {
        _subscription = _node->CreateReader<std_msgs::msg::UInt8MultiArray>(
            _subscribe_topic,
            [this](const std::shared_ptr<std_msgs::msg::UInt8MultiArray>& msg) { topicCallback(msg); });
        _publisher = _node->CreateWriter<std_msgs::msg::UInt8MultiArray>(_publish_topic);
        LOG_INFO("[SENSOR] Reader/Writer initialized for sensor data service");
    }
    initialize();
}

bool SensorDataService::_doInitialize() {
    LOG_INFO("[SENSOR] Initializing sensor data service...");
    return true;
}

void SensorDataService::_doShutdown() {
    _subscription.reset();
    _publisher.reset();
}

void SensorDataService::sendCompleteProtocol([[maybe_unused]] uint16_t report_period,
                                             [[maybe_unused]] const std::array<uint8_t, 6>& wheel_states,
                                             [[maybe_unused]] bool grip_success, [[maybe_unused]] bool lock_success,
                                             [[maybe_unused]] bool unlock_success) {
    std::vector<uint8_t> data(16, 0);
    sendRawData(data);
}

void SensorDataService::sendRawData(const std::vector<uint8_t>& data) {
    publishCommand(data);
}

bool SensorDataService::getLatestSensorData(std::vector<uint8_t>& data) const {
    std::lock_guard<std::mutex> lock(_mutex);
    if (_latest_data.empty()) return false;
    data = _latest_data;
    return true;
}

std::map<std::string, std::string> SensorDataService::getSensorInfo() const {
    std::lock_guard<std::mutex> lock(_mutex);
    std::map<std::string, std::string> info;
    info["version"] = std::to_string(_version);
    return info;
}

void SensorDataService::publishCommand(const std::vector<uint8_t>& data) {
    if (!_publisher) return;
    auto msg = std::make_shared<std_msgs::msg::UInt8MultiArray>();
    msg->data(data);
    _publisher->Write(msg);
}

void SensorDataService::topicCallback(const std::shared_ptr<std_msgs::msg::UInt8MultiArray>& msg) {
    std::lock_guard<std::mutex> lock(_mutex);
    _latest_data = msg->data();
}

}  // namespace services
}  // namespace robot_control
