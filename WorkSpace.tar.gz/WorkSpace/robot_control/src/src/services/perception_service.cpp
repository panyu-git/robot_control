#include "robot_control/services/perception_service.hpp"

#include <chrono>

#include "robot_control/common/logging.hpp"
#include "robot_control/utils/logic_utils.hpp"

namespace robot_control {
namespace services {

PerceptionService::PerceptionService(bool simulated)
    : ServiceBase("PerceptionService", simulated), _face_authenticated(false), _last_perception_feedback_time(0.0) {}

PerceptionService::~PerceptionService() {
    _doShutdown();
}

void PerceptionService::init(std::shared_ptr<rti::segar::Node> node) {
    _node = node;
    if (_node) {
        _perception_sub = _node->CreateReader<perception_interfaces::msg::FusionOutput>(
            "percep_msg/obj_track", [this](const std::shared_ptr<perception_interfaces::msg::FusionOutput>& msg) {
                _onPerceptionTrackedObjects(msg);
            });
        LOG_INFO("[PERCEPTION] Reader initialized for perception service");
    }
    initialize();
}

bool PerceptionService::_doInitialize() {
    LOG_INFO("[PERCEPTION] Initializing perception interfaces...");
    return true;
}

void PerceptionService::_doShutdown() {
    _perception_sub.reset();
}

bool PerceptionService::startActivationTracking(const std::string& user_id) {
    (void)user_id;
    if (_status != ServiceStatus::READY) {
        LOG_ERROR("[PERCEPTION] Service not ready");
        return false;
    }

    {
        std::lock_guard<std::mutex> lock(_mutex);
        _face_authenticated = false;
        _last_perception_feedback_time = 0.0;
    }

    LOG_INFO("[PERCEPTION] Activation tracking started");
    return true;
}

bool PerceptionService::stopTracking() {
    {
        std::lock_guard<std::mutex> lock(_mutex);
        _face_authenticated = false;
        _target = std::nullopt;
    }

    LOG_INFO("[PERCEPTION] Tracking stopped");
    return true;
}

bool PerceptionService::faceAuthenticated() const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _face_authenticated;
}

bool PerceptionService::isPerceptionFeedbackFresh(int64_t timeout_ms) const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _isPerceptionFeedbackFresh(timeout_ms);
}

void PerceptionService::_onPerceptionTrackedObjects(
    const std::shared_ptr<perception_interfaces::msg::FusionOutput>& msg) {
    std::lock_guard<std::mutex> lock(_mutex);
    double now_sec = utils::LogicUtils::GetCurrentTimeSec();
    _last_perception_feedback_time = now_sec;

    bool any_face_ok = false;
    for (const auto& ped : msg->ped_track_list()) {
        // 1. Authentication check: face_id in [1, 100]
        if (ped.is_face_id() && ped.face_id() >= 1 && ped.face_id() <= 100) {
            any_face_ok = true;
            if (!_face_authenticated) {
                LOG_INFO("[PERCEPTION] Face authenticated: face_id=" << static_cast<int>(ped.face_id()));
                _face_authenticated = true;
            }
        }

        // 2. Update target info if it's the main pedestrian
        if (ped.is_main_ped() == 1) {  // IS_MAIN_PED_YES
            TargetInfo target;
            target.position = std::make_tuple(ped.position().x(), ped.position().y(), ped.position().z());
            target.confidence = ped.confi();
            target.velocity = std::make_tuple(ped.velocity().x(), ped.velocity().y());
            target.last_seen = now_sec;
            _target = target;
        }
    }

    // Handle simulation of authentication loss
    if (!any_face_ok && _face_authenticated) {
        bool seen_any_ped = (msg->ped_count() > 0);
        if (seen_any_ped) {
            LOG_INFO("[PERCEPTION] Face authentication lost (stranger or no face)");
            _face_authenticated = false;
        }
    }
}

bool PerceptionService::_isPerceptionFeedbackFresh(int64_t timeout_ms) const {
    return !utils::LogicUtils::IsTimeoutMs(_last_perception_feedback_time, timeout_ms);
}

}  // namespace services
}  // namespace robot_control
