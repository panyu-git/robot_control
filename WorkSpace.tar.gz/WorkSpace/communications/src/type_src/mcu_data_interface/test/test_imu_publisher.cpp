#include "rclcpp/rclcpp.hpp"
#include "mcu_data_interface/msg/top_sun_imu_topic.hpp"

class TestImuPublisher : public rclcpp::Node {
public:
    TestImuPublisher() : Node("test_imu_publisher"), seq_(0) {
        publisher_ = this->create_publisher<mcu_data_interface::msg::TopSunImuTopic>("imu_data", 10);
        timer_ = this->create_wall_timer(
            std::chrono::seconds(1),
            std::bind(&TestImuPublisher::timer_callback, this));
        RCLCPP_INFO(this->get_logger(), "IMU测试发布器启动");
    }

private:
    void timer_callback() {
        auto msg = mcu_data_interface::msg::TopSunImuTopic();
        
        msg.header.stamp = this->now();
        msg.header.frame_id = "imu_frame";
        msg.seq = seq_++;
        
        // 模拟数据
        msg.quat_w = 1.0;
        msg.quat_x = 0.0;
        msg.quat_y = 0.0;
        msg.quat_z = 0.0;
        
        msg.omega_x = 0.1;
        msg.omega_y = 0.0;
        msg.omega_z = 0.0;
        
        msg.acc_x = 0.0;
        msg.acc_y = 0.0;
        msg.acc_z = 9.81;
        
        msg.roll = 0.0;
        msg.pitch = 0.0;
        msg.yaw = 0.0;
        
        publisher_->publish(msg);
        RCLCPP_INFO(this->get_logger(), "发布IMU数据 seq: %lu", msg.seq);
    }
    
    rclcpp::Publisher<mcu_data_interface::msg::TopSunImuTopic>::SharedPtr publisher_;
    rclcpp::TimerBase::SharedPtr timer_;
    uint64_t seq_;
};

int main(int argc, char * argv[]) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<TestImuPublisher>());
    rclcpp::shutdown();
    return 0;
}
