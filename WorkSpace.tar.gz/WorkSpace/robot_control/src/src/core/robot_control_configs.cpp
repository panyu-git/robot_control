#include "robot_control/core/robot_control_configs.hpp"

#include <cstdlib>
#include <filesystem>

namespace robot_control {
namespace core {

std::string BTConfig::xmlPathFollow() {
    return resolveXmlPath(kXmlRelativeFollow);
}

std::string BTConfig::xmlPathWakeup() {
    return resolveXmlPath(kXmlRelativeWakeup);
}

std::string BTConfig::xmlPathMountUp() {
    return resolveXmlPath(kXmlRelativeMountUp);
}

std::string BTConfig::resolveXmlPath(const std::string& relative_path) {
    namespace fs = std::filesystem;

    // 1. Try environment variable
    const char* env_path = std::getenv("ROBOT_CONTROL_CONFIG_DIR");
    if (env_path) {
        auto p = fs::path(env_path) / relative_path;
        if (fs::exists(p)) return fs::absolute(p).string();
    }

    // 2. Try relative to binary (assuming bin/ structure)
    auto exe_path = fs::canonical("/proc/self/exe").parent_path();
    auto p_rel = exe_path.parent_path() / "config" / relative_path;
    if (fs::exists(p_rel)) return fs::absolute(p_rel).string();

    auto p_rel_etc = exe_path.parent_path() / "etc" / relative_path;
    if (fs::exists(p_rel_etc)) return fs::absolute(p_rel_etc).string();

    // 3. Try standard system path
    auto p_sys = fs::path("/opt/robot_lab/robot_control/config") / relative_path;
    if (fs::exists(p_sys)) return fs::absolute(p_sys).string();

    // 4. Try current directory config/
    auto p_cwd = fs::current_path() / "config" / relative_path;
    if (fs::exists(p_cwd)) return fs::absolute(p_cwd).string();

    return relative_path;
}

}  // namespace core
}  // namespace robot_control
