#include "robot_control/services/ros2_interface.hpp"

#include <cmath>
#include <iostream>

namespace robot_control {
namespace services {

// =============================================================================
// Pose2D Implementation
// =============================================================================

PoseStamped Pose2D::toPoseStamped(const std::string& frame_id) const {
    PoseStamped ps;
    ps.header.frame_id = frame_id;
    ps.pose.position.x = x;
    ps.pose.position.y = y;
    ps.pose.position.z = 0.0;

    // Convert theta to quaternion (rotation around Z axis)
    double qz = std::sin(theta / 2.0);
    double qw = std::cos(theta / 2.0);
    ps.pose.orientation.z = qz;
    ps.pose.orientation.w = qw;

    return ps;
}

Pose2D Pose2D::fromPoseStamped(const PoseStamped& pose_stamped) {
    Pose2D p2d;
    p2d.x = pose_stamped.pose.position.x;
    p2d.y = pose_stamped.pose.position.y;

    // Extract yaw from quaternion
    const auto& ori = pose_stamped.pose.orientation;
    p2d.theta = std::atan2(2.0 * (ori.w * ori.z + ori.x * ori.y), 1.0 - 2.0 * (ori.y * ori.y + ori.z * ori.z));

    return p2d;
}

// =============================================================================
// ROS2InterfaceManager Implementation
// =============================================================================

ROS2InterfaceManager::ROS2InterfaceManager(bool /*simulated*/) {}

ROS2InterfaceManager::~ROS2InterfaceManager() {
    shutdown();
}

bool ROS2InterfaceManager::initialize() {
    return true;
}

void ROS2InterfaceManager::shutdown() {}

}  // namespace services
}  // namespace robot_control
