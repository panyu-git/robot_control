#!/bin/bash
# Stop Robot Control System

set -e

echo "Stopping Robot Control System..."

# Find and kill the process
pkill -f "robot_control" || true

echo "System stopped."
