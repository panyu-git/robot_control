# Native aarch64 (e.g. Jetson Orin) build toolchain configuration
# Uses the system default gcc/g++ on the device — not aarch64-linux-gnu-* cross prefixes

set(CMAKE_SYSTEM_NAME Linux)
set(CMAKE_SYSTEM_PROCESSOR aarch64)

# Do not pin compilers; rely on default gcc/g++
