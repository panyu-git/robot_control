#!/bin/bash
# Run robot controller node directly with Python
# 直接用 Python 运行机器人控制节点

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

# Set PYTHONPATH
export PYTHONPATH="$PROJECT_ROOT/src:$PYTHONPATH"

# Configure FastDDS to limit resource usage (helps avoid std::bad_alloc)
if [ -f "$PROJECT_ROOT/config/fastdds.xml" ]; then
    export FASTRTPS_DEFAULT_PROFILES_FILE="$PROJECT_ROOT/config/fastdds.xml"
    echo "Using FastDDS config: $FASTRTPS_DEFAULT_PROFILES_FILE"
fi

echo "Starting robot_controller_node..."
echo "  Project: $PROJECT_ROOT"
echo "  PYTHONPATH: $PYTHONPATH"
echo ""

# Run the node
python3 "$PROJECT_ROOT/src/applications/interfaces/robot_controller_node.py" "$@"
