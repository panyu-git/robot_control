#include "robot_control/applications/framework/function_manager.hpp"

#include <gtest/gtest.h>

#include <filesystem>
#include <memory>
#include <string>

#include "robot_control/applications/framework/execution_engine.hpp"
#include "robot_control/applications/functions/idle_function.hpp"
#include "robot_control/applications/functions/mountup_function.hpp"
#include "robot_control/applications/interfaces/robot_context.hpp"
#include "robot_control/core/events.hpp"
#include "robot_control/core/robot_control_configs.hpp"

#ifndef MOUNTUP_TREE_XML_PATH
#define MOUNTUP_TREE_XML_PATH "etc/bt_trees/mountup_tree.xml"
#endif

namespace robot_control::applications::framework::test {

namespace {

/// Lightweight function for scheduler/manager tests (no ROS services).
class TestSchedFunction : public Function {
   public:
    TestSchedFunction(std::shared_ptr<core::Blackboard> blackboard, core::FunctionType type, int scheduler_priority)
        : Function(std::move(blackboard)), type_(type) {
        setSchedulerPriority(scheduler_priority);
        setFunctionName(std::string(core::toString(type_)));
    }

    core::FunctionType functionType() const override {
        return type_;
    }

    core::FunctionPriority priority() const override {
        return core::FunctionPriority::NORMAL;
    }

    void onEnter(const std::optional<std::map<std::string, std::any>>& /*context*/) override {
        ++enter_count;
        setStatus(core::FunctionStatus::RUNNING);
    }

    std::optional<std::map<std::string, std::any>> onExit() override {
        ++exit_count;
        setStatus(core::FunctionStatus::IDLE);
        return std::nullopt;
    }

    std::optional<std::map<std::string, std::any>> onPause() override {
        ++pause_count;
        setStatus(core::FunctionStatus::PAUSED);
        return std::nullopt;
    }

    void onResume(const std::map<std::string, std::any>& /*context*/) override {
        ++resume_count;
        setStatus(core::FunctionStatus::RUNNING);
    }

    core::FunctionStatus postTick() override {
        return status();
    }

    void postEvent(const core::EventV& /*e*/) override {}

    int enter_count{0};
    int exit_count{0};
    int pause_count{0};
    int resume_count{0};

   private:
    core::FunctionType type_;
};

std::string resolveMountupTreePath() {
    const std::filesystem::path configured(MOUNTUP_TREE_XML_PATH);
    if (std::filesystem::exists(configured)) {
        return configured.string();
    }
    const std::filesystem::path relative("etc/bt_trees/mountup_tree.xml");
    if (std::filesystem::exists(relative)) {
        return std::filesystem::absolute(relative).string();
    }
    return configured.string();
}

/// Tracks shared-engine tick calls; MountUp must not use this path.
class MockExecutionEngine : public IExecutionEngine {
   public:
    int tick_invocations{0};

    bool load(const std::string& /*name*/, const std::string& /*resource_path*/) override {
        running_ = true;
        return true;
    }

    bool preload(const std::string& /*name*/, const std::string& /*resource_path*/) override {
        return true;
    }

    core::NodeStatus tick() override {
        ++tick_invocations;
        return core::NodeStatus::RUNNING;
    }

    void abort() override {}
    void reset() override {}
    void pause() override {}
    void resume() override {}

    core::NodeStatus lastStatus() const override {
        return core::NodeStatus::IDLE;
    }

    bool isRunning() const override {
        return running_;
    }

    bool isPaused() const override {
        return false;
    }

    std::string getLastError() const override {
        return {};
    }

    int getErrorCode() const override {
        return 0;
    }

    void setStatusNamespace(const std::string& /*ns*/) override {}
    void onPostTick() override {}

   private:
    bool running_{true};
};

}  // namespace

class FunctionManagerTest : public ::testing::Test {
   protected:
    void SetUp() override {
        blackboard = std::make_shared<core::Blackboard>();
        event_bus = &core::EventBus::getInstance();
        manager = std::make_unique<FunctionManager>(blackboard, nullptr, event_bus);

        manager->registerFunction(std::make_unique<functions::IdleFunction>(blackboard));
        manager->registerFunction(std::make_unique<TestSchedFunction>(blackboard, core::FunctionType::FOLLOW, 200));
        manager->registerFunction(std::make_unique<TestSchedFunction>(blackboard, core::FunctionType::WAKEUP, 250));
        manager->registerFunction(std::make_unique<TestSchedFunction>(blackboard, core::FunctionType::MOUNT_UP, 200));
    }

    std::shared_ptr<core::Blackboard> blackboard;
    core::EventBus* event_bus{nullptr};
    std::unique_ptr<FunctionManager> manager;
};

TEST_F(FunctionManagerTest, TransitionToIdle_DrainsStackAndRunsIdle) {
    ASSERT_TRUE(manager->transitionTo(core::FunctionType::FOLLOW));
    auto* follow = dynamic_cast<TestSchedFunction*>(manager->getFunction(core::FunctionType::FOLLOW));
    ASSERT_NE(follow, nullptr);
    EXPECT_EQ(follow->enter_count, 1);

    ASSERT_TRUE(manager->transitionTo(core::FunctionType::WAKEUP));
    auto* wakeup = dynamic_cast<TestSchedFunction*>(manager->getFunction(core::FunctionType::WAKEUP));
    ASSERT_NE(wakeup, nullptr);
    EXPECT_EQ(wakeup->enter_count, 1);
    EXPECT_EQ(manager->currentType(), core::FunctionType::WAKEUP);

    ASSERT_TRUE(manager->transitionTo(core::FunctionType::IDLE));
    EXPECT_EQ(manager->currentType(), core::FunctionType::IDLE);
    EXPECT_EQ(wakeup->exit_count, 1);
    EXPECT_EQ(follow->exit_count, 1);
    EXPECT_EQ(follow->pause_count, 1);
    EXPECT_EQ(follow->resume_count, 1);
}

TEST_F(FunctionManagerTest, TransitionToIdle_WhenAlreadyIdle_NoExtraSubmit) {
    ASSERT_TRUE(manager->transitionTo(core::FunctionType::IDLE));
    auto* idle = manager->getFunction(core::FunctionType::IDLE);
    ASSERT_NE(idle, nullptr);
    // Second transition should leave IDLE as current without breaking
    ASSERT_TRUE(manager->transitionTo(core::FunctionType::IDLE));
    EXPECT_EQ(manager->currentType(), core::FunctionType::IDLE);
}

TEST_F(FunctionManagerTest, BlackboardRequest_TriggerAndTransition) {
    // 1. Start in IDLE
    ASSERT_TRUE(manager->transitionTo(core::FunctionType::IDLE));
    EXPECT_EQ(manager->currentType(), core::FunctionType::IDLE);

    // 2. Add wakeup request (Allowed from IDLE)
    blackboard->set(core::BlackboardKeys::CMD_WAKEUP_REQUEST, true);
    manager->tick();
    EXPECT_EQ(manager->currentType(), core::FunctionType::WAKEUP);
    EXPECT_FALSE(blackboard->get<bool>(core::BlackboardKeys::CMD_WAKEUP_REQUEST, false));

    // 3. Add follow request (Blocked by WAKEUP according to validator rules)
    blackboard->set(core::BlackboardKeys::CMD_FOLLOW_REQUEST, true);
    manager->tick();
    // Status remains WAKEUP because FOLLOW is only allowed from IDLE/FOLLOW
    EXPECT_EQ(manager->currentType(), core::FunctionType::WAKEUP);
    EXPECT_FALSE(blackboard->get<bool>(core::BlackboardKeys::CMD_FOLLOW_REQUEST, false));
}

TEST_F(FunctionManagerTest, EmergencyStop_TriggersIdleAndClearsFlag) {
    ASSERT_TRUE(manager->transitionTo(core::FunctionType::FOLLOW));
    EXPECT_EQ(manager->currentType(), core::FunctionType::FOLLOW);

    blackboard->set(core::BlackboardKeys::SENSOR_EMERGENCY_STOP, true);
    manager->tick();

    EXPECT_EQ(manager->currentType(), core::FunctionType::IDLE);
    EXPECT_FALSE(blackboard->get<bool>(core::BlackboardKeys::SENSOR_EMERGENCY_STOP, true));
}

TEST_F(FunctionManagerTest, MountUpFunction_IsRegistered) {
    EXPECT_NE(manager->getFunction(core::FunctionType::MOUNT_UP), nullptr);
}

TEST_F(FunctionManagerTest, TransitionToMountUp_FromIdle_EntersFunction) {
    ASSERT_TRUE(manager->transitionTo(core::FunctionType::IDLE));
    ASSERT_TRUE(manager->transitionTo(core::FunctionType::MOUNT_UP));

    EXPECT_EQ(manager->currentType(), core::FunctionType::MOUNT_UP);
    auto* mountup = dynamic_cast<TestSchedFunction*>(manager->getFunction(core::FunctionType::MOUNT_UP));
    ASSERT_NE(mountup, nullptr);
    EXPECT_EQ(mountup->enter_count, 1);
}

TEST_F(FunctionManagerTest, TransitionToIdle_FromMountUp_ExitsAndDrains) {
    ASSERT_TRUE(manager->transitionTo(core::FunctionType::MOUNT_UP));
    auto* mountup = dynamic_cast<TestSchedFunction*>(manager->getFunction(core::FunctionType::MOUNT_UP));
    ASSERT_NE(mountup, nullptr);
    EXPECT_EQ(mountup->enter_count, 1);

    ASSERT_TRUE(manager->transitionTo(core::FunctionType::IDLE));
    EXPECT_EQ(manager->currentType(), core::FunctionType::IDLE);
    EXPECT_EQ(mountup->exit_count, 1);
}

TEST_F(FunctionManagerTest, TransitionToMountUp_FromFollow_PausesFollow) {
    ASSERT_TRUE(manager->transitionTo(core::FunctionType::FOLLOW));
    auto* follow = dynamic_cast<TestSchedFunction*>(manager->getFunction(core::FunctionType::FOLLOW));
    ASSERT_NE(follow, nullptr);
    EXPECT_EQ(follow->enter_count, 1);

    ASSERT_TRUE(manager->transitionTo(core::FunctionType::MOUNT_UP));
    EXPECT_EQ(manager->currentType(), core::FunctionType::MOUNT_UP);
    // Same scheduler priority: higher/equal bundle preempts by pausing, not exiting.
    EXPECT_EQ(follow->pause_count, 1);
    EXPECT_EQ(follow->exit_count, 0);

    auto* mountup = dynamic_cast<TestSchedFunction*>(manager->getFunction(core::FunctionType::MOUNT_UP));
    ASSERT_NE(mountup, nullptr);
    EXPECT_EQ(mountup->enter_count, 1);
}

TEST_F(FunctionManagerTest, EmergencyStop_FromMountUp_ReturnsIdle) {
    ASSERT_TRUE(manager->transitionTo(core::FunctionType::MOUNT_UP));
    EXPECT_EQ(manager->currentType(), core::FunctionType::MOUNT_UP);

    blackboard->set(core::BlackboardKeys::SENSOR_EMERGENCY_STOP, true);
    manager->tick();

    EXPECT_EQ(manager->currentType(), core::FunctionType::IDLE);
    EXPECT_FALSE(blackboard->get<bool>(core::BlackboardKeys::SENSOR_EMERGENCY_STOP, true));
}

class FunctionManagerMountUpIntegrationTest : public ::testing::Test {
   protected:
    void SetUp() override {
        tree_path_ = resolveMountupTreePath();
        ASSERT_TRUE(std::filesystem::exists(tree_path_)) << "mountup tree not found: " << tree_path_;

        blackboard = std::make_shared<core::Blackboard>();
        event_bus = &core::EventBus::getInstance();
        mock_engine = std::make_unique<MockExecutionEngine>();
        context_ = std::make_unique<interfaces::RobotContext>(nullptr, nullptr);

        manager = std::make_unique<FunctionManager>(blackboard, mock_engine.get(), event_bus);
        manager->registerFunction(std::make_unique<functions::IdleFunction>(blackboard));
        manager->registerFunction(std::make_unique<functions::MountUpFunction>(tree_path_, *context_));
        ASSERT_TRUE(manager->transitionTo(core::FunctionType::IDLE));
    }

    functions::MountUpFunction* mountUpFunction() {
        return dynamic_cast<functions::MountUpFunction*>(manager->getFunction(core::FunctionType::MOUNT_UP));
    }

    std::string tree_path_;
    std::shared_ptr<core::Blackboard> blackboard;
    core::EventBus* event_bus{nullptr};
    std::unique_ptr<MockExecutionEngine> mock_engine;
    std::unique_ptr<interfaces::RobotContext> context_;
    std::unique_ptr<FunctionManager> manager;
};

TEST_F(FunctionManagerMountUpIntegrationTest, TransitionToMountUp_EntersRunning) {
    ASSERT_TRUE(manager->transitionTo(core::FunctionType::MOUNT_UP));
    EXPECT_EQ(manager->currentType(), core::FunctionType::MOUNT_UP);

    auto* mountup = mountUpFunction();
    ASSERT_NE(mountup, nullptr);
    EXPECT_EQ(mountup->status(), core::FunctionStatus::RUNNING);
    EXPECT_FALSE(mountup->is_started());
}

TEST_F(FunctionManagerMountUpIntegrationTest, TickWhileMountUp_SkipsSharedExecutionEngine) {
    ASSERT_TRUE(manager->transitionTo(core::FunctionType::MOUNT_UP));
    auto* mountup = mountUpFunction();
    ASSERT_NE(mountup, nullptr);

    mock_engine->tick_invocations = 0;
    auto status = manager->tick();
    ASSERT_TRUE(status.has_value());
    EXPECT_EQ(mock_engine->tick_invocations, 0);

    mountup->postEvent(core::EvStart{});
    EXPECT_TRUE(mountup->is_started());

    mock_engine->tick_invocations = 0;
    status = manager->tick();
    ASSERT_TRUE(status.has_value());
    EXPECT_EQ(*status, core::FunctionStatus::RUNNING);
    EXPECT_EQ(mock_engine->tick_invocations, 0);
}

TEST_F(FunctionManagerMountUpIntegrationTest, TransitionToIdle_FromMountUp_StopsSession) {
    ASSERT_TRUE(manager->transitionTo(core::FunctionType::MOUNT_UP));
    auto* mountup = mountUpFunction();
    ASSERT_NE(mountup, nullptr);
    mountup->postEvent(core::EvStart{});
    ASSERT_TRUE(mountup->is_started());

    ASSERT_TRUE(manager->transitionTo(core::FunctionType::IDLE));
    EXPECT_EQ(manager->currentType(), core::FunctionType::IDLE);
    EXPECT_FALSE(mountup->is_started());
}

TEST_F(FunctionManagerMountUpIntegrationTest, EmergencyStop_FromMountUp_ReturnsIdle) {
    ASSERT_TRUE(manager->transitionTo(core::FunctionType::MOUNT_UP));
    auto* mountup = mountUpFunction();
    ASSERT_NE(mountup, nullptr);
    mountup->postEvent(core::EvStart{});
    ASSERT_TRUE(mountup->is_started());

    blackboard->set(core::BlackboardKeys::SENSOR_EMERGENCY_STOP, true);
    manager->tick();

    EXPECT_EQ(manager->currentType(), core::FunctionType::IDLE);
    EXPECT_FALSE(blackboard->get<bool>(core::BlackboardKeys::SENSOR_EMERGENCY_STOP, true));
}

}  // namespace robot_control::applications::framework::test
