#pragma once

#include <stdexcept>
#include <string>

namespace robot_control {
namespace core {

enum class FunctionType { IDLE, WAKEUP, FOLLOW, PHOTO, CHARGE, BOARDING };

enum class FunctionPriority { CRITICAL = 1, NORMAL = 2, LOW = 3 };

enum class FunctionStatus { IDLE, INITIALIZING, RUNNING, PAUSED, COMPLETED, FAILED };

enum class NodeStatus { IDLE, SUCCESS, FAILURE, RUNNING, SKIPPED };

enum class PreemptionType { NONE, SOFT, HARD };

enum class NavigationStatus { IDLE, RUNNING, FAILED };

enum class CameraStatus { IDLE, READY, CAPTURING, ERROR };

enum class BatteryStatus { NORMAL, LOW, CRITICAL, CHARGING, FULL };

enum class FollowPhase { IDLE, ACTIVATION, FOLLOW, LOST, TRAPPED, FAULT };

enum class WakeupPhase { IDLE, WAKEUP, FAULT };

// FollowPhase string conversion
inline std::string toString(FollowPhase phase) {
    switch (phase) {
        case FollowPhase::IDLE:
            return "IDLE";
        case FollowPhase::ACTIVATION:
            return "ACTIVATION";
        case FollowPhase::FOLLOW:
            return "FOLLOW";
        case FollowPhase::LOST:
            return "LOST";
        case FollowPhase::TRAPPED:
            return "TRAPPED";
        case FollowPhase::FAULT:
            return "FAULT";
        default:
            return "UNKNOWN";
    }
}

// WakeupPhase string conversion
inline std::string toString(WakeupPhase phase) {
    switch (phase) {
        case WakeupPhase::IDLE:
            return "IDLE";
        case WakeupPhase::WAKEUP:
            return "WAKEUP";
        case WakeupPhase::FAULT:
            return "FAULT";
        default:
            return "UNKNOWN";
    }
}

enum class BoardingStatus {
    IDLE,
    NAVIGATING_TO_PICKUP,
    WAITING_FOR_BOARDING,
    PASSENGER_BOARDING,
    PASSENGER_ONBOARD,
    NAVIGATING_TO_DEST,
    WAITING_FOR_ALIGHTING,
    PASSENGER_ALIGHTING,
    COMPLETED,
    FAILED
};

enum class FollowFailReason {
    NONE,
    NAV_UNAVAILABLE,
    PERCEPTION_UNAVAILABLE,
    FACE_RECOG_TIMEOUT,
    NO_FACE_DETECTED,
    INVALID_USER,
    WITHOUT_USER,
    RETRY_EXHAUSTED,
    BT_LOAD_FAILED,
    LOST_TIMEOUT,
    UNKNOWN
};

// FunctionType string conversion
inline std::string toString(FunctionType type) {
    switch (type) {
        case FunctionType::IDLE:
            return "IDLE";
        case FunctionType::WAKEUP:
            return "WAKEUP";
        case FunctionType::FOLLOW:
            return "FOLLOW";
        case FunctionType::PHOTO:
            return "PHOTO";
        case FunctionType::CHARGE:
            return "CHARGE";
        case FunctionType::BOARDING:
            return "BOARDING";
        default:
            return "UNKNOWN";
    }
}

template <typename T>
T fromString(const std::string& str);

template <>
inline FollowPhase fromString<FollowPhase>(const std::string& str) {
    if (str == "IDLE") return FollowPhase::IDLE;
    if (str == "ACTIVATION") return FollowPhase::ACTIVATION;
    if (str == "FOLLOW") return FollowPhase::FOLLOW;
    if (str == "LOST") return FollowPhase::LOST;
    if (str == "TRAPPED") return FollowPhase::TRAPPED;
    if (str == "FAULT") return FollowPhase::FAULT;
    throw std::invalid_argument("Invalid FollowPhase: " + str);
}

template <>
inline WakeupPhase fromString<WakeupPhase>(const std::string& str) {
    if (str == "IDLE") return WakeupPhase::IDLE;
    if (str == "WAKEUP") return WakeupPhase::WAKEUP;
    if (str == "FAULT") return WakeupPhase::FAULT;
    throw std::invalid_argument("Invalid WakeupPhase: " + str);
}

template <>
inline FunctionType fromString<FunctionType>(const std::string& str) {
    if (str == "IDLE") return FunctionType::IDLE;
    if (str == "FOLLOW") return FunctionType::FOLLOW;
    if (str == "PHOTO") return FunctionType::PHOTO;
    if (str == "CHARGE") return FunctionType::CHARGE;
    if (str == "BOARDING") return FunctionType::BOARDING;
    throw std::invalid_argument("Invalid FunctionType: " + str);
}

// FunctionPriority string conversion
inline std::string toString(FunctionPriority priority) {
    switch (priority) {
        case FunctionPriority::CRITICAL:
            return "CRITICAL";
        case FunctionPriority::NORMAL:
            return "NORMAL";
        case FunctionPriority::LOW:
            return "LOW";
        default:
            return "UNKNOWN";
    }
}

template <>
inline FunctionPriority fromString<FunctionPriority>(const std::string& str) {
    if (str == "CRITICAL") return FunctionPriority::CRITICAL;
    if (str == "NORMAL") return FunctionPriority::NORMAL;
    if (str == "LOW") return FunctionPriority::LOW;
    throw std::invalid_argument("Invalid FunctionPriority: " + str);
}

// FunctionStatus string conversion
inline std::string toString(FunctionStatus status) {
    switch (status) {
        case FunctionStatus::IDLE:
            return "IDLE";
        case FunctionStatus::INITIALIZING:
            return "INITIALIZING";
        case FunctionStatus::RUNNING:
            return "RUNNING";
        case FunctionStatus::PAUSED:
            return "PAUSED";
        case FunctionStatus::COMPLETED:
            return "COMPLETED";
        case FunctionStatus::FAILED:
            return "FAILED";
        default:
            return "UNKNOWN";
    }
}

template <>
inline FunctionStatus fromString<FunctionStatus>(const std::string& str) {
    if (str == "IDLE") return FunctionStatus::IDLE;
    if (str == "INITIALIZING") return FunctionStatus::INITIALIZING;
    if (str == "RUNNING") return FunctionStatus::RUNNING;
    if (str == "PAUSED") return FunctionStatus::PAUSED;
    if (str == "COMPLETED") return FunctionStatus::COMPLETED;
    if (str == "FAILED") return FunctionStatus::FAILED;
    throw std::invalid_argument("Invalid FunctionStatus: " + str);
}

// NodeStatus string conversion
inline std::string toString(NodeStatus status) {
    switch (status) {
        case NodeStatus::IDLE:
            return "IDLE";
        case NodeStatus::SUCCESS:
            return "SUCCESS";
        case NodeStatus::FAILURE:
            return "FAILURE";
        case NodeStatus::RUNNING:
            return "RUNNING";
        case NodeStatus::SKIPPED:
            return "SKIPPED";
        default:
            return "UNKNOWN";
    }
}

template <>
inline NodeStatus fromString<NodeStatus>(const std::string& str) {
    if (str == "IDLE") return NodeStatus::IDLE;
    if (str == "SUCCESS") return NodeStatus::SUCCESS;
    if (str == "FAILURE") return NodeStatus::FAILURE;
    if (str == "RUNNING") return NodeStatus::RUNNING;
    if (str == "SKIPPED") return NodeStatus::SKIPPED;
    throw std::invalid_argument("Invalid NodeStatus: " + str);
}

// PreemptionType string conversion
inline std::string toString(PreemptionType type) {
    switch (type) {
        case PreemptionType::NONE:
            return "NONE";
        case PreemptionType::SOFT:
            return "SOFT";
        case PreemptionType::HARD:
            return "HARD";
        default:
            return "UNKNOWN";
    }
}

template <>
inline PreemptionType fromString<PreemptionType>(const std::string& str) {
    if (str == "NONE") return PreemptionType::NONE;
    if (str == "SOFT") return PreemptionType::SOFT;
    if (str == "HARD") return PreemptionType::HARD;
    throw std::invalid_argument("Invalid PreemptionType: " + str);
}

// NavigationStatus string conversion
inline std::string toString(NavigationStatus status) {
    switch (status) {
        case NavigationStatus::IDLE:
            return "IDLE";
        case NavigationStatus::RUNNING:
            return "RUNNING";
        case NavigationStatus::FAILED:
            return "FAILED";
        default:
            return "UNKNOWN";
    }
}

template <>
inline NavigationStatus fromString<NavigationStatus>(const std::string& str) {
    if (str == "IDLE") return NavigationStatus::IDLE;
    if (str == "RUNNING") return NavigationStatus::RUNNING;
    if (str == "FAILED") return NavigationStatus::FAILED;
    throw std::invalid_argument("Invalid NavigationStatus: " + str);
}

// CameraStatus string conversion
inline std::string toString(CameraStatus status) {
    switch (status) {
        case CameraStatus::IDLE:
            return "IDLE";
        case CameraStatus::READY:
            return "READY";
        case CameraStatus::CAPTURING:
            return "CAPTURING";
        case CameraStatus::ERROR:
            return "ERROR";
        default:
            return "UNKNOWN";
    }
}

template <>
inline CameraStatus fromString<CameraStatus>(const std::string& str) {
    if (str == "IDLE") return CameraStatus::IDLE;
    if (str == "READY") return CameraStatus::READY;
    if (str == "CAPTURING") return CameraStatus::CAPTURING;
    if (str == "ERROR") return CameraStatus::ERROR;
    throw std::invalid_argument("Invalid CameraStatus: " + str);
}

// BatteryStatus string conversion
inline std::string toString(BatteryStatus status) {
    switch (status) {
        case BatteryStatus::NORMAL:
            return "NORMAL";
        case BatteryStatus::LOW:
            return "LOW";
        case BatteryStatus::CRITICAL:
            return "CRITICAL";
        case BatteryStatus::CHARGING:
            return "CHARGING";
        case BatteryStatus::FULL:
            return "FULL";
        default:
            return "UNKNOWN";
    }
}

template <>
inline BatteryStatus fromString<BatteryStatus>(const std::string& str) {
    if (str == "NORMAL") return BatteryStatus::NORMAL;
    if (str == "LOW") return BatteryStatus::LOW;
    if (str == "CRITICAL") return BatteryStatus::CRITICAL;
    if (str == "CHARGING") return BatteryStatus::CHARGING;
    if (str == "FULL") return BatteryStatus::FULL;
    throw std::invalid_argument("Invalid BatteryStatus: " + str);
}

// BoardingStatus string conversion
inline std::string toString(BoardingStatus status) {
    switch (status) {
        case BoardingStatus::IDLE:
            return "IDLE";
        case BoardingStatus::NAVIGATING_TO_PICKUP:
            return "NAVIGATING_TO_PICKUP";
        case BoardingStatus::WAITING_FOR_BOARDING:
            return "WAITING_FOR_BOARDING";
        case BoardingStatus::PASSENGER_BOARDING:
            return "PASSENGER_BOARDING";
        case BoardingStatus::PASSENGER_ONBOARD:
            return "PASSENGER_ONBOARD";
        case BoardingStatus::NAVIGATING_TO_DEST:
            return "NAVIGATING_TO_DEST";
        case BoardingStatus::WAITING_FOR_ALIGHTING:
            return "WAITING_FOR_ALIGHTING";
        case BoardingStatus::PASSENGER_ALIGHTING:
            return "PASSENGER_ALIGHTING";
        case BoardingStatus::COMPLETED:
            return "COMPLETED";
        case BoardingStatus::FAILED:
            return "FAILED";
        default:
            return "UNKNOWN";
    }
}

template <>
inline BoardingStatus fromString<BoardingStatus>(const std::string& str) {
    if (str == "IDLE") return BoardingStatus::IDLE;
    if (str == "NAVIGATING_TO_PICKUP") return BoardingStatus::NAVIGATING_TO_PICKUP;
    if (str == "WAITING_FOR_BOARDING") return BoardingStatus::WAITING_FOR_BOARDING;
    if (str == "PASSENGER_BOARDING") return BoardingStatus::PASSENGER_BOARDING;
    if (str == "PASSENGER_ONBOARD") return BoardingStatus::PASSENGER_ONBOARD;
    if (str == "NAVIGATING_TO_DEST") return BoardingStatus::NAVIGATING_TO_DEST;
    if (str == "WAITING_FOR_ALIGHTING") return BoardingStatus::WAITING_FOR_ALIGHTING;
    if (str == "PASSENGER_ALIGHTING") return BoardingStatus::PASSENGER_ALIGHTING;
    if (str == "COMPLETED") return BoardingStatus::COMPLETED;
    if (str == "FAILED") return BoardingStatus::FAILED;
    throw std::invalid_argument("Invalid BoardingStatus: " + str);
}

}  // namespace core
}  // namespace robot_control
