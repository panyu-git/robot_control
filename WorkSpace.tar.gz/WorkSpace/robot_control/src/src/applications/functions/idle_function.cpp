#include "robot_control/applications/functions/idle_function.hpp"

namespace robot_control {
namespace applications {
namespace functions {

IdleFunction::IdleFunction(std::shared_ptr<core::Blackboard> blackboard) : Function(blackboard) {
    setFunctionName("IdleFunction");
}

core::FunctionType IdleFunction::functionType() const {
    return core::FunctionType::IDLE;
}

core::FunctionPriority IdleFunction::priority() const {
    return core::FunctionPriority::LOW;
}

void IdleFunction::onEnter(const std::optional<std::map<std::string, std::any>>& /*context*/) {
    _status = core::FunctionStatus::RUNNING;
    _blackboard->set("nav_status", static_cast<int>(core::NavigationStatus::IDLE));
}

std::optional<std::map<std::string, std::any>> IdleFunction::onExit() {
    _status = core::FunctionStatus::IDLE;
    return std::nullopt;
}

std::optional<std::map<std::string, std::any>> IdleFunction::onPause() {
    // Do not call onExit() here: base Function::onPause() delegates to onExit() and would clear
    // state while FunctionScheduler has already moved us to PAUSED.
    return std::nullopt;
}

void IdleFunction::onResume(const std::map<std::string, std::any>& context) {
    Function::onResume(context);
    _blackboard->set("nav_status", static_cast<int>(core::NavigationStatus::IDLE));
}

core::FunctionStatus IdleFunction::postTick() {
    return core::FunctionStatus::RUNNING;
}

}  // namespace functions
}  // namespace applications
}  // namespace robot_control
