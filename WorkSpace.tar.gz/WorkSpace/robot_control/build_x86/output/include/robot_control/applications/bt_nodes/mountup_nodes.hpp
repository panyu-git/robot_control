#pragma once

#include <string>

#include "behaviortree_cpp/action_node.h"
#include "behaviortree_cpp/bt_factory.h"

#include "robot_control/applications/bt_nodes/convert_from_string.hpp"
#include "robot_control/applications/interfaces/robot_context.hpp"
#include "robot_control/core/enums.hpp"

namespace robot_control {
namespace applications {
namespace bt_nodes {

class ContactAction : public BT::StatefulActionNode {
   public:
    ContactAction(const std::string& name, const BT::NodeConfig& config, const interfaces::RobotContext* context);

    BT::NodeStatus onStart() override;
    BT::NodeStatus onRunning() override;
    void onHalted() override;

    static BT::PortsList providedPorts() {
        return {BT::InputPort<core::FunctionStatus>("status")};
    }

   private:
    const std::string _logger_name;
    const interfaces::RobotContext* _context;
};

class MountUpAction : public BT::StatefulActionNode {
   public:
    MountUpAction(const std::string& name, const BT::NodeConfig& config);

    BT::NodeStatus onStart() override;
    BT::NodeStatus onRunning() override;
    void onHalted() override;

    static BT::PortsList providedPorts() {
        return {BT::InputPort<core::FunctionStatus>("status"),
                BT::InputPort<core::MainMode>("main_mode"),
                BT::InputPort<core::SubMode>("sub_mode")};
    }

   private:
    const std::string _logger_name;
};


}  // namespace bt_nodes
}  // namespace applications
}  // namespace robot_control
