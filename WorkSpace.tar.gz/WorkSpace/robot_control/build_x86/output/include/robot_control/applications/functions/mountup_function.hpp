#pragma once

#include <atomic>
#include <memory>
#include <mutex>
#include <optional>
#include <string>

#include "robot_control/applications/framework/function_base.hpp"
#include "robot_control/applications/interfaces/robot_context.hpp"
#include "robot_control/core/blackboard.hpp"
#include "robot_control/core/enums.hpp"

namespace robot_control {
namespace applications {
namespace functions {


class MountUpFunction : public framework::Function {
   public:
    MountUpFunction(std::string tree_xml_path, const interfaces::RobotContext& context);
    ~MountUpFunction();

    MountUpFunction(const MountUpFunction&) = delete;
    MountUpFunction& operator=(const MountUpFunction&) = delete;

    core::FunctionType functionType() const override { return core::FunctionType::MOUNT_UP; }
    core::FunctionPriority priority() const override { return core::FunctionPriority::NORMAL; }
    core::PreemptionType preemptionType() const override { return core::PreemptionType::NONE; }

    void onEnter(const std::optional<std::map<std::string, std::any>>& context = std::nullopt) override;
    std::optional<std::map<std::string, std::any>> onExit() override;
    std::optional<std::map<std::string, std::any>> onPause() override;
    void onResume(const std::map<std::string, std::any>& context) override;

    core::FunctionStatus preTick() override;
    core::FunctionStatus postTick() override;

    void postEvent(const core::EventV& e) override {
        std::lock_guard<std::mutex> lock(_mutex);
        if (!_is_inited.load(std::memory_order_acquire)) {
            return;
        }
        std::visit([this](const auto& ev) { process_event(ev); }, e);
    }

    core::FunctionStatus tickOnce();
    void haltTree();

    [[nodiscard]] bool is_started() const noexcept {
        return _is_started.load(std::memory_order_acquire);
    }

    [[nodiscard]] const std::string& bb_user_id() const noexcept {
        return _bb_user_id;
    }

   private:
    void process_event(const core::EvStart& ev);
    void process_event(const core::EvStop& ev);
    void process_event(const core::EvPause& ev);
    void process_event(const core::EvResume& ev);
    void process_event(const core::EvComplete& ev);
    void process_event(const core::EvError& ev);
    void process_event(const core::EvMountUpContactDone& ev);
    void process_event(const core::EvMountUpClimbDone& ev);
    void process_event(const core::EvUserIdChanged& ev);

    struct Impl;
    std::unique_ptr<Impl> _impl;
    std::mutex _mutex;
    std::atomic<bool> _is_inited{false};
    std::atomic<bool> _is_started{false};
    std::string _bb_user_id = "0";
    const interfaces::RobotContext& _context;
};

}  // namespace functions
}  // namespace applications
}  // namespace robot_control
