from common.conan.robotenv import RobotEnvConan
from conan.tools.files import mkdir, copy
import os
import subprocess


class CommunicationsConan(RobotEnvConan):
    name = "communications"
    version = "1.0.0"
    build_type = "cmake"

    def requirements(self):
        self.requires("segar-workspace/2.5.7@topsun/dev")

