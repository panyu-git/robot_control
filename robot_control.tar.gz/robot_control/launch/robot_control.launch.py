"""
Robot Control System Launch File (C++ Version)
机器人控制系统启动文件 (C++ 版本)

Usage:
    ros2 launch robot_control robot_control.launch.py
    ros2 launch robot_control robot_control.launch.py simulated:=true
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, LogInfo
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    # ==========================================================================
    # Declare launch arguments (声明启动参数)
    # ==========================================================================

    simulated_arg = DeclareLaunchArgument(
        'simulated',
        default_value='false',
        description='Whether to run in simulated mode (是否运行在仿真模式)'
    )

    skip_follow_activation_in_simulated_arg = DeclareLaunchArgument(
        'skip_follow_activation_in_simulated',
        default_value='true',
        description='Skip face activation when simulated=true'
    )

    tick_rate_arg = DeclareLaunchArgument(
        'tick_rate',
        default_value='20.0',
        description='Control loop frequency in Hz (控制循环频率)'
    )

    log_level_arg = DeclareLaunchArgument(
        'log_level',
        default_value='info',
        description='Logging level (debug, info, warn, error)'
    )

    start_nav_task_server_arg = DeclareLaunchArgument(
        'start_nav_task_server',
        default_value='true',
        description='Whether to start nav_task_request action server'
    )

    # ==========================================================================
    # Main robot controller node (主控制器节点)
    # In C++ version, all services are integrated into a single node.
    # ==========================================================================

    robot_controller_node = Node(
        package='robot_control',
        executable='robot_control_node',
        name='robot_controller',
        output='both',
        output_format='{line}',
        parameters=[{
            'simulated': LaunchConfiguration('simulated'),
            'skip_follow_activation_in_simulated': LaunchConfiguration('skip_follow_activation_in_simulated'),
            'tick_rate': LaunchConfiguration('tick_rate'),
        }],
        arguments=['--ros-args', '--log-level', LaunchConfiguration('log_level')],
    )

    # ==========================================================================
    # Build launch description (构建启动描述)
    # ==========================================================================

    return LaunchDescription([
        # Launch arguments
        simulated_arg,
        skip_follow_activation_in_simulated_arg,
        tick_rate_arg,
        log_level_arg,
        # Log startup info
        LogInfo(msg='Starting Robot Control System (C++)...'),
        LogInfo(msg=['  Simulated: ', LaunchConfiguration('simulated')]),
        LogInfo(msg=['  Skip Follow Activation In Simulated: ',
                     LaunchConfiguration('skip_follow_activation_in_simulated')]),
        LogInfo(msg=['  Tick Rate: ', LaunchConfiguration('tick_rate'), ' Hz']),

        # Nodes
        robot_controller_node,
    ])
