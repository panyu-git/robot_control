#pragma once

#include <array>
#include <map>
#include <memory>
#include <mutex>
#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/u_int8_multi_array.hpp>
#include <string>
#include <vector>

#include "robot_control/services/service_base.hpp"

namespace robot_control {
namespace services {

class SensorDataService : public ServiceBase {
   public:
    SensorDataService(bool simulated = false);
    virtual ~SensorDataService();

    void init(rclcpp::Node::SharedPtr node);

    bool _doInitialize() override;
    void _doShutdown() override;

    void sendCompleteProtocol(uint16_t report_period, const std::array<uint8_t, 6>& wheel_states, bool grip_success,
                              bool lock_success, bool unlock_success);

    void sendRawData(const std::vector<uint8_t>& data);

    bool getLatestSensorData(std::vector<uint8_t>& data) const;

    std::map<std::string, std::string> getSensorInfo() const;

   private:
    void publishCommand(const std::vector<uint8_t>& data);
    void topicCallback(const std_msgs::msg::UInt8MultiArray::SharedPtr msg);

    mutable std::mutex _mutex;
    rclcpp::Node::SharedPtr _node;
    rclcpp::Subscription<std_msgs::msg::UInt8MultiArray>::SharedPtr _subscription;
    rclcpp::Publisher<std_msgs::msg::UInt8MultiArray>::SharedPtr _publisher;

    std::string _subscribe_topic;
    std::string _publish_topic;
    std::vector<uint8_t> _latest_data;

    uint8_t _cmd_id;
    uint32_t _wheel_raw;
    uint16_t _grip_raw;
    uint8_t _lock_raw;
    uint16_t _motor_raw;
    uint8_t _lock_motor;
    uint8_t _version;
};

}  // namespace services
}  // namespace robot_control
