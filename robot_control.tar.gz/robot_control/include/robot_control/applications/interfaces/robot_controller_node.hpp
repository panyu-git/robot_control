#pragma once

#include <map>
#include <memory>
#include <optional>
#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>
#include <std_srvs/srv/trigger.hpp>
#include <string>

#include "interaction_interfaces/msg/hmi_control2_robot_control_message.hpp"
#include "interaction_interfaces/msg/robot_control_state_message.hpp"
#include "robot_control/applications/interfaces/robot_controller.hpp"
#include "robot_control/core/events.hpp"

namespace robot_control {
namespace applications {
namespace interfaces {

class RobotControllerNode : public rclcpp::Node {
   public:
    using HmiCommandMsg = interaction_interfaces::msg::HmiControl2RobotControlMessage;
    using RobotStateMsg = interaction_interfaces::msg::RobotControlStateMessage;

    RobotControllerNode();
    void init();

    void shutdown();

   private:
    void _handleHmiCommand(const HmiCommandMsg::SharedPtr msg);

    std::map<std::string, std::string> _parseExecuteParam(const std::string& execute_param) const;
    bool _dispatchRobotCommand(uint8_t cmd_type, const std::string& execute_param, std::string& detail_message);

    // Publishers
    void _publishEvent(const std::string& event_type, const std::string& message);
    void _publishEventFromCore(const core::Event& event);
    void _bridgeCoreEventsToRos();
    std::optional<RobotStateMsg> _createFeedbackState(const core::Event& event);

    std::unique_ptr<RobotController> _controller;

    // Callback groups
    rclcpp::CallbackGroup::SharedPtr _timerCallbackGroup;

    // ROS2 Subscribers
    rclcpp::Subscription<HmiCommandMsg>::SharedPtr _hmiCommandSub;

    // ROS2 Publishers
    rclcpp::Publisher<RobotStateMsg>::SharedPtr _robotStatePub;
    rclcpp::Publisher<std_msgs::msg::String>::SharedPtr _eventsPub;

    // State tracking
    bool _ready;
    uint64_t _currentSeq;
    std::string _lastCommandId;
    rclcpp::Time _lastCommandStamp;
    std::string _logger_name;
};

}  // namespace interfaces
}  // namespace applications
}  // namespace robot_control