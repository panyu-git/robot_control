#include "robot_control/applications/functions/mountup_function.hpp"

#include <map>

#include "robot_control/applications/bt_nodes/common_nodes.hpp"
#include "robot_control/applications/bt_nodes/convert_from_string.hpp"
#include "robot_control/applications/bt_nodes/mountup_nodes.hpp"
#include "robot_control/common/logging.hpp"

#include "behaviortree_cpp/bt_factory.h"

namespace robot_control {
namespace applications {
namespace functions {

namespace {

constexpr const char* kLogger = "MountUpFunction";

void register_all_nodes(BT::BehaviorTreeFactory& factory, const interfaces::RobotContext& context) {
    bt_nodes::registerCommonNodes(factory);
    factory.registerNodeType<bt_nodes::ContactAction>("ContactAction", &context);
    factory.registerNodeType<bt_nodes::MountUpAction>("MountUpAction");
}

}  // namespace

struct MountUpFunction::Impl {
    std::string tree_path;
    BT::BehaviorTreeFactory factory;
    BT::Tree tree;
};

void MountUpFunction::process_event(const core::EvStart& /*ev*/) {
    if (_is_started.load(std::memory_order_acquire)) {
        LOG_WARN_NAMED(kLogger, "EvMountUpStart ignored: already started");
        return;
    }
    _impl->tree.haltTree();
    const auto bb = _impl->tree.rootBlackboard();
    bb->set<uint16_t>("error_code", 0);
    bb->set("contact_status", core::FunctionStatus::INITIALIZING);
    bb->set("mountup_sub_status", core::FunctionStatus::INITIALIZING);
    bb->set("bb_user_id", _bb_user_id);
    LOG_INFO_NAMED(kLogger, "EvMountUpStart: bb_user_id=" << _bb_user_id);
    _is_started.store(true, std::memory_order_release);
}

void MountUpFunction::process_event(const core::EvStop& /*ev*/) {
    if (!_is_started.load(std::memory_order_acquire)) {
        return;
    }
    _impl->tree.haltTree();
    _is_started.store(false, std::memory_order_release);
}

void MountUpFunction::process_event(const core::EvPause& /*ev*/) {
    if (!_is_started.load(std::memory_order_acquire)) {
        return;
    }
    // _impl->tree.haltTree();
    LOG_INFO_NAMED(kLogger, "unsupport pause-resume event for mountup function now.");
}

void MountUpFunction::process_event(const core::EvResume& /*ev*/) {
    // process_event(core::EvStart{});
    LOG_INFO_NAMED(kLogger, "unsupport pause-resume event for mountup function now.");
}

void MountUpFunction::process_event(const core::EvComplete& /*ev*/) {
    if (!_is_started.load(std::memory_order_acquire)) {
        return;
    }
    const auto bb = _impl->tree.rootBlackboard();
    _impl->tree.haltTree();
    _is_started.store(false, std::memory_order_release);
}

void MountUpFunction::process_event(const core::EvError& ev) {
    if (!_is_started.load(std::memory_order_acquire)) {
        return;
    }
    const auto bb = _impl->tree.rootBlackboard();
    bb->set("error_code", ev.code);
    bb->set("contact_status", core::FunctionStatus::FAILED);
    bb->set("mountup_sub_status", core::FunctionStatus::FAILED);
    bb->set("mountup_stage", core::MountupStage::FAULT);
}

void MountUpFunction::process_event(const core::EvMountUpContactDone& /*ev*/) {
    if (!_is_started.load(std::memory_order_acquire)) {
        return;
    }
    _impl->tree.rootBlackboard()->set("contact_status", core::FunctionStatus::COMPLETED);
}

void MountUpFunction::process_event(const core::EvMountUpClimbDone& /*ev*/) {
    if (!_is_started.load(std::memory_order_acquire)) {
        return;
    }
    _impl->tree.rootBlackboard()->set("mountup_sub_status", core::FunctionStatus::COMPLETED);
}

void MountUpFunction::process_event(const core::EvUserIdChanged& ev) {
    _bb_user_id = ev.user_id;
    _impl->tree.rootBlackboard()->set("bb_user_id", _bb_user_id);
    LOG_INFO_NAMED(kLogger, "bb_user_id updated: " << _bb_user_id);
}

MountUpFunction::MountUpFunction(std::string tree_xml_path,
                                 const interfaces::RobotContext& context)
    : Function(nullptr), _impl(std::make_unique<Impl>()), _context(context) {
    _impl->tree_path = std::move(tree_xml_path);
    register_all_nodes(_impl->factory, context);
    _impl->factory.registerScriptingEnums<core::EventType>();
    _impl->factory.registerScriptingEnums<core::SubMode>();  // 新增，需要再完善
    _impl->factory.registerScriptingEnums<core::MainMode>();  // 新增，需要再完善
    _impl->tree = _impl->factory.createTreeFromFile(_impl->tree_path, BT::Blackboard::create());
    _is_inited.store(true, std::memory_order_release);
}

MountUpFunction::~MountUpFunction() {
    std::lock_guard<std::mutex> lock(_mutex);
    _is_started.store(false, std::memory_order_release);
    _is_inited.store(false, std::memory_order_release);
}

void MountUpFunction::onEnter(const std::optional<std::map<std::string, std::any>>& context) {
    (void)context;
    setStatus(core::FunctionStatus::RUNNING);
}

std::optional<std::map<std::string, std::any>> MountUpFunction::onExit() {
    postEvent(core::EvStop{});
    haltTree();
    return std::nullopt;
}

std::optional<std::map<std::string, std::any>> MountUpFunction::onPause() {
    return std::nullopt;
}

void MountUpFunction::onResume(const std::map<std::string, std::any>& context) {
    (void)context;
    postEvent(core::EvStart{});
    setStatus(core::FunctionStatus::RUNNING);
}

core::FunctionStatus MountUpFunction::preTick() {
    const auto status = tickOnce();
    setStatus(status);
    return status;
}

core::FunctionStatus MountUpFunction::postTick() {
    return status();
}

core::FunctionStatus MountUpFunction::tickOnce() {
    std::lock_guard<std::mutex> lock(_mutex);
    if (!_is_inited.load(std::memory_order_acquire)) {
        return core::FunctionStatus::IDLE;
    }
    if (!_is_started.load(std::memory_order_acquire)) {
        return core::FunctionStatus::IDLE;
    }
    const BT::NodeStatus status = _impl->tree.tickOnce();
    if (status == BT::NodeStatus::RUNNING || status == BT::NodeStatus::SKIPPED) {
        return core::FunctionStatus::RUNNING;
    }
    if (status == BT::NodeStatus::SUCCESS) {
        return core::FunctionStatus::COMPLETED;
    }
    if (status == BT::NodeStatus::FAILURE) {
        return core::FunctionStatus::FAILED;
    }
    return core::FunctionStatus::IDLE;
}

void MountUpFunction::haltTree() {
    std::lock_guard<std::mutex> lock(_mutex);
    if (!_is_inited.load(std::memory_order_acquire)) {
        return;
    }
    _impl->tree.haltTree();
    _is_started.store(false, std::memory_order_release);
}

}  // namespace functions
}  // namespace applications
}  // namespace robot_control
