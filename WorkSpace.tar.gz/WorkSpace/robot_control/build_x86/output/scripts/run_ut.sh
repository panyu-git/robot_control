#!/bin/bash
# Run unit tests with required shared library paths (segar-workspace, communications, BT).

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
BUILD_DIR="${PROJECT_ROOT}/build_x86"
UT_BIN="${BUILD_DIR}/robot_control_ut"

if [[ ! -x "${UT_BIN}" ]]; then
    echo "Error: ${UT_BIN} not found. Build first: ./scripts/build_x86.sh" >&2
    exit 1
fi

# segar-workspace provides libyaml-cpp, glog, protobuf, etc.
SEGRA_LIB="/opt/robot_lab/segar-workspace/lib"
COMM_LIB="/opt/robot_lab/communications/lib"
BT_LIB="${BUILD_DIR}/3rdparty/BehaviorTree.CPP"

export LD_LIBRARY_PATH="${SEGRA_LIB}:${COMM_LIB}:${BT_LIB}:${BUILD_DIR}:${LD_LIBRARY_PATH:-}"

exec "${UT_BIN}" "$@"
