#!/bin/bash
# Uninstall Robot Control System systemd service

set -e

SERVICE_NAME="robot-control"

echo "Uninstalling Robot Control System service..."

# Stop service if running
sudo systemctl stop ${SERVICE_NAME} 2>/dev/null || true

# Disable service
sudo systemctl disable ${SERVICE_NAME} 2>/dev/null || true

# Remove service file
sudo rm -f /etc/systemd/system/${SERVICE_NAME}.service

# Reload systemd
sudo systemctl daemon-reload

echo "Service uninstalled."
