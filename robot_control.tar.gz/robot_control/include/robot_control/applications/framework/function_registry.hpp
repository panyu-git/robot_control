#pragma once

#include <map>
#include <string>
#include <vector>

#include "robot_control/core/enums.hpp"

namespace robot_control {
namespace applications {
namespace framework {

enum class EngineType {
    BEHAVIOR_TREE,
    STATE_MACHINE,
    NONE
};

struct FunctionDescriptor {
    core::FunctionType type;
    EngineType engine_type;
    std::string resource_name;
    std::string resource_path;
    bool preload = false;
};

class FunctionRegistry {
   public:
    static FunctionRegistry& getInstance() {
        static FunctionRegistry instance;
        return instance;
    }

    void add(const FunctionDescriptor& desc) {
        _descriptors[desc.type] = desc;
    }

    const FunctionDescriptor* get(core::FunctionType type) const {
        auto it = _descriptors.find(type);
        return (it != _descriptors.end()) ? &it->second : nullptr;
    }

    std::vector<FunctionDescriptor> getAllPreload() const {
        std::vector<FunctionDescriptor> result;
        for (const auto& [type, desc] : _descriptors) {
            if (desc.preload) result.push_back(desc);
        }
        return result;
    }

   private:
    FunctionRegistry() = default;
    std::map<core::FunctionType, FunctionDescriptor> _descriptors;
};

}  // namespace framework
}  // namespace applications
}  // namespace robot_control
