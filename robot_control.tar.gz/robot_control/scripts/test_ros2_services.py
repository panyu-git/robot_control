#!/usr/bin/env python3
"""
ROS2 Services Test Script
ROS2 服务测试脚本

Usage:
    ros2 run robot_control test_ros2_services.py
    # or
    python3 scripts/test_ros2_services.py
"""

import rclpy
from rclpy.node import Node
import json
import time

from std_msgs.msg import String
from std_srvs.srv import Trigger
from sensor_msgs.msg import BatteryState


class RobotServiceTester(Node):
    """测试机器人 ROS2 服务的节点"""
    
    def __init__(self):
        super().__init__('robot_service_tester')
        
        # Subscribers - 订阅状态话题
        self._status_sub = self.create_subscription(
            String, '/robot/status_json', self._on_status, 10)
        self._battery_sub = self.create_subscription(
            BatteryState, '/robot/battery', self._on_battery, 10)
        self._state_sub = self.create_subscription(
            String, '/robot/state', self._on_state, 10)
        
        # Publishers - 发送命令
        self._cmd_pub = self.create_publisher(String, '/robot/command', 10)
        self._voice_pub = self.create_publisher(String, '/voice/command', 10)
        
        # Service clients
        self._follow_client = self.create_client(Trigger, '/robot/follow')
        self._stop_client = self.create_client(Trigger, '/robot/stop')
        self._photo_client = self.create_client(Trigger, '/robot/photo')
        self._charge_client = self.create_client(Trigger, '/robot/charge')
        self._status_client = self.create_client(Trigger, '/robot/get_status_srv')
        
        # State
        self._last_status = None
        self._last_battery = None
        self._last_state = None
        
        self.get_logger().info('RobotServiceTester initialized')
        self.get_logger().info('Listening on: /robot/status_json, /robot/battery, /robot/state')
    
    def _on_status(self, msg: String):
        """处理状态消息"""
        try:
            self._last_status = json.loads(msg.data)
            self.get_logger().info(f'Status: {msg.data[:100]}...')
        except Exception as e:
            self.get_logger().error(f'Status parse error: {e}')
    
    def _on_battery(self, msg: BatteryState):
        """处理电池消息"""
        self._last_battery = msg
        self.get_logger().info(
            f'Battery: {msg.percentage*100:.1f}%, voltage={msg.voltage:.2f}V, '
            f'charging={msg.power_supply_status == BatteryState.POWER_SUPPLY_STATUS_CHARGING}'
        )
    
    def _on_state(self, msg: String):
        """处理状态消息"""
        self._last_state = msg.data
        self.get_logger().info(f'State: {msg.data}')
    
    def send_command(self, cmd: str):
        """通过话题发送命令"""
        msg = String()
        msg.data = cmd
        self._cmd_pub.publish(msg)
        self.get_logger().info(f'Sent command: {cmd}')
    
    def send_voice_command(self, text: str):
        """模拟语音命令"""
        msg = String()
        msg.data = text
        self._voice_pub.publish(msg)
        self.get_logger().info(f'Sent voice command: {text}')
    
    def call_follow(self):
        """调用跟随服务"""
        return self._call_service(self._follow_client, 'follow')
    
    def call_stop(self):
        """调用停止服务"""
        return self._call_service(self._stop_client, 'stop')
    
    def call_photo(self):
        """调用拍照服务"""
        return self._call_service(self._photo_client, 'photo')
    
    def call_charge(self):
        """调用充电服务"""
        return self._call_service(self._charge_client, 'charge')
    
    def call_get_status(self):
        """调用获取状态服务"""
        return self._call_service(self._status_client, 'get_status')
    
    def _call_service(self, client, name: str):
        """通用服务调用"""
        if not client.wait_for_service(timeout_sec=2.0):
            self.get_logger().warn(f'Service {name} not available')
            return None
        
        request = Trigger.Request()
        future = client.call_async(request)
        rclpy.spin_until_future_complete(self, future, timeout_sec=5.0)
        
        if future.result() is not None:
            result = future.result()
            self.get_logger().info(f'Service {name}: success={result.success}, message={result.message}')
            return result
        else:
            self.get_logger().error(f'Service {name} call failed')
            return None


def run_interactive_test(tester: RobotServiceTester):
    """交互式测试"""
    print("\n" + "="*60)
    print("Robot Control ROS2 Service Tester")
    print("机器人控制 ROS2 服务测试器")
    print("="*60)
    print("\nCommands (命令):")
    print("  1 / follow    - Start follow mode (开始跟随)")
    print("  2 / stop      - Stop current task (停止)")
    print("  3 / photo     - Take photo (拍照)")
    print("  4 / charge    - Start charging (充电)")
    print("  5 / status    - Get status (获取状态)")
    print("  6 / voice     - Send voice command (发送语音命令)")
    print("  7 / cmd       - Send topic command (发送话题命令)")
    print("  q / quit      - Exit (退出)")
    print("="*60 + "\n")
    
    while rclpy.ok():
        try:
            cmd = input("\nEnter command (输入命令): ").strip().lower()
            
            if cmd in ('q', 'quit', 'exit'):
                print("Exiting...")
                break
            elif cmd in ('1', 'follow'):
                tester.call_follow()
            elif cmd in ('2', 'stop'):
                tester.call_stop()
            elif cmd in ('3', 'photo'):
                tester.call_photo()
            elif cmd in ('4', 'charge'):
                tester.call_charge()
            elif cmd in ('5', 'status'):
                tester.call_get_status()
            elif cmd in ('6', 'voice'):
                text = input("  Voice text (语音文本): ").strip()
                if text:
                    tester.send_voice_command(text)
            elif cmd in ('7', 'cmd'):
                text = input("  Command text (命令文本): ").strip()
                if text:
                    tester.send_command(text)
            else:
                print(f"Unknown command: {cmd}")
            
            # Spin to process callbacks
            rclpy.spin_once(tester, timeout_sec=0.5)
            
        except KeyboardInterrupt:
            print("\nInterrupted")
            break
        except EOFError:
            break


def run_auto_test(tester: RobotServiceTester):
    """自动测试流程"""
    print("\n" + "="*60)
    print("Running automated test sequence...")
    print("运行自动测试序列...")
    print("="*60 + "\n")
    
    # Wait for initial status
    print("[1/6] Waiting for status messages...")
    for _ in range(5):
        rclpy.spin_once(tester, timeout_sec=1.0)
    
    # Test get status service
    print("\n[2/6] Testing get_status service...")
    tester.call_get_status()
    rclpy.spin_once(tester, timeout_sec=1.0)
    
    # Test follow
    print("\n[3/6] Testing follow service...")
    tester.call_follow()
    time.sleep(2)
    for _ in range(3):
        rclpy.spin_once(tester, timeout_sec=1.0)
    
    # Test photo (interrupts follow)
    print("\n[4/6] Testing photo service (should pause follow)...")
    tester.call_photo()
    time.sleep(2)
    for _ in range(3):
        rclpy.spin_once(tester, timeout_sec=1.0)
    
    # Test stop
    print("\n[5/6] Testing stop service...")
    tester.call_stop()
    time.sleep(1)
    for _ in range(2):
        rclpy.spin_once(tester, timeout_sec=1.0)
    
    # Test voice command
    print("\n[6/6] Testing voice command (跟着我)...")
    tester.send_voice_command("跟着我")
    time.sleep(2)
    for _ in range(3):
        rclpy.spin_once(tester, timeout_sec=1.0)
    
    # Final stop
    print("\n[Done] Stopping...")
    tester.call_stop()
    rclpy.spin_once(tester, timeout_sec=1.0)
    
    print("\n" + "="*60)
    print("Automated test completed!")
    print("自动测试完成!")
    print("="*60)


def main(args=None):
    import sys
    
    rclpy.init(args=args)
    tester = RobotServiceTester()
    
    try:
        # Check for auto mode
        if len(sys.argv) > 1 and sys.argv[1] in ('--auto', '-a'):
            run_auto_test(tester)
        else:
            run_interactive_test(tester)
    finally:
        tester.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
