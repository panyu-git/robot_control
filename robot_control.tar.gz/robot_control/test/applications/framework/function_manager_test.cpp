#include "robot_control/applications/framework/function_manager.hpp"

#include <gtest/gtest.h>

#include <memory>

#include "robot_control/applications/functions/idle_function.hpp"
#include "robot_control/core/events.hpp"
#include "robot_control/core/robot_control_configs.hpp"

namespace robot_control::applications::framework::test {

namespace {

/// Lightweight function for scheduler/manager tests (no ROS services).
class TestSchedFunction : public Function {
   public:
    TestSchedFunction(std::shared_ptr<core::Blackboard> blackboard, core::FunctionType type, int scheduler_priority)
        : Function(std::move(blackboard)), type_(type) {
        setSchedulerPriority(scheduler_priority);
        setFunctionName(std::string(core::toString(type_)));
    }

    core::FunctionType functionType() const override {
        return type_;
    }

    core::FunctionPriority priority() const override {
        return core::FunctionPriority::NORMAL;
    }

    void onEnter(const std::optional<std::map<std::string, std::any>>& /*context*/) override {
        ++enter_count;
        setStatus(core::FunctionStatus::RUNNING);
    }

    std::optional<std::map<std::string, std::any>> onExit() override {
        ++exit_count;
        setStatus(core::FunctionStatus::IDLE);
        return std::nullopt;
    }

    std::optional<std::map<std::string, std::any>> onPause() override {
        ++pause_count;
        setStatus(core::FunctionStatus::PAUSED);
        return std::nullopt;
    }

    void onResume(const std::map<std::string, std::any>& /*context*/) override {
        ++resume_count;
        setStatus(core::FunctionStatus::RUNNING);
    }

    core::FunctionStatus postTick() override {
        return status();
    }

    int enter_count{0};
    int exit_count{0};
    int pause_count{0};
    int resume_count{0};

   private:
    core::FunctionType type_;
};

}  // namespace

class FunctionManagerTest : public ::testing::Test {
   protected:
    void SetUp() override {
        blackboard = std::make_shared<core::Blackboard>();
        event_bus = &core::EventBus::getInstance();
        manager = std::make_unique<FunctionManager>(blackboard, nullptr, event_bus);

        manager->registerFunction(std::make_unique<functions::IdleFunction>(blackboard));
        manager->registerFunction(std::make_unique<TestSchedFunction>(blackboard, core::FunctionType::FOLLOW, 200));
        manager->registerFunction(std::make_unique<TestSchedFunction>(blackboard, core::FunctionType::WAKEUP, 250));
    }

    std::shared_ptr<core::Blackboard> blackboard;
    core::EventBus* event_bus{nullptr};
    std::unique_ptr<FunctionManager> manager;
};

TEST_F(FunctionManagerTest, TransitionToIdle_DrainsStackAndRunsIdle) {
    ASSERT_TRUE(manager->transitionTo(core::FunctionType::FOLLOW));
    auto* follow = dynamic_cast<TestSchedFunction*>(manager->getFunction(core::FunctionType::FOLLOW));
    ASSERT_NE(follow, nullptr);
    EXPECT_EQ(follow->enter_count, 1);

    ASSERT_TRUE(manager->transitionTo(core::FunctionType::WAKEUP));
    auto* wakeup = dynamic_cast<TestSchedFunction*>(manager->getFunction(core::FunctionType::WAKEUP));
    ASSERT_NE(wakeup, nullptr);
    EXPECT_EQ(wakeup->enter_count, 1);
    EXPECT_EQ(manager->currentType(), core::FunctionType::WAKEUP);

    ASSERT_TRUE(manager->transitionTo(core::FunctionType::IDLE));
    EXPECT_EQ(manager->currentType(), core::FunctionType::IDLE);
    EXPECT_EQ(wakeup->exit_count, 1);
    EXPECT_EQ(follow->exit_count, 1);
    EXPECT_EQ(follow->pause_count, 1);
    EXPECT_EQ(follow->resume_count, 1);
}

TEST_F(FunctionManagerTest, CanTransitionToIdle_AlwaysTrueWhenRegistered) {
    ASSERT_TRUE(manager->transitionTo(core::FunctionType::FOLLOW));
    EXPECT_TRUE(manager->canTransitionTo(core::FunctionType::IDLE));
}

TEST_F(FunctionManagerTest, TransitionToIdle_WhenAlreadyIdle_NoExtraSubmit) {
    ASSERT_TRUE(manager->transitionTo(core::FunctionType::IDLE));
    auto* idle = manager->getFunction(core::FunctionType::IDLE);
    ASSERT_NE(idle, nullptr);
    // Second transition should leave IDLE as current without breaking
    ASSERT_TRUE(manager->transitionTo(core::FunctionType::IDLE));
    EXPECT_EQ(manager->currentType(), core::FunctionType::IDLE);
}

TEST_F(FunctionManagerTest, BlackboardRequest_TriggerAndTransition) {
    // 1. Start in IDLE
    ASSERT_TRUE(manager->transitionTo(core::FunctionType::IDLE));
    EXPECT_EQ(manager->currentType(), core::FunctionType::IDLE);

    // 2. Add wakeup request (Allowed from IDLE)
    blackboard->set(core::BlackboardKeys::CMD_WAKEUP_REQUEST, true);
    manager->tick();
    EXPECT_EQ(manager->currentType(), core::FunctionType::WAKEUP);
    EXPECT_FALSE(blackboard->get<bool>(core::BlackboardKeys::CMD_WAKEUP_REQUEST, false));

    // 3. Add follow request (Blocked by WAKEUP according to validator rules)
    blackboard->set(core::BlackboardKeys::CMD_FOLLOW_REQUEST, true);
    manager->tick();
    // Status remains WAKEUP because FOLLOW is only allowed from IDLE/FOLLOW
    EXPECT_EQ(manager->currentType(), core::FunctionType::WAKEUP);
    EXPECT_FALSE(blackboard->get<bool>(core::BlackboardKeys::CMD_FOLLOW_REQUEST, false));
}

TEST_F(FunctionManagerTest, EmergencyStop_TriggersIdleAndClearsFlag) {
    ASSERT_TRUE(manager->transitionTo(core::FunctionType::FOLLOW));
    EXPECT_EQ(manager->currentType(), core::FunctionType::FOLLOW);

    blackboard->set(core::BlackboardKeys::SENSOR_EMERGENCY_STOP, true);
    manager->tick();

    EXPECT_EQ(manager->currentType(), core::FunctionType::IDLE);
    EXPECT_FALSE(blackboard->get<bool>(core::BlackboardKeys::SENSOR_EMERGENCY_STOP, true));
}

}  // namespace robot_control::applications::framework::test
