#pragma once

#include <array>
#include <string>

namespace robot_control {
namespace core {

/**
 * @brief BlackboardKeys centralizes all blackboard key names to avoid magic strings.
 */
namespace BlackboardKeys {

// System commands
inline const char* const CMD_FOLLOW_REQUEST = "cmd_follow_request";
inline const char* const CMD_WAKEUP_REQUEST = "cmd_wakeup_request";
inline const char* const CMD_PHOTO_REQUEST = "cmd_photo_request";
inline const char* const CMD_CHARGE_REQUEST = "cmd_charge_request";
inline const char* const CMD_BOARDING_REQUEST = "cmd_boarding_request";
inline const char* const CMD_STOP_REQUEST = "cmd_stop_request";
inline const char* const CMD_FOLLOW_SPEED_UP = "cmd_follow_speed_up";
inline const char* const CMD_FOLLOW_SPEED_DOWN = "cmd_follow_speed_down";
inline const char* const CMD_FOLLOW_DISTANCE_NEAR = "cmd_follow_distance_near";
inline const char* const CMD_FOLLOW_DISTANCE_FAR = "cmd_follow_distance_far";
inline const char* const CMD_FOLLOW_LOCATION_REQUEST = "cmd_follow_location_request";

// Sensor data
inline const char* const SENSOR_EMERGENCY_STOP = "sensor_emergency_stop";

// Follow related
inline const char* const FOLLOW_ACTIVATION_SESSION_ID = "follow_activation_session_id";
inline const char* const FOLLOW_HEARTBEAT_INTERVAL_MS = "follow_heartbeat_interval_ms";

// Follow Request Params
inline const char* const FOLLOW_REQUEST_PREFIX = "follow_request_";
inline const char* const FOLLOW_REQUEST_USER_ID = "follow_request_user_id";
inline const char* const FOLLOW_REQUEST_TASK = "follow_request_task";
inline const char* const FOLLOW_REQUEST_REMOTE_POSE = "follow_request_remote_pose";

// Follow Task Settings
inline const char* const TASK_FOLLOW_DISTANCE = "task_follow_distance";
inline const char* const TASK_FOLLOW_SPEED = "task_follow_speed";
inline const char* const TASK_FOLLOW_MODE = "task_follow_mode";

// Wakeup related
inline const char* const LAST_WAKEUP_PREFIX = "last_wakeup_";
inline const char* const LAST_WAKEUP_TARGET_YAW = "last_wakeup_target_yaw";
inline const char* const LAST_WAKEUP_WAKEUP_ANGLE = "last_wakeup_wakeup_angle";
inline const char* const LAST_WAKEUP_MAX_ANGULAR_VELOCITY = "last_wakeup_max_angular_velocity";
inline const char* const LAST_WAKEUP_TIMEOUT = "last_wakeup_timeout";
inline const char* const LAST_WAKEUP_TASK_ID = "last_wakeup_task_id";
inline const char* const LAST_WAKEUP_USER_ID = "last_wakeup_user_id";

// FSM state tracking
inline const char* const FSM_CURRENT_STATE = "fsm_current_state";
inline const char* const FSM_PREVIOUS_STATE = "fsm_previous_state";
inline const char* const FSM_STATE_START_TIME = "fsm_state_start_time";
inline const char* const FSM_TRANSITION_COUNT = "fsm_transition_count";

// Blackboard BT Function State
inline const char* const BT_PUB_FUNCTION_STATE = "bbd_bt_function_state";
}  // namespace BlackboardKeys

/**
 * @brief BTConfig centralizes BehaviorTree names and XML file paths.
 */
struct BTConfig {
    // Tree Names (Blackboard/TaskManager keys)
    static constexpr const char* kTreeNameFollow = "BT_FOLLOW";
    static constexpr const char* kTreeNameWakeup = "BT_WAKEUP";
    static constexpr const char* kTreeNameMountUp = "BT_MOUNT_UP";

    // XML relative paths under package share directory: share/robot_control/
    static constexpr const char* kXmlRelativeFollow = "bt_trees/follow_tree.xml";
    static constexpr const char* kXmlRelativeWakeup = "bt_trees/wakeup_tree.xml";
    static constexpr const char* kXmlRelativeMountUp = "bt_trees/mountup_tree.xml";

    static std::string xmlPathFollow();
    static std::string xmlPathWakeup();
    static std::string xmlPathMountUp();

   private:
    static std::string resolveXmlPath(const std::string& relative_path);
};

/**
 * @brief Follow-related constants and configuration values.
 * Centralizing these values ensures consistency across the application.
 */
struct FollowConfigs {
    static constexpr int kPerceptionTimeoutMs = 15000;
    static constexpr int kSystemWatchdogTimeoutMs = 5000;
    static constexpr int kHealthGracePeriodMs = 5000;
    static constexpr int kHeartbeatIntervalMs = 3000;

    // Follow Gears
    static constexpr std::array<double, 3> kSpeedLevels{0.6, 1.0, 1.5};
    static constexpr std::array<double, 3> kDistanceLevels{0.5, 1.0, 2.0};
    static constexpr int kDefaultLevelIndex = 1;
};

}  // namespace core
}  // namespace robot_control
