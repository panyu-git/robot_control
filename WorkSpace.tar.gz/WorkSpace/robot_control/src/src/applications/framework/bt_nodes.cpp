#include "robot_control/applications/framework/bt_nodes.hpp"

namespace robot_control {
namespace applications {
namespace framework {

SetRobotBlackboard::SetRobotBlackboard(const std::string& name, const BT::NodeConfig& config,
                                       std::shared_ptr<core::Blackboard> blackboard)
    : ActionNode(name, config, blackboard) {}

core::NodeStatus SetRobotBlackboard::execute() {
    std::string key;
    std::string value;
    if (!getInput("output_key", key) || !getInput("value", value)) {
        return core::NodeStatus::FAILURE;
    }

    // Special logic for follow_activation_fail_reason: only set if current value is empty.
    // This prevents overwriting a more specific error already set by a node.
    if (key == "follow_activation_fail_reason") {
        std::string current = _blackboard->get<std::string>(key, "");
        if (current.empty()) {
            _blackboard->set(key, value);
        }
    } else {
        _blackboard->set(key, value);
    }

    return core::NodeStatus::SUCCESS;
}

BT::PortsList SetRobotBlackboard::providedPorts() {
    return {BT::InputPort<std::string>("output_key"), BT::InputPort<std::string>("value")};
}

}  // namespace framework
}  // namespace applications
}  // namespace robot_control
