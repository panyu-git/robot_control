#!/usr/bin/env bash
# Usage: scripts/build.sh <build_dir> <install_dir>

set -euo pipefail

if [[ $# -ne 2 ]]; then
  echo "Usage: $0 <build_dir> <install_dir>" >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
SRC_DIR="${PROJECT_ROOT}/src"

BUILD_DIR="$1"
INSTALL_DIR="$2"
if [[ "${BUILD_DIR}" != /* ]]; then
  BUILD_DIR="${PROJECT_ROOT}/${BUILD_DIR}"
fi
if [[ "${INSTALL_DIR}" != /* ]]; then
  INSTALL_DIR="${PROJECT_ROOT}/${INSTALL_DIR}"
fi

mkdir -p "${BUILD_DIR}" "${INSTALL_DIR}"
cd "${BUILD_DIR}"

CMAKE_ARGS=("${SRC_DIR}" -DCMAKE_INSTALL_PREFIX="${INSTALL_DIR}")
if [[ -n "${CMAKE_TOOLCHAIN_FILE:-}" ]]; then
  CMAKE_ARGS+=(-DCMAKE_TOOLCHAIN_FILE="${CMAKE_TOOLCHAIN_FILE}")
fi

cmake "${CMAKE_ARGS[@]}"
cmake --build . -- -j"$(nproc)"
cmake --install .

echo "Done. Install prefix: ${INSTALL_DIR}"
