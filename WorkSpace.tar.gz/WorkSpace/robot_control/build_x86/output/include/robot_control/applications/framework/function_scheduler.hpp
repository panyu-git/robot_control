#pragma once

#include <any>
#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <nlohmann/json.hpp>
#include <optional>
#include <stack>
#include <string>
#include <unordered_map>
#include <vector>

#include "robot_control/applications/framework/function_base.hpp"
#include "robot_control/core/enums.hpp"

namespace robot_control {
namespace applications {
namespace framework {

/**
 * @brief Result of a function transition validation.
 */
struct TransitionValidationResult {
    bool allowed{true};
    std::string reject_message;
};

/**
 * @brief Result of a batch submission.
 */
struct SubmissionResult {
    bool success{false};
    core::FunctionType winner_type{core::FunctionType::IDLE};
    TransitionValidationResult validation{true, ""};
};

/**
 * @brief Generic task orchestrator for quadruped robot functions.
 *
 * FunctionScheduler only handles lifecycle and scheduling mechanics,
 * and does not own business logic.
 */
class FunctionScheduler {
   public:
    /**
     * @brief JSON alias used by scheduler serialization APIs.
     */
    using json = nlohmann::json;
    /**
     * @brief Factory signature for restoring Function from serialized JSON.
     */
    using FunctionFactory = std::function<std::shared_ptr<Function>(const json&)>;
    /**
     * @brief Validation function signature for transition checking.
     */
    using ValidationFn =
        std::function<TransitionValidationResult(core::FunctionType target, core::FunctionType current_function)>;

    /**
     * @brief Construct a scheduler instance.
     */
    FunctionScheduler() = default;

    /**
     * @brief Register function construction callback used during deserialization.
     *
     * @param function_name Name key found in serialized payload.
     * @param factory Factory callback to create a function instance from JSON.
     */
    void registerFunctionFactory(const std::string& function_name, FunctionFactory factory);

    /**
     * @brief Register transition validation callback.
     */
    void registerValidation(core::FunctionType target, ValidationFn validator);

    /**
     * @brief Validate if transition to target is allowed.
     */
    TransitionValidationResult validate(core::FunctionType target, core::FunctionType current_function);

    /**
     * @brief Submit one function into scheduler.
     *
     * A single function is treated as a one-item bundle.
     *
     * @param function Function instance to submit.
     * @return true if submit succeeds; otherwise false.
     */
    bool submitFunction(const std::shared_ptr<Function>& function);
    /**
     * @brief Submit a dependent function bundle.
     *
     * Functions in one bundle execute in order. The next function starts only after
     * the current function is completed successfully.
     *
     * @param functions Ordered function sequence.
     * @return true if submit succeeds; otherwise false.
     */
    bool submitFunctionBundle(const std::vector<std::shared_ptr<Function>>& functions);

    /**
     * @brief Submit a list of candidates and let scheduler pick the best valid one.
     *
     * This performs dynamic arbitration:
     * 1. Filters candidates by registerValidation rules.
     * 2. Picks the one with the highest schedulerPriority().
     * 3. Submits the winner for preemption or queueing.
     *
     * @param candidates List of function candidates.
     * @return Result containing winner information and validation status.
     */
    SubmissionResult submitBestOf(const std::vector<std::shared_ptr<Function>>& candidates);

    /**
     * @brief Complete the current running function.
     *
     * If current bundle has next function, scheduler enters next function in the same bundle.
     * Otherwise, scheduler promotes the next bundle candidate.
     *
     * @return true if scheduler has a promoted/continued running function; otherwise false.
     */
    bool stopCurrentFunction();
    /**
     * @brief Alias of stopCurrentFunction().
     *
     * @return true if scheduler has a promoted/continued running function; otherwise false.
     */
    bool completeCurrentFunction() {
        return stopCurrentFunction();
    }
    /**
     * @brief Mark current function as failed and drop remaining functions in its bundle.
     *
     * @return true if scheduler promotes a next running function; otherwise false.
     */
    bool failCurrentFunction();
    /**
     * @brief Drain running/paused/waiting functions until target type is running or scheduler is empty.
     *
     * This repeatedly stops the current running function and lets scheduler promotion happen,
     * mainly used by upper layers to converge to a baseline state (for example IDLE).
     *
     * @param target_type Desired running function type.
     * @return false only when scheduler enters an inconsistent state during stop/promotion.
     */
    bool drainUntilOrEmpty(core::FunctionType target_type);

    /**
     * @brief Serialize scheduler state (running/paused/waiting) to JSON string.
     *
     * @return Serialized JSON string. Returns "{}" if serialization fails.
     */
    std::string dumpToJsonString() const;
    /**
     * @brief Restore scheduler state from JSON string.
     *
     * @param json_str Serialized scheduler snapshot.
     * @return true when parsing and reconstruction both succeed.
     */
    bool loadFromJsonString(const std::string& json_str);

    /**
     * @brief Get the currently running function snapshot.
     *
     * @return Running function, or nullptr if scheduler is idle.
     */
    std::shared_ptr<Function> currentFunction() const;
    /**
     * @brief Get paused stack size.
     *
     * @return Number of paused functions currently stored in paused stack.
     */
    std::size_t pausedFunctionSize() const;
    /**
     * @brief Get waiting queue size.
     *
     * @return Number of waiting functions currently queued by priority.
     */
    std::size_t waitingFunctionSize() const;
    /**
     * @brief Get paused function names from stack top to bottom.
     *
     * @return Snapshot of paused function names in top-first order.
     */
    std::vector<std::string> pausedFunctionNamesTopFirst() const;
    /**
     * @brief Get waiting function names in queue order.
     *
     * @return Snapshot of waiting function names in current promotion order.
     */
    std::vector<std::string> waitingFunctionNames() const;
    /**
     * @brief Get paused bundle names from stack top to bottom.
     *
     * @return Snapshot of paused bundle names in top-first order.
     */
    std::vector<std::string> pausedBundleNamesTopFirst() const;
    /**
     * @brief Get waiting bundle names in queue order.
     *
     * @return Snapshot of waiting bundle names in current promotion order.
     */
    std::vector<std::string> waitingBundleNames() const;

    /**
     * @brief Clear all scheduler runtime state.
     *
     * Running function, paused stack, waiting queue, and pause contexts are reset.
     */
    void clear();

   private:
    /**
     * @brief Runtime scheduling bundle metadata.
     */
    struct FunctionBundle {
        /**
         * @brief Stable runtime bundle identifier.
         */
        std::string bundle_id;
        /**
         * @brief Ordered functions in this bundle.
         */
        std::vector<std::shared_ptr<Function>> functions;
        /**
         * @brief Current running function index in functions.
         */
        std::size_t current_index{0};
        /**
         * @brief Effective bundle priority (max priority of all functions).
         */
        int effective_priority{0};

        /**
         * @brief Get current function by current_index.
         *
         * @return Current function or nullptr if invalid.
         */
        std::shared_ptr<Function> currentFunction() const {
            if (functions.empty() || current_index >= functions.size()) {
                return nullptr;
            }
            return functions[current_index];
        }
        /**
         * @brief Check whether bundle has next function.
         *
         * @return true if current_index + 1 is valid.
         */
        bool hasNext() const {
            return current_index + 1 < functions.size();
        }
        /**
         * @brief Build printable bundle name in "{A+B+C}" format.
         *
         * @return Human-readable bundle name.
         */
        std::string bundleName() const;
    };

    /**
     * @brief Insert bundle into waiting queue by descending effective priority.
     *
     * @param bundle Bundle instance to insert.
     *
     * @note Caller must hold @ref mutex_.
     */
    void _insertWaitingFunctionUnlocked(FunctionBundle bundle);
    /**
     * @brief Promote next candidate function after current function stops.
     *
     * Selection is decided between paused-stack top and waiting-queue head
     * based on scheduler priority.
     *
     * @return true if a function is promoted to running; otherwise false.
     *
     * @note Caller must hold @ref mutex_.
     */
    bool _promoteNextFunctionUnlocked();
    /**
     * @brief Promote next function inside current running bundle.
     *
     * @return true if bundle has next function and is promoted.
     *
     * @note Caller must hold @ref mutex_.
     */
    bool _promoteNextFunctionInRunningBundleUnlocked();
    /**
     * @brief Build a paused stack snapshot in top-first order.
     *
     * @return Vector containing paused functions from stack top to bottom.
     *
     * @note Caller must hold @ref mutex_.
     */
    std::vector<FunctionBundle> _pausedTopFirstUnlocked() const;
    /**
     * @brief Build a paused bundle stack snapshot in top-first order.
     *
     * @return Vector containing paused bundles from stack top to bottom.
     *
     * @note Caller must hold @ref mutex_.
     */
    std::vector<FunctionBundle> _pausedTopFirstCopyUnlocked() const;
    /**
     * @brief Create runtime bundle from ordered function list.
     *
     * @param functions Ordered function list.
     * @return Created bundle with generated id and computed effective priority.
     *
     * @note Caller must hold @ref mutex_.
     */
    FunctionBundle _createBundleFromFunctionsUnlocked(const std::vector<std::shared_ptr<Function>>& functions);
    /**
     * @brief Wrap one legacy function into a single-item bundle.
     *
     * @param function Legacy function object.
     * @return Created single-item bundle.
     *
     * @note Caller must hold @ref mutex_.
     */
    FunctionBundle _bundleFromLegacyFunctionUnlocked(const std::shared_ptr<Function>& function);
    /**
     * @brief Generate runtime bundle id.
     *
     * @return Generated bundle id string.
     *
     * @note Caller must hold @ref mutex_.
     */
    std::string _buildBundleIdUnlocked();
    /**
     * @brief Reset runtime scheduling state before loading snapshot.
     *
     * @note Caller must hold @ref mutex_.
     */
    void _resetRuntimeStateUnlocked();
    /**
     * @brief Load running bundle (new or legacy schema) from payload.
     *
     * @param payload Scheduler JSON snapshot.
     * @return true if running bundle data is valid.
     *
     * @note Caller must hold @ref mutex_.
     */
    bool _loadRunningBundleUnlocked(const json& payload);
    /**
     * @brief Load paused bundles (new or legacy schema) from payload.
     *
     * @param payload Scheduler JSON snapshot.
     * @return true if paused bundle data is valid.
     *
     * @note Caller must hold @ref mutex_.
     */
    bool _loadPausedBundlesUnlocked(const json& payload);
    /**
     * @brief Load waiting bundles (new or legacy schema) from payload.
     *
     * @param payload Scheduler JSON snapshot.
     * @return true if waiting bundle data is valid.
     *
     * @note Caller must hold @ref mutex_.
     */
    bool _loadWaitingBundlesUnlocked(const json& payload);
    /**
     * @brief Build one bundle from serialized bundle JSON.
     *
     * @param bundle_json Serialized bundle JSON.
     * @param current_status Status assigned to bundle current function.
     * @param out_bundle Output bundle.
     * @return true if bundle is parsed and validated.
     *
     * @note Caller must hold @ref mutex_.
     */
    bool _bundleFromJsonUnlocked(const json& bundle_json, core::FunctionStatus current_status,
                                 FunctionBundle* out_bundle);
    /**
     * @brief Create a function instance from serialized JSON metadata.
     *
     * @param function_json Serialized function object.
     * @return Created function instance, or nullptr when reconstruction fails.
     *
     * @note Caller must hold @ref mutex_.
     */
    std::shared_ptr<Function> _createFunctionFromJsonUnlocked(const json& function_json) const;
    /**
     * @brief Load serialized bundle array into waiting queue or paused stack.
     *
     * @param payload Scheduler JSON snapshot.
     * @param key JSON field name.
     * @param out_waiting_bundles Output waiting queue target.
     * @param out_paused_bundles Output paused stack target.
     * @return true if array parsing succeeds.
     *
     * @note Caller must hold @ref mutex_.
     */
    bool _loadBundleArrayUnlocked(const json& payload, const char* key,
                                  std::vector<FunctionBundle>* out_waiting_bundles,
                                  std::stack<FunctionBundle>* out_paused_bundles);

    /// Mutex guarding all internal scheduler state.
    mutable std::mutex mutex_;
    /// Currently running bundle.
    std::optional<FunctionBundle> running_bundle_;
    /// Paused bundle stack (LIFO).
    std::stack<FunctionBundle> paused_function_stack_;
    /// Waiting bundle queue sorted by descending effective priority.
    std::vector<FunctionBundle> waiting_function_queue_;
    /// Pause context storage keyed by function_id.
    std::unordered_map<std::string, std::map<std::string, std::any>> pause_contexts_;
    /// Factory registry used for deserializing function instances.
    std::unordered_map<std::string, FunctionFactory> function_factories_;
    /// Validators for function transitions.
    std::map<core::FunctionType, ValidationFn> _validators;
    /// Monotonic counter for generated bundle ids.
    std::uint64_t next_bundle_sequence_{1};
};

}  // namespace framework
}  // namespace applications
}  // namespace robot_control
