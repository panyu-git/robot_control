#include "robot_control/applications/functions/wakeup_function.hpp"

#include <cmath>

#include "robot_control/common/logging.hpp"
#include "robot_control/core/enums.hpp"
#include "robot_control/core/robot_control_configs.hpp"
#include "robot_control/services/navigation_service.hpp"

namespace robot_control {
namespace applications {
namespace functions {

WakeupFunction::WakeupFunction(std::shared_ptr<core::Blackboard> blackboard, const interfaces::RobotContext& context)
    : Function(blackboard),
      _mutex(),
      _context(context),
      _node(nullptr),
      _target_yaw(),
      _max_angular_velocity("0.5"),
      _timeout(),
      _task_id(),
      _user_id(),
      _wakeup_callback(nullptr) {
    LOG_INFO("WakeupFunction: Initialized");
}

void WakeupFunction::onEnter(const std::optional<std::map<std::string, std::any>>& /*context*/) {
    LOG_INFO("WakeupFunction: Entering wakeup state");

    if (!_context.navigation) {
        LOG_ERROR("WakeupFunction: Navigation service not available");
        _publishInteraction("唤醒失败：导航服务未初始化");
        _status = core::FunctionStatus::FAILED;
        return;
    }

    auto target_yaw = _blackboard->get<std::string>(core::BlackboardKeys::LAST_WAKEUP_TARGET_YAW, "");
    if (target_yaw.empty()) {
        target_yaw = _blackboard->get<std::string>(core::BlackboardKeys::LAST_WAKEUP_WAKEUP_ANGLE, "");
    }

    if (target_yaw.empty()) {
        LOG_ERROR("WakeupFunction: Missing wakeup parameters");
        _publishInteraction("唤醒失败：缺少唤醒参数");
        _status = core::FunctionStatus::FAILED;
        return;
    }

    _wakeup_callback = [this](bool success, const std::string& message) { this->_onWakeupComplete(success, message); };

    LOG_INFO("WakeupFunction: Wakeup initialization completed, waiting for engine tick");
    _blackboard->deleteKey("wakeup_fail_reason");
    _blackboard->set("wakeup_phase", core::WakeupPhase::WAKEUP);
}

std::optional<std::map<std::string, std::any>> WakeupFunction::onExit() {
    LOG_INFO("WakeupFunction: Exiting wakeup state");

    stopWakeup();
    _wakeup_callback = nullptr;

    _status = core::FunctionStatus::IDLE;
    return std::nullopt;
}

core::FunctionStatus WakeupFunction::preTick() {
    // 1. Handle user/internal commands first.
    // This ensures that if a command (like 'rotate') is issued, the service status
    // is updated BEFORE we sync it to the blackboard in the next step.
    auto cmd_status = _checkUserCommands();

    // 2. Mirror service status to blackboard for decoupled BT nodes
    if (_context.navigation) {
        _blackboard->set("nav_status", static_cast<int>(_context.navigation->navigationStatus()));
        // Sync the last result success flag directly from service to blackboard
        _blackboard->set("nav_last_result_success", _context.navigation->isNavigationSuccessful());
    }

    auto health_status = _context.checkHealth(functionType(), _sessionStartTime);
    if (health_status == core::FunctionStatus::FAILED) {
        return health_status;
    }

    return cmd_status;
}

core::FunctionStatus WakeupFunction::_checkUserCommands() {
    if (_blackboard->get<bool>(core::BlackboardKeys::CMD_STOP_REQUEST, false)) {
        LOG_INFO_NAMED("WakeupFunction", "COMPLETED due to cmd_stop_request on blackboard");
        _blackboard->set(core::BlackboardKeys::CMD_STOP_REQUEST, false);
        _status = core::FunctionStatus::COMPLETED;
    }

    return _status;
}

void WakeupFunction::_handleInternalCommands() {
    std::string navigation_cmd = _blackboard->get<std::string>("navigation_cmd", "");
    if (!navigation_cmd.empty()) {
        _blackboard->set("navigation_cmd", std::string(""));
        if (navigation_cmd == "rotate" && _context.navigation) {
            std::string user_id = _blackboard->get<std::string>("navigation_target_user", "");
            std::string target_yaw = _blackboard->get<std::string>("navigation_target_yaw", "");
            std::string max_w = _blackboard->get<std::string>("navigation_max_angular_velocity", "0.5");
            std::string timeout = _blackboard->get<std::string>("navigation_timeout", "");
            std::string task_id = _blackboard->get<std::string>("navigation_task_id", "");

            std::map<std::string, std::string> params;
            params["target_yaw"] = target_yaw;
            params["max_angular_velocity"] = max_w;
            if (!timeout.empty()) params["timeout"] = timeout;
            if (!task_id.empty()) params["task_id"] = task_id;
            params["request_start"] = "true";

            _context.navigation->requestFollowTask("ROTATE_TASK", user_id, params);
        } else if (navigation_cmd == "cancel" && _context.navigation) {
            _context.navigation->cancelNavigation();
        }
    }
}

core::FunctionStatus WakeupFunction::postTick() {
    // 1. Update status from behavior tree engine
    auto prev_status = _status;
    updateStatusFromEngine();

    // 2. Handle internal commands from BT nodes IMMEDIATELY after they are issued.
    // This reduces latency and ensures the next preTick() syncs the updated service state.
    _handleInternalCommands();

    // Success/Failure Leak Prevention:
    // If engine returns SUCCESS or FAILURE but we are not in IDLE phase, it means a state transition
    // just happened and the engine will re-tick in the next control loop cycle.
    // We must stay in RUNNING to keep the function alive.
    auto phase = _blackboard->get<core::WakeupPhase>("wakeup_phase", core::WakeupPhase::IDLE);

    if ((_status == core::FunctionStatus::COMPLETED || _status == core::FunctionStatus::FAILED) &&
        phase != core::WakeupPhase::IDLE) {
        // If engine failed with a critical error (exception), do not prevent exit
        std::string engine_error = _blackboard->get<std::string>("WAKEUP/engine_error", "");
        if (_status == core::FunctionStatus::FAILED && !engine_error.empty()) {
            LOG_ERROR("WakeupFunction: Critical engine error detected: " << engine_error << ". Exiting function.");
        } else {
            if (_status != prev_status) {
                static auto last_leak_log_time = std::chrono::steady_clock::now();
                auto now = std::chrono::steady_clock::now();
                if (std::chrono::duration<double>(now - last_leak_log_time).count() >= 1.0) {
                    LOG_INFO("WakeupFunction: Status leak prevented, engine returned "
                             << core::toString(_status) << " but phase is " << core::toString(phase)
                             << ". Staying RUNNING.");
                    last_leak_log_time = now;
                }
            }

            // If engine failed with a reason, we should still process it but stay RUNNING
            // to allow the tree to cleanup if necessary, or just stay RUNNING until phase is IDLE.
            if (_status == core::FunctionStatus::FAILED && prev_status != core::FunctionStatus::FAILED) {
                std::string reason = _blackboard->get<std::string>("wakeup_fail_reason", "");
                static auto last_leak_warn_time = std::chrono::steady_clock::now();
                auto now = std::chrono::steady_clock::now();
                if (std::chrono::duration<double>(now - last_leak_warn_time).count() >= 1.0) {
                    LOG_WARN("WakeupFunction: Engine reported FAILURE while phase is "
                             << core::toString(phase) << ", reason=" << (reason.empty() ? "unknown" : reason)
                             << ", engine_error=" << (engine_error.empty() ? "none" : engine_error));
                    last_leak_warn_time = now;
                }
            }

            _status = core::FunctionStatus::RUNNING;
        }
    }

    if (_status != prev_status) {
        if (_status == core::FunctionStatus::COMPLETED) {
            _onWakeupComplete(true, "唤醒成功，已完成朝向调整");
        } else if (_status == core::FunctionStatus::FAILED) {
            std::string reason = _blackboard->get<std::string>("wakeup_fail_reason", "");
            LOG_WARN("WakeupFunction: FAILED, reason=" << (reason.empty() ? "unknown" : reason));
            std::string msg = "唤醒失败";
            if (reason == "rotate_task_timeout") {
                msg = "唤醒超时，朝向调整未完成";
            } else if (!reason.empty()) {
                msg = "唤醒失败：" + reason;
            }
            _onWakeupComplete(false, msg);
        }
    }

    return _status;
}

bool WakeupFunction::startWakeup(const std::string& /*target_yaw*/, const std::string& /*max_angular_velocity*/,
                                 const std::string& /*timeout*/, const std::string& /*task_id*/,
                                 const std::string& /*user_id*/) {
    // This method is now legacy as the function entry is handled via Blackboard keys
    // and transitionTo in FunctionManager.
    return true;
}

bool WakeupFunction::stopWakeup() {
    if (_status == core::FunctionStatus::IDLE) {
        return true;
    }

    if (_context.navigation) {
        _context.navigation->cancelNavigation();
    }

    LOG_INFO("WakeupFunction: Wakeup stopped");
    return true;
}

void WakeupFunction::resetWakeupState() {
    _target_yaw.clear();
    _max_angular_velocity = "0.5";
    _timeout.clear();
    _task_id.clear();
    _user_id.clear();
    LOG_INFO("WakeupFunction: State reset");
}

bool WakeupFunction::isWakeupComplete() const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _status == core::FunctionStatus::COMPLETED;
}

bool WakeupFunction::isWakeupFailed() const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _status == core::FunctionStatus::FAILED;
}

bool WakeupFunction::isWakeupTimeout() const {
    std::lock_guard<std::mutex> lock(_mutex);
    std::string reason = _blackboard->get<std::string>("wakeup_fail_reason", "");
    return _status == core::FunctionStatus::FAILED && reason == "rotate_task_timeout";
}

double WakeupFunction::getWakeupElapsedTime() const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _getWakeupElapsedTime();
}

double WakeupFunction::_getWakeupElapsedTime() const {
    auto now = std::chrono::steady_clock::now();
    return std::chrono::duration<double>(now - _sessionStartTime).count();
}

void WakeupFunction::setWakeupCallback(WakeupCallback callback) {
    std::lock_guard<std::mutex> lock(_mutex);
    _wakeup_callback = callback;
}

void WakeupFunction::_onWakeupComplete(bool success, const std::string& message) {
    LOG_INFO("WakeupFunction: Wakeup finalized, success=" << success << ", message=" << message);

    // Note: nav_last_result_success is now updated in preTick for real-time BT access.
    // This callback now only handles HMI and high-level feedback.

    if (success) {
        _publishInteraction(message);
        _publishFeedback(core::EventType::FEEDBACK_WAKE_UP_RELAY, "唤醒成功");
    } else {
        _publishInteraction(message);
    }
}

void WakeupFunction::_publishInteraction(const std::string& message) {
    LOG_DEBUG("WakeupFunction: Publishing interaction: " << message);

    core::Event interaction_event(core::EventType::HMI_INTERACTION_REQUEST, "WakeupFunction");
    interaction_event.data["message"] = message;
    interaction_event.data["session_id"] = "0";

    try {
        core::EventBus::getInstance().publish(interaction_event);
    } catch (const std::exception& e) {
        LOG_ERROR("WakeupFunction: Failed to publish interaction event: " << e.what());
    }
}

void WakeupFunction::_publishFeedback(core::EventType type, const std::string& message) {
    LOG_DEBUG("WakeupFunction: Publishing feedback of type: " << static_cast<int>(type));
    if (!message.empty()) {
        LOG_DEBUG("WakeupFunction: Feedback message: " << message);
    }

    core::Event feedback_event(type, "WakeupFunction");
    if (!message.empty()) {
        feedback_event.data["message"] = message;
    }
    feedback_event.data["session_id"] = "0";

    try {
        core::EventBus::getInstance().publish(feedback_event);
    } catch (const std::exception& e) {
        LOG_ERROR("WakeupFunction: Failed to publish feedback event: " << e.what());
    }
}

}  // namespace functions
}  // namespace applications
}  // namespace robot_control
