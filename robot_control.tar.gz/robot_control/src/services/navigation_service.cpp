#include "robot_control/services/navigation_service.hpp"

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cmath>
#include <rclcpp_action/exceptions.hpp>
#include <sstream>

#include "robot_control/utils/logic_utils.hpp"

namespace robot_control {
namespace services {

NavigationService::NavigationService(bool simulated)
    : ServiceBase("NavigationService", simulated),
      _status_nav(core::NavigationStatus::IDLE),
      _mode(NavigationMode::IDLE),
      _last_follow_trace_time(0.0),
      _last_nav_feedback_time(0.0),
      _last_nav_timeout_warn_time(0.0),
      _active_nav_goal_handle(nullptr),
      _nav_goal_status(GoalStatus::UNKNOWN),
      _current_goal_id(0) {}

NavigationService::~NavigationService() {
    _doShutdown();
}

void NavigationService::init(rclcpp::Node::SharedPtr node) {
    _node = node;
    if (_node) {
        _nav_client = rclcpp_action::create_client<nav_interfaces::action::NavTaskJson>(_node, "nav_task_request");
        LOG_INFO("ROS2 Action Client initialized for nav_task_request");
        _follow_task_pub = _node->create_publisher<nav_interfaces::msg::FollowTask>("nav_task_request", 10);
        LOG_INFO("ROS2 Publisher initialized for nav_task_request (FollowTask)");
    }
    initialize();
}

bool NavigationService::_doInitialize() {
    LOG_INFO("[NAV] Initializing navigation service interfaces...");
    if (!_nav_client->wait_for_action_server(std::chrono::seconds(2))) {
        LOG_WARN("[NAV] External /nav_task_request server not available yet");
    } else {
        LOG_INFO("[NAV] External /nav_task_request server connected");
    }

    return true;
}

void NavigationService::_doShutdown() {
    // stopFollow() already cancels nav action goals.
    stopFollow();
    _nav_client.reset();
    _follow_task_pub.reset();
}

bool NavigationService::startFollow(const std::string& mode, double distance, double speed,
                                    const std::string& user_id) {
    if (_status != ServiceStatus::READY) {
        LOG_ERROR("Service not ready");
        return false;
    }

    LOG_INFO("Starting follow: mode=" << mode << ", distance=" << distance << ", speed=" << speed);

    // Follow requires nav_task_request online; tracking alone is not enough.
    if (!_simulated) {
        if (!_nav_client) {
            LOG_ERROR("Navigation action client is null, cannot start follow");
            return false;
        }
        if (!_nav_client->wait_for_action_server(std::chrono::seconds(2))) {
            LOG_WARN("nav_task_request server is not ready, reject follow start (timeout=2s)");
            stopFollow();
            return false;
        }
    }

    auto now = std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();

    {
        std::lock_guard<std::mutex> lock(_mutex);
        _follow_params["mode"] = mode;
        _follow_params["task_name"] = "FOLLOW_TASK";
        _follow_params["request_start"] = "true";
        _follow_params["user_id"] = user_id;
        _follow_params["param_follow_dis_m"] = std::to_string(distance);
        _follow_params["param_speed_ms"] = std::to_string(speed);
        _follow_params["param_follow_dir"] = (mode == "left") ? "1" : ((mode == "right") ? "2" : "0");
        _follow_params["start_time"] = std::to_string(now);
        _last_follow_trace_time = now;
        _last_nav_feedback_time = now;
        _target_timeout = std::nullopt;
        _mode = NavigationMode::FOLLOW_HUMAN;
        _status_nav = core::NavigationStatus::RUNNING;  // 立即设置为 RUNNING，避免 BT 启动瞬间的 IDLE 误判
    }

    // Runtime follow dispatch is unified for both simulated and real modes.
    // Face authentication is handled in activation flow.
    std::map<std::string, std::string> task_params;
    task_params["request_start"] = "true";
    task_params["param_speed_ms"] = std::to_string(speed);
    task_params["param_follow_dis_m"] = std::to_string(distance);
    task_params["param_follow_dir"] = (mode == "left") ? "1" : ((mode == "right") ? "2" : "0");
    bool nav_ok = requestFollowTask("FOLLOW_TASK", user_id, task_params);
    if (!nav_ok) {
        LOG_WARN("startFollow failed to dispatch FOLLOW_TASK");
    }
    return nav_ok;
}

bool NavigationService::requestFollowTask(const std::string& task, const std::string& user_id,
                                          const std::map<std::string, std::string>& params) {
    if (!rclcpp::ok()) {
        LOG_ERROR("requestFollowTask: rclcpp is not ok");
        return false;
    }
    if (_status != ServiceStatus::READY) {
        LOG_ERROR("requestFollowTask: Navigation service status is " << static_cast<int>(_status) << ", not READY");
        return false;
    }
    if (user_id.empty()) {
        LOG_ERROR("requestFollowTask: user_id is empty");
        return false;
    }

    uint64_t goal_id = 0;
    {
        std::lock_guard<std::mutex> lock(_mutex);
        _nav_goal_status = GoalStatus::UNKNOWN;
        _current_goal_id++;
        goal_id = _current_goal_id;
        LOG_INFO("[NAV] requestFollowTask: task=" << task << ", goal_id=" << goal_id);
    }

    auto request_start_it = params.find("request_start");
    bool request_start = true;
    if (request_start_it != params.end()) {
        std::string req = request_start_it->second;
        std::transform(req.begin(), req.end(), req.begin(), ::tolower);
        if (req == "false" || req == "0") request_start = false;
    }

    // Full teardown of follow (nav + perception) is centralized in stopFollow().
    // Here we only build JSON goals; perception is not cancelled on this path unless stopFollow() runs.

    if (request_start) {
        std::lock_guard<std::mutex> lock(_mutex);
        _status_nav = core::NavigationStatus::RUNNING;  // 启动任务时立即置为 RUNNING，确保 BT 状态一致性
    }

    if (!_nav_client) {
        // Stop request should be best-effort even when nav action is offline.
        if (task == "FOLLOW_TASK" && !request_start) {
            std::lock_guard<std::mutex> lock(_mutex);
            _status_nav = core::NavigationStatus::IDLE;
            _mode = NavigationMode::IDLE;
            return true;
        }
        LOG_ERROR("Navigation action client is null, cannot dispatch task");
        return false;
    }
    if (!_nav_client->wait_for_action_server(std::chrono::seconds(2))) {
        if (task == "FOLLOW_TASK" && !request_start) {
            LOG_INFO("nav_task_request server is not ready, skip remote FOLLOW stop dispatch (timeout=2s)");
            // Best-effort fallback: try to cancel active goals even when graph discovery
            // reports server not ready during shutdown race window.
            _nav_client->async_cancel_all_goals();
            std::lock_guard<std::mutex> lock(_mutex);
            _status_nav = core::NavigationStatus::IDLE;
            _mode = NavigationMode::IDLE;
            return true;
        }
        LOG_WARN("nav_task_request server is not ready, dispatch rejected (timeout=2s)");
        stopFollow();
        return false;
    }

    nlohmann::json task_json;
    task_json["task_name"] = task;
    task_json["request_start"] = request_start;

    if (task == "ROTATE_TASK") {
        // New rotate task parameters:
        // - target_yaw (rad): required (fallback to wakeup_angle for compatibility)
        // - max_angular_velocity (rad/s): defaults to 0.5 if missing; 0 means unlimited
        // - timeout (s): optional; 0 means no timeout
        // - task_id: optional trace id
        std::string target_yaw_s = "";
        auto yaw_it = params.find("target_yaw");
        if (yaw_it != params.end() && !yaw_it->second.empty()) {
            target_yaw_s = yaw_it->second;
        } else {
            auto angle_it = params.find("wakeup_angle");
            if (angle_it != params.end() && !angle_it->second.empty()) {
                target_yaw_s = angle_it->second;
            }
        }
        if (target_yaw_s.empty()) {
            // Legacy rotate direction support (best-effort)
            auto rotate_it = params.find("param_rotate_dir");
            if (rotate_it != params.end() && !rotate_it->second.empty()) {
                try {
                    task_json["param_rotate_dir"] = std::stoi(rotate_it->second);
                } catch (...) {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            try {
                task_json["target_yaw"] = static_cast<float>(std::stod(target_yaw_s));
            } catch (...) {
                return false;
            }

            float max_w = 0.5f;
            auto max_it = params.find("max_angular_velocity");
            if (max_it != params.end() && !max_it->second.empty()) {
                try {
                    max_w = static_cast<float>(std::stod(max_it->second));
                } catch (...) {
                }
            }
            task_json["max_angular_velocity"] = max_w;

            float timeout_s = 0.0f;
            auto timeout_it = params.find("timeout");
            if (timeout_it != params.end() && !timeout_it->second.empty()) {
                try {
                    timeout_s = static_cast<float>(std::stod(timeout_it->second));
                } catch (...) {
                }
            }
            task_json["timeout"] = timeout_s;

            auto task_id_it = params.find("task_id");
            if (task_id_it != params.end() && !task_id_it->second.empty()) {
                task_json["task_id"] = task_id_it->second;
            }
        }

        {
            std::lock_guard<std::mutex> lock(_mutex);
            _follow_params["task_name"] = "ROTATE_TASK";
            _follow_params["user_id"] = user_id;
            _mode = NavigationMode::NAVIGATE_TO_POSE;
            _last_nav_feedback_time =
                std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
            _target_timeout = std::nullopt;
            _status_nav = core::NavigationStatus::RUNNING;
        }
    } else if (task == "FOLLOW_TASK") {
        double speed_ms = 1.0;
        double follow_dis_m = 1.0;
        int follow_dir = 0;

        auto speed_it = params.find("param_speed_ms");
        if (speed_it != params.end()) try {
                speed_ms = std::stod(speed_it->second);
            } catch (...) {
            }

        auto dis_it = params.find("param_follow_dis_m");
        if (dis_it != params.end()) try {
                follow_dis_m = std::stod(dis_it->second);
            } catch (...) {
            }

        auto dir_it = params.find("param_follow_dir");
        if (dir_it != params.end()) try {
                follow_dir = std::stoi(dir_it->second);
            } catch (...) {
            }

        task_json["param_speed_ms"] = speed_ms;
        task_json["param_follow_dis_m"] = follow_dis_m;
        task_json["param_follow_dir"] = follow_dir;

        {
            std::lock_guard<std::mutex> lock(_mutex);
            _follow_params["task_name"] = "FOLLOW_TASK";
            _follow_params["request_start"] = request_start ? "true" : "false";
            _follow_params["user_id"] = user_id;
            _follow_params["param_speed_ms"] = std::to_string(speed_ms);
            _follow_params["param_follow_dis_m"] = std::to_string(follow_dis_m);
            _follow_params["param_follow_dir"] = std::to_string(follow_dir);
            _follow_params["mode"] = (follow_dir == 1) ? "left" : ((follow_dir == 2) ? "right" : "center");
            _mode = NavigationMode::FOLLOW_HUMAN;  // No human follow
            _last_nav_feedback_time =
                std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
            _target_timeout = std::nullopt;
            _status_nav = request_start ? core::NavigationStatus::RUNNING : core::NavigationStatus::IDLE;
        }
    } else {
        return false;
    }

    nav_interfaces::action::NavTaskJson::Goal goal;
    goal.task_json = task_json.dump();
    if (task == "ROTATE_TASK") {
        std::string raw_target_yaw = "";
        std::string raw_max_w = "";
        std::string raw_timeout = "";
        std::string raw_task_id = "";
        std::string raw_wakeup_angle = "";
        std::string raw_rotate_dir = "";

        auto target_it = params.find("target_yaw");
        if (target_it != params.end()) raw_target_yaw = target_it->second;
        auto max_it = params.find("max_angular_velocity");
        if (max_it != params.end()) raw_max_w = max_it->second;
        auto timeout_it = params.find("timeout");
        if (timeout_it != params.end()) raw_timeout = timeout_it->second;
        auto task_id_it = params.find("task_id");
        if (task_id_it != params.end()) raw_task_id = task_id_it->second;
        auto wakeup_it = params.find("wakeup_angle");
        if (wakeup_it != params.end()) raw_wakeup_angle = wakeup_it->second;
        auto rotate_it = params.find("param_rotate_dir");
        if (rotate_it != params.end()) raw_rotate_dir = rotate_it->second;

        float final_target_yaw = 0.0f;
        float final_max_w = 0.0f;
        float final_timeout = 0.0f;
        int final_rotate_dir = 0;
        try {
            final_target_yaw = task_json.value("target_yaw", 0.0f);
        } catch (...) {
            final_target_yaw = 0.0f;
        }
        try {
            final_max_w = task_json.value("max_angular_velocity", 0.0f);
        } catch (...) {
            final_max_w = 0.0f;
        }
        try {
            final_timeout = task_json.value("timeout", 0.0f);
        } catch (...) {
            final_timeout = 0.0f;
        }
        try {
            final_rotate_dir = task_json.value("param_rotate_dir", 0);
        } catch (...) {
            final_rotate_dir = 0;
        }
        LOG_INFO("[dispatch][ROTATE_TASK] user_id="
                 << user_id << ", request_start=" << (request_start ? "true" : "false")
                 << ", raw_target_yaw=" << (raw_target_yaw.empty() ? "<empty>" : raw_target_yaw)
                 << ", raw_max_angular_velocity=" << (raw_max_w.empty() ? "<empty>" : raw_max_w)
                 << ", raw_timeout=" << (raw_timeout.empty() ? "<empty>" : raw_timeout)
                 << ", raw_task_id=" << (raw_task_id.empty() ? "<empty>" : raw_task_id)
                 << ", raw_wakeup_angle=" << (raw_wakeup_angle.empty() ? "<empty>" : raw_wakeup_angle)
                 << ", raw_param_rotate_dir=" << (raw_rotate_dir.empty() ? "<empty>" : raw_rotate_dir)
                 << ", final_target_yaw=" << final_target_yaw << ", final_max_angular_velocity=" << final_max_w
                 << ", final_timeout=" << final_timeout << ", final_param_rotate_dir=" << final_rotate_dir
                 << ", task_json=" << goal.task_json);
    } else {
        LOG_INFO("[dispatch][" << task << "] user_id=" << user_id << ", request_start="
                               << (request_start ? "true" : "false") << ", task_json=" << goal.task_json);
    }

    auto send_goal_options = rclcpp_action::Client<nav_interfaces::action::NavTaskJson>::SendGoalOptions();
    auto last_nav_feedback_log_time = std::make_shared<double>(0.0);
    send_goal_options.goal_response_callback =
        [this, task, user_id, request_start,
         goal_id](const rclcpp_action::ClientGoalHandle<nav_interfaces::action::NavTaskJson>::SharedPtr& goal_handle) {
            if (!goal_handle) {
                // A stop dispatch can be rejected as "Busy" when there is an active FOLLOW goal.
                // Still cancel all nav_task_request goals so the follow task is torn down.
                if (task == "FOLLOW_TASK" && !request_start) {
                    LOG_INFO("NavTaskJson stop goal rejected (likely busy), fallback: async_cancel_all_goals");
                    cancelNavigation();
                    return;
                }
                LOG_ERROR("NavTaskJson goal was rejected by server");
                std::lock_guard<std::mutex> lock(_mutex);
                if (goal_id == _current_goal_id) {
                    _status_nav = core::NavigationStatus::FAILED;
                    _nav_goal_status = GoalStatus::ABORTED;
                }
                return;
            }

            {
                std::lock_guard<std::mutex> lock(_mutex);
                if (goal_id != _current_goal_id) {
                    LOG_WARN("[NAV] goal_response: ignoring stale goal (id=" << goal_id << ", current="
                                                                             << _current_goal_id << ")");
                    return;
                }

                LOG_INFO("[goal_response][" << task << "] user_id=" << user_id
                                            << ", request_start=" << (request_start ? "true" : "false")
                                            << ", status=ACCEPTED, goal_id=" << goal_id);
                _active_nav_goal_handle = goal_handle;
            }
        };

    send_goal_options.feedback_callback =
        [this, task, user_id, request_start, last_nav_feedback_log_time, goal_id](
            rclcpp_action::ClientGoalHandle<nav_interfaces::action::NavTaskJson>::SharedPtr goal_handle,
            const std::shared_ptr<const nav_interfaces::action::NavTaskJson::Feedback> feedback) {
            {
                std::lock_guard<std::mutex> lock(_mutex);
                if (goal_id != _current_goal_id || goal_handle != _active_nav_goal_handle) return;
            }

            _processNavStatusJson(feedback->feedback_json);

            std::lock_guard<std::mutex> lock(_mutex);
            double now = std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
            if (now - *last_nav_feedback_log_time >= 2.0) {
                LOG_INFO("[feedback][" << task << "] user_id=" << user_id
                                       << ", request_start=" << (request_start ? "true" : "false")
                                       << ", feedback_json=" << feedback->feedback_json << ", goal_id=" << goal_id);
                *last_nav_feedback_log_time = now;
            }
        };

    send_goal_options.result_callback = [this, task, user_id, request_start, goal_id,
                                         dispatched_task_json = goal.task_json](const auto& result) {
        std::string code_str = "UNKNOWN";
        switch (result.code) {
            case rclcpp_action::ResultCode::SUCCEEDED:
                code_str = "SUCCEEDED";
                break;
            case rclcpp_action::ResultCode::CANCELED:
                code_str = "CANCELED";
                break;
            case rclcpp_action::ResultCode::ABORTED:
                code_str = "ABORTED";
                break;
            default:
                break;
        }
        bool nav_result_success = false;
        std::string nav_result_json = "";
        if (result.result) {
            nav_result_success = result.result->success;
            nav_result_json = result.result->result_json;
        }
        LOG_INFO("[result][" << task << "] user_id=" << user_id
                             << ", request_start=" << (request_start ? "true" : "false") << ", action_code=" << code_str
                             << ", nav_result_success=" << (nav_result_success ? "true" : "false")
                             << ", nav_result_json=" << (nav_result_json.empty() ? "<empty>" : nav_result_json)
                             << ", task_json=" << dispatched_task_json << ", goal_id=" << goal_id);
        std::lock_guard<std::mutex> lock(_mutex);

        if (goal_id != _current_goal_id) {
            LOG_WARN("[NAV] result_callback: ignoring stale result (id=" << goal_id << ", current=" << _current_goal_id
                                                                         << ")");
            return;
        }

        _active_nav_goal_handle.reset();

        if (result.code == rclcpp_action::ResultCode::SUCCEEDED) {
            _nav_goal_status = GoalStatus::SUCCEEDED;
            _status_nav = core::NavigationStatus::IDLE;
        } else if (result.code == rclcpp_action::ResultCode::CANCELED) {
            _nav_goal_status = GoalStatus::CANCELED;
            _status_nav = core::NavigationStatus::IDLE;
        } else {
            _nav_goal_status = GoalStatus::ABORTED;
            _status_nav = core::NavigationStatus::FAILED;
        }
        if (_navigation_complete_callback)
            _navigation_complete_callback(result.code == rclcpp_action::ResultCode::SUCCEEDED);
    };

    _nav_client->async_send_goal(goal, send_goal_options);
    return true;
}

bool NavigationService::updateFollowParams(std::optional<double> distance, std::optional<double> speed) {
    std::string user_id;
    std::string mode = "center";
    double current_distance = 1.0;
    double current_speed = 1.0;
    {
        std::lock_guard<std::mutex> lock(_mutex);
        if (_follow_params.empty()) {
            return false;
        }
        if (distance.has_value()) {
            _follow_params["param_follow_dis_m"] = std::to_string(distance.value());
        }
        if (speed.has_value()) {
            _follow_params["param_speed_ms"] = std::to_string(speed.value());
        }

        auto uid_it = _follow_params.find("user_id");
        if (uid_it != _follow_params.end()) {
            user_id = uid_it->second;
        }
        if (_follow_params.count("mode") > 0) {
            mode = _follow_params["mode"];
        }
        if (_follow_params.count("param_follow_dis_m") > 0) {
            try {
                current_distance = std::stod(_follow_params["param_follow_dis_m"]);
            } catch (...) {
            }
        }
        if (_follow_params.count("param_speed_ms") > 0) {
            try {
                current_speed = std::stod(_follow_params["param_speed_ms"]);
            } catch (...) {
            }
        }
    }

    if (user_id.empty()) {
        LOG_WARN("updateFollowParams skipped topic dispatch: user_id is empty");
        return false;
    }
    if (!_follow_task_pub) {
        LOG_WARN("updateFollowParams skipped topic dispatch: nav_task_request publisher not ready");
        return false;
    }

    nav_interfaces::msg::FollowTask msg;
    msg.target_id = user_id;
    msg.position = nav_interfaces::msg::FollowTask::POSITION_CUSTOM;
    if (mode == "left") {
        msg.position = nav_interfaces::msg::FollowTask::POSITION_LEFT;
    } else if (mode == "right") {
        msg.position = nav_interfaces::msg::FollowTask::POSITION_RIGHT;
    } else if (mode == "back") {
        msg.position = nav_interfaces::msg::FollowTask::POSITION_BACK;
    }
    msg.position_offset_x = 0.0f;
    msg.position_offset_y = 0.0f;
    msg.speed_level = nav_interfaces::msg::FollowTask::SPEED_CUSTOM;
    msg.velocity = static_cast<float>(current_speed);
    msg.distance_level = nav_interfaces::msg::FollowTask::DISTANCE_CUSTOM;
    if (current_distance <= 0.75) {
        msg.distance_level = nav_interfaces::msg::FollowTask::DISTANCE_CLOSE;
    } else if (current_distance <= 1.25) {
        msg.distance_level = nav_interfaces::msg::FollowTask::DISTANCE_MEDIUM;
    } else if (current_distance <= 1.75) {
        msg.distance_level = nav_interfaces::msg::FollowTask::DISTANCE_FAR;
    } else {
        msg.distance_level = nav_interfaces::msg::FollowTask::DISTANCE_VERY_FAR;
    }
    msg.follow_distance = static_cast<float>(current_distance);
    msg.timeout = 0.0f;
    _follow_task_pub->publish(msg);
    return true;
}

bool NavigationService::updateFollowPosition(const std::string& mode) {
    {
        std::lock_guard<std::mutex> lock(_mutex);
        if (_follow_params.empty()) {
            return false;
        }
        _follow_params["mode"] = mode;
        _follow_params["param_follow_dir"] = (mode == "left") ? "1" : ((mode == "right") ? "2" : "0");
    }
    return updateFollowParams(std::nullopt, std::nullopt);
}

void NavigationService::stopFollow() {
    LOG_INFO("[NAV] Stopping follow: cancel nav_task_request action");

    // 1) Cancel NavTaskJson (FOLLOW_TASK / etc.) on nav_task_request — same client as async_send_goal.
    cancelNavigation();

    std::lock_guard<std::mutex> lock(_mutex);
    _status_nav = core::NavigationStatus::IDLE;
    _mode = NavigationMode::IDLE;
    _follow_params.clear();
    _last_follow_trace_time = 0.0;
    _last_nav_feedback_time = 0.0;
    _target_timeout = std::nullopt;
    LOG_INFO("stopFollow completed, state set to IDLE");
}

std::map<std::string, std::string> NavigationService::pauseFollow() {
    LOG_INFO("[NAV] Pausing follow");

    auto now = std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();

    std::lock_guard<std::mutex> lock(_mutex);
    std::map<std::string, std::string> context;
    context["params"] = "";
    context["paused_at"] = std::to_string(now);

    _status_nav = core::NavigationStatus::RUNNING;
    return context;
}

bool NavigationService::resumeFollow(const std::map<std::string, std::string>& context) {
    LOG_INFO("Resuming follow");
    (void)context;

    std::string mode = "center";
    double distance = 1.5;
    double speed = 0.5;
    std::string user_id;

    {
        std::lock_guard<std::mutex> lock(_mutex);
        if (_follow_params.count("mode")) mode = _follow_params.at("mode");
        if (_follow_params.count("param_follow_dis_m")) distance = std::stod(_follow_params.at("param_follow_dis_m"));
        if (_follow_params.count("param_speed_ms")) speed = std::stod(_follow_params.at("param_speed_ms"));
        if (_follow_params.count("user_id")) user_id = _follow_params.at("user_id");
    }

    if (user_id.empty()) {
        LOG_ERROR("Cannot resume: user_id unknown");
        return false;
    }

    return startFollow(mode, distance, speed, user_id);
}

void NavigationService::resetFollowState() {
    std::lock_guard<std::mutex> lock(_mutex);
    _last_nav_feedback_time =
        std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
    _target_timeout = std::nullopt;
    _status_nav = core::NavigationStatus::IDLE;
    _mode = NavigationMode::IDLE;
    LOG_INFO("resetFollowState: state cleared and timestamp reset");
}

core::NavigationStatus NavigationService::update() {
    std::lock_guard<std::mutex> lock(_mutex);
    if (_simulated && _mode == NavigationMode::FOLLOW_HUMAN && _status_nav == core::NavigationStatus::RUNNING) {
        _status_nav = core::NavigationStatus::RUNNING;
    }
    return _status_nav;
}

bool NavigationService::navigateToLocation(const std::string& name, std::function<void(bool)> callback) {
    if (!_nav_client) return false;

    LOG_INFO("Navigating to location: " << name);
    uint64_t goal_id = 0;
    std::unique_lock<std::mutex> lock(_mutex);
    _current_goal_id++;
    goal_id = _current_goal_id;
    _mode = NavigationMode::NAVIGATE_TO_LOCATION;
    _goal_location = name;
    _navigation_complete_callback = callback;
    _last_nav_feedback_time =
        std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
    _status_nav = core::NavigationStatus::RUNNING;
    _nav_goal_status = GoalStatus::UNKNOWN;
    _target_timeout = std::nullopt;
    lock.unlock();

    nlohmann::json task_json;
    task_json["task_name"] = "NAV_LOCATION";
    task_json["location_name"] = name;

    nav_interfaces::action::NavTaskJson::Goal goal;
    goal.task_json = task_json.dump();

    auto send_goal_options = rclcpp_action::Client<nav_interfaces::action::NavTaskJson>::SendGoalOptions();

    send_goal_options.goal_response_callback =
        [this,
         goal_id](const rclcpp_action::ClientGoalHandle<nav_interfaces::action::NavTaskJson>::SharedPtr& goal_handle) {
            if (!goal_handle) {
                LOG_ERROR("[NAV] NAVIGATE_TO_LOCATION goal rejected");
                std::lock_guard<std::mutex> lock(_mutex);
                if (goal_id == _current_goal_id) {
                    _status_nav = core::NavigationStatus::FAILED;
                    _nav_goal_status = GoalStatus::ABORTED;
                }
                return;
            }
            std::lock_guard<std::mutex> lock(_mutex);
            if (goal_id != _current_goal_id) {
                LOG_WARN("[NAV] navigateToLocation goal_response: ignoring stale goal (id=" << goal_id << ")");
                return;
            }
            _active_nav_goal_handle = goal_handle;
            LOG_INFO("[goal_response][NAVIGATE_TO_LOCATION] accepted, goal_id=" << goal_id);
        };

    send_goal_options.feedback_callback =
        [this, goal_id](rclcpp_action::ClientGoalHandle<nav_interfaces::action::NavTaskJson>::SharedPtr goal_handle,
                        const std::shared_ptr<const nav_interfaces::action::NavTaskJson::Feedback> feedback) {
            {
                std::lock_guard<std::mutex> lock(_mutex);
                if (goal_id != _current_goal_id || goal_handle != _active_nav_goal_handle) return;
            }
            _processNavStatusJson(feedback->feedback_json);
            LOG_DEBUG("Received NavTaskJson feedback for location: " << feedback->feedback_json
                                                                     << ", goal_id=" << goal_id);
        };

    send_goal_options.result_callback = [this, goal_id](const auto& result) {
        bool success = (result.code == rclcpp_action::ResultCode::SUCCEEDED);
        std::lock_guard<std::mutex> lock(_mutex);
        if (goal_id != _current_goal_id) {
            LOG_WARN("[NAV] navigateToLocation result_callback: ignoring stale result (id=" << goal_id << ")");
            return;
        }
        _active_nav_goal_handle.reset();
        _status_nav = success ? core::NavigationStatus::IDLE : core::NavigationStatus::FAILED;
        _nav_goal_status =
            success ? GoalStatus::SUCCEEDED
                    : (result.code == rclcpp_action::ResultCode::CANCELED ? GoalStatus::CANCELED : GoalStatus::ABORTED);
        _mode = NavigationMode::IDLE;
        if (_navigation_complete_callback) _navigation_complete_callback(success);
    };

    _nav_client->async_send_goal(goal, send_goal_options);
    return true;
}

bool NavigationService::navigateToPose(double x, double y, double theta, std::function<void(bool)> callback) {
    if (!_nav_client) return false;

    LOG_INFO("Navigating to pose: x=" << x << ", y=" << y << ", theta=" << theta);
    uint64_t goal_id = 0;
    std::unique_lock<std::mutex> lock(_mutex);
    _current_goal_id++;
    goal_id = _current_goal_id;
    _mode = NavigationMode::NAVIGATE_TO_POSE;
    _navigation_complete_callback = callback;
    _last_nav_feedback_time =
        std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
    _status_nav = core::NavigationStatus::RUNNING;
    _nav_goal_status = GoalStatus::UNKNOWN;
    _target_timeout = std::nullopt;
    lock.unlock();

    nlohmann::json task_json;
    task_json["task_name"] = "NAV_POSE";
    task_json["target_x"] = x;
    task_json["target_y"] = y;
    task_json["target_theta"] = theta;

    nav_interfaces::action::NavTaskJson::Goal goal;
    goal.task_json = task_json.dump();

    auto send_goal_options = rclcpp_action::Client<nav_interfaces::action::NavTaskJson>::SendGoalOptions();

    send_goal_options.goal_response_callback =
        [this,
         goal_id](const rclcpp_action::ClientGoalHandle<nav_interfaces::action::NavTaskJson>::SharedPtr& goal_handle) {
            if (!goal_handle) {
                LOG_ERROR("[NAV] NAVIGATE_TO_POSE goal rejected");
                std::lock_guard<std::mutex> lock(_mutex);
                if (goal_id == _current_goal_id) {
                    _status_nav = core::NavigationStatus::FAILED;
                    _nav_goal_status = GoalStatus::ABORTED;
                }
                return;
            }
            std::lock_guard<std::mutex> lock(_mutex);
            if (goal_id != _current_goal_id) {
                LOG_WARN("[NAV] navigateToPose goal_response: ignoring stale goal (id=" << goal_id << ")");
                return;
            }
            _active_nav_goal_handle = goal_handle;
            LOG_INFO("[goal_response][NAVIGATE_TO_POSE] accepted, goal_id=" << goal_id);
        };

    send_goal_options.feedback_callback =
        [this, goal_id](rclcpp_action::ClientGoalHandle<nav_interfaces::action::NavTaskJson>::SharedPtr goal_handle,
                        const std::shared_ptr<const nav_interfaces::action::NavTaskJson::Feedback> feedback) {
            {
                std::lock_guard<std::mutex> lock(_mutex);
                if (goal_id != _current_goal_id || goal_handle != _active_nav_goal_handle) return;
            }
            _processNavStatusJson(feedback->feedback_json);
            LOG_DEBUG("Received NavTaskJson feedback for pose: " << feedback->feedback_json << ", goal_id=" << goal_id);
        };

    send_goal_options.result_callback = [this, goal_id](const auto& result) {
        bool success = (result.code == rclcpp_action::ResultCode::SUCCEEDED);
        std::lock_guard<std::mutex> lock(_mutex);
        if (goal_id != _current_goal_id) {
            LOG_WARN("[NAV] navigateToPose result_callback: ignoring stale result (id=" << goal_id << ")");
            return;
        }
        _active_nav_goal_handle.reset();
        _status_nav = success ? core::NavigationStatus::IDLE : core::NavigationStatus::FAILED;
        _nav_goal_status =
            success ? GoalStatus::SUCCEEDED
                    : (result.code == rclcpp_action::ResultCode::CANCELED ? GoalStatus::CANCELED : GoalStatus::ABORTED);
        _mode = NavigationMode::IDLE;
        if (_navigation_complete_callback) _navigation_complete_callback(success);
    };

    _nav_client->async_send_goal(goal, send_goal_options);
    return true;
}

bool NavigationService::isNavFeedbackFresh(int64_t timeout_ms) const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _isNavFeedbackFresh(timeout_ms);
}

bool NavigationService::_isNavFeedbackFresh(int64_t timeout_ms) const {
    return !utils::LogicUtils::IsTimeoutMs(_last_nav_feedback_time, timeout_ms);
}

bool NavigationService::navigateToChargingStation(std::function<void(bool)> callback) {
    return navigateToLocation("charging_station", callback);
}

bool NavigationService::cancelNavigation() {
    if (!rclcpp::ok()) {
        LOG_WARN("[NAV] cancelNavigation: ROS2 context is already shut down");
        return false;
    }
    if (!_nav_client) {
        LOG_WARN("[NAV] cancelNavigation: nav_task_request client is null");
        return false;
    }

    std::shared_ptr<rclcpp_action::ClientGoalHandle<nav_interfaces::action::NavTaskJson>> gh;
    {
        std::lock_guard<std::mutex> lock(_mutex);
        gh = _active_nav_goal_handle;

        // If no active goal and already in IDLE mode, skip redundant cancellation.
        // This prevents multiple 'unknown response' warnings from ROS2 action client.
        if (!gh && _mode == NavigationMode::IDLE) {
            return true;
        }

        // Increment current_goal_id to ignore any pending responses for the cancelled goal.
        _current_goal_id++;
        _nav_goal_status = GoalStatus::CANCELED;
        _mode = NavigationMode::IDLE;
        _status_nav = core::NavigationStatus::IDLE;
    }

    if (gh) {
        try {
            LOG_INFO("[NAV] cancelNavigation: async_cancel_goal(nav_task_request), goal_id="
                     << _current_goal_id << ", active_handle_ptr=" << gh.get());
            _nav_client->async_cancel_goal(gh);
        } catch (const rclcpp_action::exceptions::UnknownGoalHandleError&) {
            LOG_WARN("[NAV] async_cancel_goal: handle not tracked by client (already finished?)");
        }
    } else {
        // Only call cancel_all if we were NOT in IDLE, to ensure cleanup of any pending/unknown goals.
        LOG_INFO("[NAV] cancelNavigation: async_cancel_all_goals(nav_task_request), goal_id=" << _current_goal_id);
        _nav_client->async_cancel_all_goals();
    }

    {
        std::lock_guard<std::mutex> lock(_mutex);
        _active_nav_goal_handle.reset();
    }
    return true;
}

bool NavigationService::isReady() const {
    return _status == ServiceStatus::READY;
}

bool NavigationService::isNavServerOnline() const {
    if (!_nav_client) return false;
    return _nav_client->wait_for_action_server(std::chrono::seconds(0));
}

bool NavigationService::isNavigationComplete() const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _isNavigationComplete();
}

bool NavigationService::_isNavigationComplete() const {
    return _nav_goal_status == GoalStatus::SUCCEEDED || _nav_goal_status == GoalStatus::CANCELED ||
           _nav_goal_status == GoalStatus::ABORTED;
}

bool NavigationService::isNavigationSuccessful() const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _isNavigationSuccessful();
}

bool NavigationService::_isNavigationSuccessful() const {
    return _nav_goal_status == GoalStatus::SUCCEEDED;
}

core::NavigationStatus NavigationService::navigationStatus() const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _navigationStatus();
}

core::NavigationStatus NavigationService::_navigationStatus() const {
    // If we haven't received feedback for more than 3 seconds while active,
    // we still return the current status, but the BT will detect target lost
    // via target_timeout from last valid feedback or other mechanisms.
    // The previous logic of forcing SEARCHING here is redundant now that
    // the BT owns the state transitions.
    return _status_nav;
}

bool NavigationService::isNavFeedbackInterrupted() const {
    std::lock_guard<std::mutex> lock(_mutex);
    if (_mode != NavigationMode::FOLLOW_HUMAN) return false;
    // Current threshold for interruption is 3 seconds.
    return !_isNavFeedbackFresh(3000);
}

double NavigationService::getLastNavFeedbackTime() const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _last_nav_feedback_time;
}

std::optional<double> NavigationService::getTargetTimeout() const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _target_timeout;
}

std::tuple<double, double, double> NavigationService::currentPose() const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _currentPose();
}

std::tuple<double, double, double> NavigationService::_currentPose() const {
    return std::make_tuple(_current_pose.x, _current_pose.y, _current_pose.theta);
}

std::map<std::string, std::string> NavigationService::getFeedback() const {
    std::lock_guard<std::mutex> lock(_mutex);
    std::map<std::string, std::string> feedback;

    auto nav_status = _navigationStatus();
    feedback["status"] = std::to_string(static_cast<int>(nav_status));

    bool fresh = _isNavFeedbackFresh(3000);
    feedback["nav_mode"] = std::to_string(static_cast<int>(_mode));
    feedback["nav_goal_status"] = std::to_string(static_cast<int>(_nav_goal_status));
    feedback["task_state"] = fresh ? _last_task_state : "";
    feedback["task_message"] = fresh ? _last_task_message : "Navigation timeout";

    if (_target_timeout.has_value()) {
        feedback["target_timeout"] = std::to_string(_target_timeout.value());
    }

    auto pose = _currentPose();
    std::ostringstream oss2;
    oss2 << std::get<0>(pose) << "," << std::get<1>(pose) << "," << std::get<2>(pose);
    feedback["current_pose"] = oss2.str();

    return feedback;
}

void NavigationService::_processNavStatusJson(const std::string& json_str) {
    try {
        auto j = nlohmann::json::parse(json_str);
        std::string task_name = j.value("task_name", "");
        std::string task_state = "";

        // Handle both string and int for task_state if necessary,
        // but user spec says "1001" which is a string.
        if (j.contains("task_state")) {
            if (j["task_state"].is_string()) {
                task_state = j["task_state"];
            } else if (j["task_state"].is_number()) {
                task_state = std::to_string(j["task_state"].get<int>());
            }
        } else if (j.contains("status") && j["status"].is_string()) {
            // Fallback to "status" field if "task_state" is missing
            task_state = j["status"];
        }

        std::string message = j.value("message", "");

        {
            std::lock_guard<std::mutex> lock(_mutex);
            bool changed =
                (task_name != _last_task_name || task_state != _last_task_state || message != _last_task_message);
            if (changed) {
                static auto last_status_log_time = std::chrono::steady_clock::now();
                auto now = std::chrono::steady_clock::now();
                if (std::chrono::duration<double>(now - last_status_log_time).count() >= 1.0) {
                    LOG_INFO("Received nav status: task=" << task_name << ", state=" << task_state
                                                          << ", msg=" << message);
                    last_status_log_time = now;
                } else {
                    LOG_DEBUG("Received nav status (throttled): task=" << task_name << ", state=" << task_state
                                                                       << ", msg=" << message);
                }
            }

            _last_nav_feedback_time =
                std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
            _last_task_name = task_name;
            _last_task_state = task_state;
            _last_task_message = message;

            // Extract target_timeout from progress if available
            if (j.contains("progress") && j["progress"].is_object()) {
                if (j["progress"].contains("target_timeout")) {
                    _target_timeout = j["progress"]["target_timeout"].get<double>();
                } else {
                    _target_timeout = std::nullopt;
                }
            } else {
                _target_timeout = std::nullopt;
            }

            // Removed redundant HMI interaction request for ROTATE_TASK completion;
            // High-level success message is handled by RobotController.
            if (changed && task_name == "ROTATE_TASK" && task_state == "COMPLETED") {
                LOG_INFO("[NAV] ROTATE_TASK completed.");
            }

            // Removed explicit state mapping based on task_state/status.
            // NavigationStatus is now primarily managed by action lifecycle (start/stop/result)
            // and high-level phase is managed by the Behavior Tree.
        }
    } catch (const std::exception& e) {
        LOG_ERROR("Failed to parse nav status JSON: " << e.what());
    }
}

}  // namespace services
}  // namespace robot_control
