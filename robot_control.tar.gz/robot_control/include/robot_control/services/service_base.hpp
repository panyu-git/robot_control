#pragma once

#include <map>
#include <optional>
#include <string>

#include "robot_control/common/logging.hpp"

namespace robot_control {
namespace services {

enum class ServiceStatus { UNINITIALIZED, READY, BUSY, ERROR, STOPPED };

inline std::string toString(ServiceStatus status) {
    switch (status) {
        case ServiceStatus::UNINITIALIZED:
            return "UNINITIALIZED";
        case ServiceStatus::READY:
            return "READY";
        case ServiceStatus::BUSY:
            return "BUSY";
        case ServiceStatus::ERROR:
            return "ERROR";
        case ServiceStatus::STOPPED:
            return "STOPPED";
        default:
            return "UNKNOWN";
    }
}

class ServiceBase {
   public:
    ServiceBase(const std::string& name, bool simulated = true);
    virtual ~ServiceBase() = default;

    // Properties
    std::string name() const {
        return _name;
    }
    ServiceStatus status() const {
        return _status;
    }
    bool isReady() const {
        return _status == ServiceStatus::READY;
    }
    bool isSimulated() const {
        return _simulated;
    }
    std::optional<std::string> errorMessage() const {
        return _errorMsg;
    }

    // Lifecycle methods
    bool initialize();
    void shutdown();
    bool reset();

    // Status information
    std::map<std::string, std::string> getStatusInfo() const;

   protected:
    // Pure virtual methods to be implemented by subclasses
    virtual bool _doInitialize() = 0;
    virtual void _doShutdown() = 0;

    // Protected members
    std::string _name;
    bool _simulated;
    ServiceStatus _status;
    std::optional<std::string> _errorMsg;
    std::string _logger_name;  // For logging identification
};

}  // namespace services
}  // namespace robot_control
