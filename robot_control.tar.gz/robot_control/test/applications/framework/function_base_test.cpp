#include "robot_control/applications/framework/function_base.hpp"

#include <gtest/gtest.h>

#include <memory>
#include <optional>

#include "robot_control/core/blackboard.hpp"
#include "robot_control/core/enums.hpp"

namespace robot_control::applications::framework::test {

class DummyFunction : public Function {
   public:
    DummyFunction(std::shared_ptr<core::Blackboard> blackboard, core::FunctionType type,
                  core::FunctionPriority priority)
        : Function(blackboard), _type(type), _priority(priority) {}

    core::FunctionType functionType() const override {
        return _type;
    }

    core::FunctionPriority priority() const override {
        return _priority;
    }

    void onEnter(const std::optional<std::map<std::string, std::any>>& /*context*/) override {
        _status = core::FunctionStatus::RUNNING;
    }

    std::optional<std::map<std::string, std::any>> onExit() override {
        _status = core::FunctionStatus::IDLE;
        return std::nullopt;
    }

    core::FunctionStatus postTick() override {
        return _status;
    }

    void setStatus(core::FunctionStatus status) {
        _status = status;
    }

   private:
    core::FunctionType _type;
    core::FunctionPriority _priority;
};

TEST(FunctionComparisonTest, CompareFunctionWithEnums) {
    auto blackboard = std::make_shared<core::Blackboard>();
    DummyFunction func(blackboard, core::FunctionType::FOLLOW, core::FunctionPriority::NORMAL);
    func.setStatus(core::FunctionStatus::RUNNING);

    EXPECT_TRUE(func == core::FunctionType::FOLLOW);
    EXPECT_TRUE(func != core::FunctionType::WAKEUP);
    EXPECT_TRUE(func == core::FunctionPriority::NORMAL);
    EXPECT_TRUE(func != core::FunctionPriority::LOW);
    EXPECT_TRUE(func == core::FunctionStatus::RUNNING);
    EXPECT_TRUE(func != core::FunctionStatus::FAILED);
}

TEST(FunctionComparisonTest, CompareEnumsWithFunction) {
    auto blackboard = std::make_shared<core::Blackboard>();
    DummyFunction func(blackboard, core::FunctionType::WAKEUP, core::FunctionPriority::CRITICAL);
    func.setStatus(core::FunctionStatus::INITIALIZING);

    EXPECT_TRUE(core::FunctionType::WAKEUP == func);
    EXPECT_TRUE(core::FunctionType::FOLLOW != func);
    EXPECT_TRUE(core::FunctionPriority::CRITICAL == func);
    EXPECT_TRUE(core::FunctionPriority::LOW != func);
    EXPECT_TRUE(core::FunctionStatus::INITIALIZING == func);
    EXPECT_TRUE(core::FunctionStatus::COMPLETED != func);
}

TEST(FunctionComparisonTest, CompareNullFunctionPointerWithEnums) {
    Function* null_func = nullptr;

    EXPECT_FALSE(null_func == core::FunctionType::IDLE);
    EXPECT_TRUE(null_func != core::FunctionType::IDLE);
    EXPECT_FALSE(null_func == core::FunctionPriority::LOW);
    EXPECT_TRUE(null_func != core::FunctionPriority::LOW);
    EXPECT_FALSE(null_func == core::FunctionStatus::RUNNING);
    EXPECT_TRUE(null_func != core::FunctionStatus::RUNNING);

    EXPECT_FALSE(core::FunctionType::IDLE == null_func);
    EXPECT_TRUE(core::FunctionType::IDLE != null_func);
    EXPECT_FALSE(core::FunctionPriority::LOW == null_func);
    EXPECT_TRUE(core::FunctionPriority::LOW != null_func);
    EXPECT_FALSE(core::FunctionStatus::RUNNING == null_func);
    EXPECT_TRUE(core::FunctionStatus::RUNNING != null_func);
}

TEST(FunctionComparisonTest, CompareValidFunctionPointerWithEnums) {
    auto blackboard = std::make_shared<core::Blackboard>();
    DummyFunction func(blackboard, core::FunctionType::IDLE, core::FunctionPriority::LOW);
    func.setStatus(core::FunctionStatus::IDLE);
    Function* ptr = &func;

    EXPECT_TRUE(ptr == core::FunctionType::IDLE);
    EXPECT_TRUE(ptr != core::FunctionType::FOLLOW);
    EXPECT_TRUE(ptr == core::FunctionPriority::LOW);
    EXPECT_TRUE(ptr != core::FunctionPriority::CRITICAL);
    EXPECT_TRUE(ptr == core::FunctionStatus::IDLE);
    EXPECT_TRUE(ptr != core::FunctionStatus::RUNNING);
}

TEST(FunctionComparisonTest, FromJsonAcceptsStringSchedulerPriority) {
    auto blackboard = std::make_shared<core::Blackboard>();
    DummyFunction func(blackboard, core::FunctionType::FOLLOW, core::FunctionPriority::LOW);

    Function::json payload = {{"function_id", "f-1"},
                              {"function_name", "follow_1"},
                              {"status", "RUNNING"},
                              {"scheduler_priority", "CRITICAL"}};
    func.fromJson(payload);

    EXPECT_EQ(func.functionId(), "f-1");
    EXPECT_EQ(func.functionName(), "follow_1");
    EXPECT_EQ(func.status(), core::FunctionStatus::RUNNING);
    EXPECT_EQ(func.schedulerPriority(), static_cast<int>(core::FunctionPriority::CRITICAL));
}

TEST(FunctionComparisonTest, FromJsonIgnoresMalformedFieldsWithoutThrowing) {
    auto blackboard = std::make_shared<core::Blackboard>();
    DummyFunction func(blackboard, core::FunctionType::FOLLOW, core::FunctionPriority::NORMAL);
    func.setFunctionId("original-id");
    func.setFunctionName("original-name");
    func.setStatus(core::FunctionStatus::PAUSED);
    func.setSchedulerPriority(123);

    Function::json malformed = {{"function_id", 12345},
                                {"function_name", {"not", "string"}},
                                {"status", "BAD_STATUS"},
                                {"scheduler_priority", "BAD_PRIORITY"}};
    EXPECT_NO_THROW(func.fromJson(malformed));

    EXPECT_EQ(func.functionId(), "original-id");
    EXPECT_EQ(func.functionName(), "original-name");
    EXPECT_EQ(func.status(), core::FunctionStatus::PAUSED);
    EXPECT_EQ(func.schedulerPriority(), 123);
}

}  // namespace robot_control::applications::framework::test
