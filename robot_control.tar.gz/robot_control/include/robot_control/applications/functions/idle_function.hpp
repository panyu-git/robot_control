#pragma once

#include "robot_control/applications/framework/function_base.hpp"

namespace robot_control {
namespace applications {
namespace functions {

class IdleFunction : public framework::Function {
   public:
    IdleFunction(std::shared_ptr<core::Blackboard> blackboard);

    core::FunctionType functionType() const override;
    core::FunctionPriority priority() const override;

    void onEnter(const std::optional<std::map<std::string, std::any>>& context = std::nullopt) override;
    std::optional<std::map<std::string, std::any>> onExit() override;
    std::optional<std::map<std::string, std::any>> onPause() override;
    void onResume(const std::map<std::string, std::any>& context) override;

    core::FunctionStatus preTick() override {
        return _status;
    }
    core::FunctionStatus postTick() override;
};

}  // namespace functions
}  // namespace applications
}  // namespace robot_control
