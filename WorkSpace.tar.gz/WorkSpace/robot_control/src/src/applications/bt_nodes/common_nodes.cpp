#include "robot_control/applications/bt_nodes/common_nodes.hpp"

#include <algorithm>
#include <cctype>
#include <chrono>
#include <fstream>
#include <string>
#include <vector>

#include "behaviortree_cpp/contrib/magic_enum.hpp"
#include "robot_control/common/logging.hpp"
#include "robot_control/core/events.hpp"
#include "robot_control/core/robot_control_configs.hpp"
#include "robot_control/core/enums.hpp"
#include "robot_control/common/blackboard/black_board.hpp"

#if defined(__linux__)
#include <time.h>
#ifndef CLOCK_BOOTTIME
#define CLOCK_BOOTTIME 7
#endif
#endif

namespace robot_control {
namespace applications {
namespace bt_nodes {

namespace {

constexpr const char* kLoggerPublishEvent = "PublishToEventBus";
constexpr const char* kLoggerPublishState = "PublishFuncState";

std::string strip_whitespace(std::string s) {
    const auto not_space = [](unsigned char c) { return std::isspace(c) == 0; };
    s.erase(s.begin(), std::find_if(s.begin(), s.end(), not_space));
    s.erase(std::find_if(s.rbegin(), s.rend(), not_space).base(), s.end());
    return s;
}

}  // namespace

std::int64_t millis_since_system_boot() {
#if defined(__linux__)
    struct timespec ts {};
    if (clock_gettime(CLOCK_BOOTTIME, &ts) == 0) {
        return static_cast<std::int64_t>(ts.tv_sec) * 1000 + static_cast<std::int64_t>(ts.tv_nsec / 1000000);
    }
    std::ifstream in("/proc/uptime");
    double up = 0.0;
    double idle_unused = 0.0;
    if (in >> up >> idle_unused) {
        return static_cast<std::int64_t>(up * 1000.0);
    }
#endif
    static const std::chrono::steady_clock::time_point t0 = std::chrono::steady_clock::now();
    return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - t0).count();
}

BT::NodeStatus PublishToEventBus::tick() {
    const auto ev_type = getInput<core::EventType>("event_type");
    const auto source = getInput<std::string>("source");
    const auto data_raw = getInput<std::string>("data");

    if (!ev_type || !source || !data_raw) {
        LOG_ERROR_NAMED(kLoggerPublishEvent, "missing input port");
        return BT::NodeStatus::FAILURE;
    }

    std::vector<std::string> items;
    std::string current;
    for (char c : *data_raw) {
        if (c == ';') {
            if (!current.empty()) {
                items.push_back(current);
                current.clear();
            }
        } else {
            current.push_back(c);
        }
    }
    if (!current.empty()) {
        items.push_back(current);
    }

    core::Event ev(*ev_type, *source);
    for (size_t i = 0; i < items.size(); ++i) {
        const std::string& el = items[i];
        const std::size_t colon = el.find(':');
        if (colon == std::string::npos) {
            LOG_ERROR_NAMED(kLoggerPublishEvent, "data element #" << i << " has no ':' delimiter");
            return BT::NodeStatus::FAILURE;
        }
        std::string key = strip_whitespace(el.substr(0, colon));
        std::string val = strip_whitespace(el.substr(colon + 1));
        if (key.empty()) {
            return BT::NodeStatus::FAILURE;
        }
        ev.data[std::move(key)] = std::move(val);
    }

    LOG_DEBUG_NAMED(kLoggerPublishEvent, "event_type=" << magic_enum::enum_name(*ev_type));
    core::EventBus::getInstance().publish(ev);
    return BT::NodeStatus::SUCCESS;
}

BT::NodeStatus PublishFuncState::tick() {
    const auto user_id = getInput<std::string>("user_id");
    const auto func_type = getInput<core::FunctionType>("type");
    const auto stage = getInput<core::MountupStage>("stage");
    const auto status = getInput<core::FunctionStatus>("status");
    const auto error_code = getInput<uint16_t>("error_code");

    if (!user_id || !func_type || !stage || !status || !error_code) {
        LOG_ERROR_NAMED(kLoggerPublishState, "missing input port");
        return BT::NodeStatus::FAILURE;
    }

    LOG_DEBUG_NAMED(kLoggerPublishState,
                    "user_id=" << *user_id << " type=" << magic_enum::enum_name(*func_type)
                               << " stage=" << magic_enum::enum_name(*stage)
                               << " status=" << magic_enum::enum_name(*status)
                               << " error_code=" << *error_code);
    bbd::Pub(core::BlackboardKeys::BT_PUB_FUNCTION_STATE,
             *user_id, *func_type, *stage, *status, *error_code);
    return BT::NodeStatus::SUCCESS;
}

BT::NodeStatus GrabBootupTime::tick() {
    setOutput("ms", millis_since_system_boot());
    return BT::NodeStatus::SUCCESS;
}

void registerCommonNodes(BT::BehaviorTreeFactory& factory) {
    factory.registerNodeType<PublishToEventBus>("PublishToEventBus");
    factory.registerNodeType<PublishFuncState>("PublishFuncState");
    factory.registerNodeType<GrabBootupTime>("GrabBootupTime");
}

}  // namespace bt_nodes
}  // namespace applications
}  // namespace robot_control
