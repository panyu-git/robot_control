#include <cstdlib>

#include "robot_control/applications/interfaces/robot_controller_node.hpp"
#include "robot_control/common/logging.hpp"
#include "segar/segar.h"

int main([[maybe_unused]] int argc, char* argv[]) {
    // Initialize Segar
    if (!rti::segar::Init(argv[0])) {
        return EXIT_FAILURE;
    }

    auto node = std::make_shared<robot_control::applications::interfaces::RobotControllerNode>();

    if (!node->init()) {
        LOG_ERROR_NAMED("Main", "Failed to initialize RobotControllerNode");
        return EXIT_FAILURE;
    }

    LOG_INFO_NAMED("Main", "Robot Control Node started. Waiting for shutdown...");

    // Segar handles its own execution threads inside the Node/Middleware
    rti::segar::WaitForShutdown();

    node->shutdown();

    return EXIT_SUCCESS;
}
