#include "robot_control/services/navigation_service.hpp"

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cmath>
#include <sstream>

#include "robot_control/common/logging.hpp"
#include "robot_control/utils/logic_utils.hpp"
#include "segar/time/clock.h"

namespace robot_control {
namespace services {

NavigationService::NavigationService(bool simulated)
    : ServiceBase("NavigationService", simulated),
      _status_nav(core::NavigationStatus::IDLE),
      _mode(NavigationMode::IDLE),
      _last_follow_trace_time(0.0),
      _last_nav_feedback_time(0.0),
      _last_nav_timeout_warn_time(0.0),
      _nav_goal_status(GoalStatus::UNKNOWN),
      _current_goal_id(0) {}

NavigationService::~NavigationService() {
    _doShutdown();
}

void NavigationService::init(std::shared_ptr<rti::segar::Node> node) {
    _node = node;
    if (_node) {
        ActionClient::GoalCallbacks callbacks;
        callbacks.on_feedback = [this](ActionClient&, const rti::segar::action::GoalID& goal_id,
                                       const nav_interfaces::action::NavTaskJson::Feedback& feedback) {
            {
                std::lock_guard<std::mutex> lock(_mutex);
                if (goal_id != _active_goal_id) return;
            }

            _processNavStatusJson(feedback.feedback_json());

            std::lock_guard<std::mutex> lock(_mutex);
            double now = rti::segar::Clock::Now().ToSecond();
            // Original logging logic with 2s throttle
            static double last_nav_feedback_log_time = 0.0;
            if (now - last_nav_feedback_log_time >= 2.0) {
                LOG_INFO("[feedback] user_id=" << _follow_params["user_id"] << ", feedback_json="
                                               << feedback.feedback_json() << ", goal_id=" << _current_goal_id);
                last_nav_feedback_log_time = now;
            }
        };

        callbacks.on_result = [this](ActionClient&, const rti::segar::action::GoalID& goal_id,
                                     [[maybe_unused]] const nav_interfaces::action::NavTaskJson::Result& result,
                                     rti::segar::action::GoalStatusCode status) {
            std::string code_str = "UNKNOWN";
            switch (status) {
                case rti::segar::action::GoalStatusCode::STATUS_SUCCEEDED:
                    code_str = "SUCCEEDED";
                    break;
                case rti::segar::action::GoalStatusCode::STATUS_CANCELED:
                    code_str = "CANCELED";
                    break;
                case rti::segar::action::GoalStatusCode::STATUS_ABORTED:
                    code_str = "ABORTED";
                    break;
                default:
                    break;
            }

            bool nav_result_success = result.success();
            std::string nav_result_json = result.result_json();

            LOG_INFO("[result] action_code="
                     << code_str << ", nav_result_success=" << (nav_result_success ? "true" : "false")
                     << ", nav_result_json=" << (nav_result_json.empty() ? "<empty>" : nav_result_json)
                     << ", goal_id=" << _current_goal_id);

            std::lock_guard<std::mutex> lock(_mutex);
            if (goal_id != _active_goal_id) {
                LOG_WARN("[NAV] result_callback: ignoring stale result");
                return;
            }

            bool success = (status == rti::segar::action::GoalStatusCode::STATUS_SUCCEEDED);
            _nav_goal_status =
                success ? GoalStatus::SUCCEEDED
                        : (status == rti::segar::action::GoalStatusCode::STATUS_CANCELED ? GoalStatus::CANCELED
                                                                                         : GoalStatus::ABORTED);
            _status_nav = success ? core::NavigationStatus::IDLE : core::NavigationStatus::FAILED;
            _mode = NavigationMode::IDLE;

            if (_navigation_complete_callback) _navigation_complete_callback(success);
        };

        rti::segar::action::ActionOptions action_options;
        action_options.wait_result_timeout_ms = 3600000.0;  // 1 hour timeout for result
        _nav_client = _node->CreateActionClient<nav_interfaces::action::NavTaskJson>("nav_task_request", callbacks,
                                                                                     action_options);
        _follow_task_pub = _node->CreateWriter<nav_interfaces::msg::FollowTask>("nav_task_request");
        LOG_INFO("Segar Action Client and Publisher initialized for navigation");
    }
    initialize();
}

bool NavigationService::_doInitialize() {
    LOG_INFO("[NAV] Initializing navigation service interfaces...");
    // Segar action client doesn't have wait_for_action_server in the same way,
    // but we can assume initialization is successful if CreateActionClient returned a valid pointer.
    return true;
}

void NavigationService::_doShutdown() {
    stopFollow();
    _nav_client.reset();
    _follow_task_pub.reset();
}

bool NavigationService::startFollow(const std::string& mode, double distance, double speed,
                                    const std::string& user_id) {
    if (_status != ServiceStatus::READY) {
        LOG_ERROR("Service not ready");
        return false;
    }

    LOG_INFO("Starting follow: mode=" << mode << ", distance=" << distance << ", speed=" << speed);

    double now = rti::segar::Clock::Now().ToSecond();

    {
        std::lock_guard<std::mutex> lock(_mutex);
        _follow_params["mode"] = mode;
        _follow_params["task_name"] = "FOLLOW_TASK";
        _follow_params["request_start"] = "true";
        _follow_params["user_id"] = user_id;
        _follow_params["param_follow_dis_m"] = std::to_string(distance);
        _follow_params["param_speed_ms"] = std::to_string(speed);
        _follow_params["param_follow_dir"] = (mode == "left") ? "1" : ((mode == "right") ? "2" : "0");
        _follow_params["start_time"] = std::to_string(now);
        _last_follow_trace_time = now;
        _last_nav_feedback_time = now;
        _target_timeout = std::nullopt;
        _mode = NavigationMode::FOLLOW_HUMAN;
        _status_nav = core::NavigationStatus::RUNNING;
    }

    std::map<std::string, std::string> task_params;
    task_params["request_start"] = "true";
    task_params["param_speed_ms"] = std::to_string(speed);
    task_params["param_follow_dis_m"] = std::to_string(distance);
    task_params["param_follow_dir"] = (mode == "left") ? "1" : ((mode == "right") ? "2" : "0");
    bool nav_ok = requestFollowTask("FOLLOW_TASK", user_id, task_params);
    if (!nav_ok) {
        LOG_WARN("startFollow failed to dispatch FOLLOW_TASK");
    }
    return nav_ok;
}

bool NavigationService::requestFollowTask(const std::string& task, const std::string& user_id,
                                          const std::map<std::string, std::string>& params) {
    if (_status != ServiceStatus::READY) {
        LOG_ERROR("requestFollowTask: Navigation service status is " << static_cast<int>(_status) << ", not READY");
        return false;
    }
    if (user_id.empty()) {
        LOG_ERROR("requestFollowTask: user_id is empty");
        return false;
    }

    uint64_t goal_id = 0;
    {
        std::lock_guard<std::mutex> lock(_mutex);
        _nav_goal_status = GoalStatus::UNKNOWN;
        _current_goal_id++;
        goal_id = _current_goal_id;
        LOG_INFO("[NAV] requestFollowTask: task=" << task << ", goal_id=" << goal_id);
    }

    auto request_start_it = params.find("request_start");
    bool request_start = true;
    if (request_start_it != params.end()) {
        std::string req = request_start_it->second;
        std::transform(req.begin(), req.end(), req.begin(), ::tolower);
        if (req == "false" || req == "0") request_start = false;
    }

    if (request_start) {
        std::lock_guard<std::mutex> lock(_mutex);
        _status_nav = core::NavigationStatus::RUNNING;
    }

    if (!_nav_client) {
        if (task == "FOLLOW_TASK" && !request_start) {
            std::lock_guard<std::mutex> lock(_mutex);
            _status_nav = core::NavigationStatus::IDLE;
            _mode = NavigationMode::IDLE;
            return true;
        }
        LOG_ERROR("Navigation action client is null, cannot dispatch task");
        return false;
    }

    nlohmann::json task_json;
    task_json["task_name"] = task;
    task_json["request_start"] = request_start;

    if (task == "ROTATE_TASK") {
        std::string target_yaw_s = "";
        auto yaw_it = params.find("target_yaw");
        if (yaw_it != params.end() && !yaw_it->second.empty()) {
            target_yaw_s = yaw_it->second;
        } else {
            auto angle_it = params.find("wakeup_angle");
            if (angle_it != params.end() && !angle_it->second.empty()) {
                target_yaw_s = angle_it->second;
            }
        }
        if (target_yaw_s.empty()) {
            auto rotate_it = params.find("param_rotate_dir");
            if (rotate_it != params.end() && !rotate_it->second.empty()) {
                try {
                    task_json["param_rotate_dir"] = std::stoi(rotate_it->second);
                } catch (...) {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            try {
                task_json["target_yaw"] = static_cast<float>(std::stod(target_yaw_s));
            } catch (...) {
                return false;
            }

            float max_w = 0.5f;
            auto max_it = params.find("max_angular_velocity");
            if (max_it != params.end() && !max_it->second.empty()) {
                try {
                    max_w = static_cast<float>(std::stod(max_it->second));
                } catch (...) {
                }
            }
            task_json["max_angular_velocity"] = max_w;

            float timeout_s = 0.0f;
            auto timeout_it = params.find("timeout");
            if (timeout_it != params.end() && !timeout_it->second.empty()) {
                try {
                    timeout_s = static_cast<float>(std::stod(timeout_it->second));
                } catch (...) {
                }
            }
            task_json["timeout"] = timeout_s;

            auto task_id_it = params.find("task_id");
            if (task_id_it != params.end() && !task_id_it->second.empty()) {
                task_json["task_id"] = task_id_it->second;
            }
        }

        {
            std::lock_guard<std::mutex> lock(_mutex);
            _follow_params["task_name"] = "ROTATE_TASK";
            _follow_params["user_id"] = user_id;
            _mode = NavigationMode::NAVIGATE_TO_POSE;
            _last_nav_feedback_time = rti::segar::Clock::Now().ToSecond();
            _target_timeout = std::nullopt;
            _status_nav = core::NavigationStatus::RUNNING;
        }
    } else if (task == "FOLLOW_TASK") {
        double speed_ms = 1.0;
        double follow_dis_m = 1.0;
        int follow_dir = 0;

        auto speed_it = params.find("param_speed_ms");
        if (speed_it != params.end()) try {
                speed_ms = std::stod(speed_it->second);
            } catch (...) {
            }

        auto dis_it = params.find("param_follow_dis_m");
        if (dis_it != params.end()) try {
                follow_dis_m = std::stod(dis_it->second);
            } catch (...) {
            }

        auto dir_it = params.find("param_follow_dir");
        if (dir_it != params.end()) try {
                follow_dir = std::stoi(dir_it->second);
            } catch (...) {
            }

        task_json["param_speed_ms"] = speed_ms;
        task_json["param_follow_dis_m"] = follow_dis_m;
        task_json["param_follow_dir"] = follow_dir;

        {
            std::lock_guard<std::mutex> lock(_mutex);
            _follow_params["task_name"] = "FOLLOW_TASK";
            _follow_params["request_start"] = request_start ? "true" : "false";
            _follow_params["user_id"] = user_id;
            _follow_params["param_speed_ms"] = std::to_string(speed_ms);
            _follow_params["param_follow_dis_m"] = std::to_string(follow_dis_m);
            _follow_params["param_follow_dir"] = std::to_string(follow_dir);
            _follow_params["mode"] = (follow_dir == 1) ? "left" : ((follow_dir == 2) ? "right" : "center");
            _mode = NavigationMode::FOLLOW_HUMAN;
            _last_nav_feedback_time = rti::segar::Clock::Now().ToSecond();
            _target_timeout = std::nullopt;
            _status_nav = request_start ? core::NavigationStatus::RUNNING : core::NavigationStatus::IDLE;
        }
    } else {
        return false;
    }

    nav_interfaces::action::NavTaskJson::Goal goal;
    goal.task_json(task_json.dump());

    LOG_INFO("[dispatch][" << task << "] user_id=" << user_id << ", request_start="
                           << (request_start ? "true" : "false") << ", task_json=" << goal.task_json());

    _nav_client->AsyncSendGoal(goal, &_active_goal_id);
    return true;
}

bool NavigationService::updateFollowParams(std::optional<double> distance, std::optional<double> speed) {
    std::string user_id;
    std::string mode = "center";
    double current_distance = 1.0;
    double current_speed = 1.0;
    {
        std::lock_guard<std::mutex> lock(_mutex);
        if (_follow_params.empty()) return false;
        if (distance.has_value()) _follow_params["param_follow_dis_m"] = std::to_string(distance.value());
        if (speed.has_value()) _follow_params["param_speed_ms"] = std::to_string(speed.value());

        auto uid_it = _follow_params.find("user_id");
        if (uid_it != _follow_params.end()) user_id = uid_it->second;
        if (_follow_params.count("mode") > 0) mode = _follow_params["mode"];
        if (_follow_params.count("param_follow_dis_m") > 0) try {
                current_distance = std::stod(_follow_params["param_follow_dis_m"]);
            } catch (...) {
            }
        if (_follow_params.count("param_speed_ms") > 0) try {
                current_speed = std::stod(_follow_params["param_speed_ms"]);
            } catch (...) {
            }
    }

    if (user_id.empty()) {
        LOG_WARN("updateFollowParams skipped topic dispatch: user_id is empty");
        return false;
    }
    if (!_follow_task_pub) {
        LOG_WARN("updateFollowParams skipped topic dispatch: nav_task_request publisher not ready");
        return false;
    }

    auto msg = std::make_shared<nav_interfaces::msg::FollowTask>();
    msg->target_id(user_id);
    msg->position(nav_interfaces::msg::FollowTask_Constants::POSITION_CUSTOM);
    if (mode == "left")
        msg->position(nav_interfaces::msg::FollowTask_Constants::POSITION_LEFT);
    else if (mode == "right")
        msg->position(nav_interfaces::msg::FollowTask_Constants::POSITION_RIGHT);
    else if (mode == "back")
        msg->position(nav_interfaces::msg::FollowTask_Constants::POSITION_BACK);

    msg->position_offset_x(0.0f);
    msg->position_offset_y(0.0f);
    msg->speed_level(nav_interfaces::msg::FollowTask_Constants::SPEED_CUSTOM);
    msg->velocity(static_cast<float>(current_speed));
    msg->distance_level(nav_interfaces::msg::FollowTask_Constants::DISTANCE_CUSTOM);
    if (current_distance <= 0.75)
        msg->distance_level(nav_interfaces::msg::FollowTask_Constants::DISTANCE_CLOSE);
    else if (current_distance <= 1.25)
        msg->distance_level(nav_interfaces::msg::FollowTask_Constants::DISTANCE_MEDIUM);
    else if (current_distance <= 1.75)
        msg->distance_level(nav_interfaces::msg::FollowTask_Constants::DISTANCE_FAR);
    else
        msg->distance_level(nav_interfaces::msg::FollowTask_Constants::DISTANCE_VERY_FAR);

    msg->follow_distance(static_cast<float>(current_distance));
    msg->timeout(0.0f);
    _follow_task_pub->Write(msg);
    return true;
}

bool NavigationService::updateFollowPosition(const std::string& mode) {
    {
        std::lock_guard<std::mutex> lock(_mutex);
        if (_follow_params.empty()) return false;
        _follow_params["mode"] = mode;
        _follow_params["param_follow_dir"] = (mode == "left") ? "1" : ((mode == "right") ? "2" : "0");
    }
    return updateFollowParams(std::nullopt, std::nullopt);
}

void NavigationService::stopFollow() {
    LOG_INFO("[NAV] Stopping follow: cancel nav_task_request action");
    cancelNavigation();

    std::lock_guard<std::mutex> lock(_mutex);
    _status_nav = core::NavigationStatus::IDLE;
    _mode = NavigationMode::IDLE;
    _last_follow_trace_time = 0.0;
    _last_nav_feedback_time = 0.0;
    _target_timeout = std::nullopt;
    LOG_INFO("stopFollow completed, state set to IDLE");
}

std::map<std::string, std::string> NavigationService::pauseFollow() {
    LOG_INFO("[NAV] Pausing follow");
    double now = rti::segar::Clock::Now().ToSecond();
    std::lock_guard<std::mutex> lock(_mutex);
    std::map<std::string, std::string> context;
    context["params"] = "";
    context["paused_at"] = std::to_string(now);
    _status_nav = core::NavigationStatus::RUNNING;
    return context;
}

bool NavigationService::resumeFollow(const std::map<std::string, std::string>& context) {
    LOG_INFO("Resuming follow");
    (void)context;
    std::string mode = "center";
    double distance = 1.5;
    double speed = 0.5;
    std::string user_id;

    {
        std::lock_guard<std::mutex> lock(_mutex);
        if (_follow_params.count("mode")) mode = _follow_params.at("mode");
        if (_follow_params.count("param_follow_dis_m")) distance = std::stod(_follow_params.at("param_follow_dis_m"));
        if (_follow_params.count("param_speed_ms")) speed = std::stod(_follow_params.at("param_speed_ms"));
        if (_follow_params.count("user_id")) user_id = _follow_params.at("user_id");
    }

    if (user_id.empty()) {
        LOG_ERROR("Cannot resume: user_id unknown");
        return false;
    }
    return startFollow(mode, distance, speed, user_id);
}

void NavigationService::resetFollowState() {
    std::lock_guard<std::mutex> lock(_mutex);
    _follow_params.clear();
    _last_nav_feedback_time = rti::segar::Clock::Now().ToSecond();
    _target_timeout = std::nullopt;
    _status_nav = core::NavigationStatus::IDLE;
    _mode = NavigationMode::IDLE;
    LOG_INFO("resetFollowState: state cleared and timestamp reset");
}

core::NavigationStatus NavigationService::update() {
    std::lock_guard<std::mutex> lock(_mutex);
    return _status_nav;
}

bool NavigationService::navigateToLocation(const std::string& name, std::function<void(bool)> callback) {
    if (!_nav_client) return false;
    LOG_INFO("Navigating to location: " << name);
    {
        std::lock_guard<std::mutex> lock(_mutex);
        _current_goal_id++;
        _mode = NavigationMode::NAVIGATE_TO_LOCATION;
        _goal_location = name;
        _navigation_complete_callback = callback;
        _last_nav_feedback_time = rti::segar::Clock::Now().ToSecond();
        _status_nav = core::NavigationStatus::RUNNING;
        _nav_goal_status = GoalStatus::UNKNOWN;
        _target_timeout = std::nullopt;
    }

    nlohmann::json task_json;
    task_json["task_name"] = "NAV_LOCATION";
    task_json["location_name"] = name;

    nav_interfaces::action::NavTaskJson::Goal goal;
    goal.task_json(task_json.dump());

    _nav_client->AsyncSendGoal(goal, &_active_goal_id);
    return true;
}

bool NavigationService::navigateToPose(double x, double y, double theta, std::function<void(bool)> callback) {
    if (!_nav_client) return false;
    LOG_INFO("Navigating to pose: x=" << x << ", y=" << y << ", theta=" << theta);
    {
        std::lock_guard<std::mutex> lock(_mutex);
        _current_goal_id++;
        _mode = NavigationMode::NAVIGATE_TO_POSE;
        _navigation_complete_callback = callback;
        _last_nav_feedback_time = rti::segar::Clock::Now().ToSecond();
        _status_nav = core::NavigationStatus::RUNNING;
        _nav_goal_status = GoalStatus::UNKNOWN;
        _target_timeout = std::nullopt;
    }

    nlohmann::json task_json;
    task_json["task_name"] = "NAV_POSE";
    task_json["target_x"] = x;
    task_json["target_y"] = y;
    task_json["target_theta"] = theta;

    nav_interfaces::action::NavTaskJson::Goal goal;
    goal.task_json(task_json.dump());

    _nav_client->AsyncSendGoal(goal, &_active_goal_id);
    return true;
}

bool NavigationService::isNavFeedbackFresh(int64_t timeout_ms) const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _isNavFeedbackFresh(timeout_ms);
}

bool NavigationService::_isNavFeedbackFresh(int64_t timeout_ms) const {
    return !utils::LogicUtils::IsTimeoutMs(_last_nav_feedback_time, timeout_ms);
}

bool NavigationService::navigateToChargingStation(std::function<void(bool)> callback) {
    return navigateToLocation("charging_station", callback);
}

bool NavigationService::cancelNavigation() {
    if (!_nav_client) {
        LOG_WARN("[NAV] cancelNavigation: nav_task_request client is null");
        return false;
    }

    {
        std::lock_guard<std::mutex> lock(_mutex);
        if (_mode == NavigationMode::IDLE) return true;
        _current_goal_id++;
        _nav_goal_status = GoalStatus::CANCELED;
        _mode = NavigationMode::IDLE;
        _status_nav = core::NavigationStatus::IDLE;
    }

    _nav_client->AsyncCancelGoal(_active_goal_id);
    return true;
}

bool NavigationService::isReady() const {
    return _status == ServiceStatus::READY;
}

bool NavigationService::isNavServerOnline() const {
    if (!_nav_client) return false;
    return true;
}

bool NavigationService::isNavigationComplete() const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _isNavigationComplete();
}

bool NavigationService::_isNavigationComplete() const {
    return _nav_goal_status == GoalStatus::SUCCEEDED || _nav_goal_status == GoalStatus::CANCELED ||
           _nav_goal_status == GoalStatus::ABORTED;
}

bool NavigationService::isNavigationSuccessful() const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _isNavigationSuccessful();
}

bool NavigationService::_isNavigationSuccessful() const {
    return _nav_goal_status == GoalStatus::SUCCEEDED;
}

core::NavigationStatus NavigationService::navigationStatus() const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _navigationStatus();
}

core::NavigationStatus NavigationService::_navigationStatus() const {
    return _status_nav;
}

bool NavigationService::isNavFeedbackInterrupted() const {
    std::lock_guard<std::mutex> lock(_mutex);
    if (_mode != NavigationMode::FOLLOW_HUMAN) return false;
    return !_isNavFeedbackFresh(3000);
}

double NavigationService::getLastNavFeedbackTime() const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _last_nav_feedback_time;
}

std::optional<double> NavigationService::getTargetTimeout() const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _target_timeout;
}

std::tuple<double, double, double> NavigationService::currentPose() const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _currentPose();
}

std::tuple<double, double, double> NavigationService::_currentPose() const {
    return std::make_tuple(_current_pose.x(), _current_pose.y(), _current_pose.theta());
}

std::map<std::string, std::string> NavigationService::getFeedback() const {
    std::lock_guard<std::mutex> lock(_mutex);
    std::map<std::string, std::string> feedback;

    auto nav_status = _navigationStatus();
    feedback["status"] = std::to_string(static_cast<int>(nav_status));

    bool fresh = _isNavFeedbackFresh(3000);
    feedback["nav_mode"] = std::to_string(static_cast<int>(_mode));
    feedback["nav_goal_status"] = std::to_string(static_cast<int>(_nav_goal_status));
    feedback["task_state"] = fresh ? _last_task_state : "";
    feedback["task_message"] = fresh ? _last_task_message : "Navigation timeout";

    if (_target_timeout.has_value()) {
        feedback["target_timeout"] = std::to_string(_target_timeout.value());
    }

    auto pose = _currentPose();
    std::ostringstream oss2;
    oss2 << std::get<0>(pose) << "," << std::get<1>(pose) << "," << std::get<2>(pose);
    feedback["current_pose"] = oss2.str();

    return feedback;
}

void NavigationService::_processNavStatusJson(const std::string& json_str) {
    try {
        auto j = nlohmann::json::parse(json_str);
        std::string task_name = j.value("task_name", "");
        std::string task_state = "";

        if (j.contains("task_state")) {
            if (j["task_state"].is_string())
                task_state = j["task_state"];
            else if (j["task_state"].is_number())
                task_state = std::to_string(j["task_state"].get<int>());
        } else if (j.contains("status") && j["status"].is_string()) {
            task_state = j["status"];
        }

        std::string message = j.value("message", "");

        {
            std::lock_guard<std::mutex> lock(_mutex);
            bool changed =
                (task_name != _last_task_name || task_state != _last_task_state || message != _last_task_message);
            if (changed) {
                static auto last_status_log_time = std::chrono::steady_clock::now();
                auto now = std::chrono::steady_clock::now();
                if (std::chrono::duration<double>(now - last_status_log_time).count() >= 1.0) {
                    LOG_INFO("Received nav status: task=" << task_name << ", state=" << task_state
                                                          << ", msg=" << message);
                    last_status_log_time = now;
                }
            }

            _last_nav_feedback_time = rti::segar::Clock::Now().ToSecond();
            _last_task_name = task_name;
            _last_task_state = task_state;
            _last_task_message = message;

            if (j.contains("progress") && j["progress"].is_object()) {
                if (j["progress"].contains("target_timeout")) {
                    _target_timeout = j["progress"]["target_timeout"].get<double>();
                    if (_target_timeout.value() > 0.1) {
                        LOG_INFO_NAMED("NavigationService", "Parsed target_timeout: " << _target_timeout.value());
                    }
                } else {
                    _target_timeout = std::nullopt;
                }
            } else {
                _target_timeout = std::nullopt;
            }

            if (changed && task_name == "ROTATE_TASK" && task_state == "COMPLETED") {
                LOG_INFO("[NAV] ROTATE_TASK completed.");
            }
        }
    } catch (const std::exception& e) {
        LOG_ERROR("Failed to parse nav status JSON: " << e.what());
    }
}

bool NavigationService::stopNavigation() {
    return cancelNavigation();
}

}  // namespace services
}  // namespace robot_control
