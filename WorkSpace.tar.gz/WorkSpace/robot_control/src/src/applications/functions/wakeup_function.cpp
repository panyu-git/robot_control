#include "robot_control/applications/functions/wakeup_function.hpp"

#include <cmath>

#include "robot_control/common/logging.hpp"
#include "robot_control/core/enums.hpp"
#include "robot_control/core/robot_control_configs.hpp"
#include "robot_control/services/navigation_service.hpp"

namespace robot_control {
namespace applications {
namespace functions {

WakeupFunction::WakeupFunction(std::shared_ptr<core::Blackboard> blackboard, const interfaces::RobotContext& context)
    : Function(blackboard),
      _mutex(),
      _context(context),
      _target_yaw(),
      _max_angular_velocity("0.5"),
      _timeout(),
      _task_id(),
      _user_id(),
      _wakeup_callback(nullptr) {
    LOG_INFO("WakeupFunction: Initialized");
}

void WakeupFunction::onEnter(const std::optional<std::map<std::string, std::any>>& /*context*/) {
    LOG_INFO("WakeupFunction: Entering wakeup state");

    if (!_context.navigation) {
        LOG_ERROR("WakeupFunction: Navigation service not available");
        _publishInteraction("唤醒失败：导航服务未初始化");
        _status = core::FunctionStatus::FAILED;
        return;
    }

    auto target_yaw = _blackboard->get<std::string>(core::BlackboardKeys::LAST_WAKEUP_TARGET_YAW, "");
    if (target_yaw.empty()) {
        target_yaw = _blackboard->get<std::string>(core::BlackboardKeys::LAST_WAKEUP_WAKEUP_ANGLE, "");
    }

    if (target_yaw.empty()) {
        LOG_ERROR("WakeupFunction: Missing wakeup parameters");
        _publishInteraction("唤醒失败：缺少唤醒参数");
        _status = core::FunctionStatus::FAILED;
        return;
    }

    _wakeup_callback = [this](bool success, const std::string& message) { this->_onWakeupComplete(success, message); };

    LOG_INFO("WakeupFunction: Wakeup initialization completed, waiting for engine tick");
    _blackboard->deleteKey("wakeup_fail_reason");
    _blackboard->set("wakeup_phase", core::WakeupPhase::WAKEUP);
}

std::optional<std::map<std::string, std::any>> WakeupFunction::onExit() {
    LOG_INFO("WakeupFunction: Exiting wakeup state");

    stopWakeup();
    _wakeup_callback = nullptr;

    _status = core::FunctionStatus::IDLE;
    return std::nullopt;
}

core::FunctionStatus WakeupFunction::preTick() {
    auto cmd_status = _checkUserCommands();

    if (_context.navigation) {
        _blackboard->set("nav_status", static_cast<int>(_context.navigation->navigationStatus()));
        _blackboard->set("nav_last_result_success", _context.navigation->isNavigationSuccessful());
    }

    auto health_status = _context.checkHealth(functionType(), _sessionStartTime);
    if (health_status == core::FunctionStatus::FAILED) {
        return health_status;
    }

    return cmd_status;
}

core::FunctionStatus WakeupFunction::_checkUserCommands() {
    if (_blackboard->get<bool>(core::BlackboardKeys::CMD_STOP_REQUEST, false)) {
        LOG_INFO_NAMED("WakeupFunction", "COMPLETED due to cmd_stop_request on blackboard");
        _blackboard->set(core::BlackboardKeys::CMD_STOP_REQUEST, false);
        _status = core::FunctionStatus::COMPLETED;
    }

    return _status;
}

void WakeupFunction::_handleInternalCommands() {
    std::string navigation_cmd = _blackboard->get<std::string>("navigation_cmd", "");
    if (!navigation_cmd.empty()) {
        _blackboard->set("navigation_cmd", std::string(""));
        if (navigation_cmd == "rotate" && _context.navigation) {
            std::string user_id = _blackboard->get<std::string>("navigation_target_user", "");
            std::string target_yaw = _blackboard->get<std::string>("navigation_target_yaw", "");
            std::string max_w = _blackboard->get<std::string>("navigation_max_angular_velocity", "0.5");
            std::string timeout = _blackboard->get<std::string>("navigation_timeout", "");
            std::string task_id = _blackboard->get<std::string>("navigation_task_id", "");

            std::map<std::string, std::string> params;
            params["target_yaw"] = target_yaw;
            params["max_angular_velocity"] = max_w;
            if (!timeout.empty()) params["timeout"] = timeout;
            if (!task_id.empty()) params["task_id"] = task_id;
            params["request_start"] = "true";

            _context.navigation->requestFollowTask("ROTATE_TASK", user_id, params);
        } else if (navigation_cmd == "cancel" && _context.navigation) {
            _context.navigation->cancelNavigation();
        }
    }
}

core::FunctionStatus WakeupFunction::postTick() {
    auto prev_status = _status;
    updateStatusFromEngine();

    _handleInternalCommands();

    auto phase = _blackboard->get<core::WakeupPhase>("wakeup_phase", core::WakeupPhase::IDLE);

    if ((_status == core::FunctionStatus::COMPLETED || _status == core::FunctionStatus::FAILED) &&
        phase != core::WakeupPhase::IDLE) {
        std::string engine_error = _blackboard->get<std::string>("WAKEUP/engine_error", "");
        if (_status == core::FunctionStatus::FAILED && !engine_error.empty()) {
            LOG_ERROR("WakeupFunction: Critical engine error detected: " << engine_error << ". Exiting function.");
        } else {
            _status = core::FunctionStatus::RUNNING;
        }
    }

    if (_status != prev_status) {
        if (_status == core::FunctionStatus::COMPLETED) {
            _onWakeupComplete(true, "唤醒成功，已完成朝向调整");
        } else if (_status == core::FunctionStatus::FAILED) {
            std::string reason = _blackboard->get<std::string>("wakeup_fail_reason", "");
            LOG_WARN("WakeupFunction: FAILED, reason=" << (reason.empty() ? "unknown" : reason));
            std::string msg = "唤醒失败";
            if (reason == "rotate_task_timeout") {
                msg = "唤醒超时，朝向调整未完成";
            } else if (!reason.empty()) {
                msg = "唤醒失败：" + reason;
            }
            _onWakeupComplete(false, msg);
        }
    }

    return _status;
}

bool WakeupFunction::startWakeup(const std::string&, const std::string&, const std::string&, const std::string&,
                                 const std::string&) {
    return true;
}

bool WakeupFunction::stopWakeup() {
    if (_status == core::FunctionStatus::IDLE) return true;
    if (_context.navigation) _context.navigation->cancelNavigation();
    LOG_INFO("WakeupFunction: Wakeup stopped");
    return true;
}

void WakeupFunction::resetWakeupState() {
    _target_yaw.clear();
    _max_angular_velocity = "0.5";
    _timeout.clear();
    _task_id.clear();
    _user_id.clear();
    LOG_INFO("WakeupFunction: State reset");
}

bool WakeupFunction::isWakeupComplete() const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _status == core::FunctionStatus::COMPLETED;
}

bool WakeupFunction::isWakeupFailed() const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _status == core::FunctionStatus::FAILED;
}

bool WakeupFunction::isWakeupTimeout() const {
    std::lock_guard<std::mutex> lock(_mutex);
    std::string reason = _blackboard->get<std::string>("wakeup_fail_reason", "");
    return _status == core::FunctionStatus::FAILED && reason == "rotate_task_timeout";
}

double WakeupFunction::getWakeupElapsedTime() const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _getWakeupElapsedTime();
}

double WakeupFunction::_getWakeupElapsedTime() const {
    auto now = std::chrono::steady_clock::now();
    return std::chrono::duration<double>(now - _sessionStartTime).count();
}

void WakeupFunction::setWakeupCallback(WakeupCallback callback) {
    std::lock_guard<std::mutex> lock(_mutex);
    _wakeup_callback = callback;
}

void WakeupFunction::_onWakeupComplete(bool success, const std::string& message) {
    LOG_INFO("WakeupFunction: Wakeup finalized, success=" << success << ", message=" << message);
    if (success) {
        _publishInteraction(message);
        _publishFeedback(core::EventType::FEEDBACK_WAKE_UP_RELAY, "唤醒成功");
    } else {
        _publishInteraction(message);
    }
}

void WakeupFunction::_publishInteraction(const std::string& message) {
    core::Event interaction_event(core::EventType::HMI_INTERACTION_REQUEST, "WakeupFunction");
    interaction_event.data["message"] = message;
    interaction_event.data["session_id"] = "0";
    core::EventBus::getInstance().publish(interaction_event);
}

void WakeupFunction::_publishFeedback(core::EventType type, const std::string& message) {
    core::Event feedback_event(type, "WakeupFunction");
    if (!message.empty()) feedback_event.data["message"] = message;
    feedback_event.data["session_id"] = "0";
    core::EventBus::getInstance().publish(feedback_event);
}

}  // namespace functions
}  // namespace applications
}  // namespace robot_control
