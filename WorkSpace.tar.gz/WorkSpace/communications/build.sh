#!/bin/bash

set -e

cd "$(dirname "${BASH_SOURCE[0]}")/.."
if [ -n "$REPO_ROOT" ] && [ -d "$REPO_ROOT" ]; then
  echo $REPO_ROOT
fi
echo "Building in $(pwd)..."

colcon build --packages-select base_interfaces account_interface perception_interfaces sensor_interfaces interaction_interfaces locomotion_dds2ros_msgs nav_interfaces mcu_data_interface tp_router_interfaces
