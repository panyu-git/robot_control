#include "robot_control/applications/framework/task_manager.hpp"

#include <iostream>

#include "robot_control/common/logging.hpp"
#include "robot_control/core/enums.hpp"

namespace robot_control {
namespace applications {
namespace framework {

namespace {
core::NodeStatus toNodeStatus(BT::NodeStatus status) {
    switch (status) {
        case BT::NodeStatus::SUCCESS:
            return core::NodeStatus::SUCCESS;
        case BT::NodeStatus::FAILURE:
            return core::NodeStatus::FAILURE;
        case BT::NodeStatus::RUNNING:
            return core::NodeStatus::RUNNING;
        case BT::NodeStatus::IDLE:
            return core::NodeStatus::IDLE;
        case BT::NodeStatus::SKIPPED:
            return core::NodeStatus::SKIPPED;
        default:
            LOG_WARN_NAMED("TaskManager",
                           "Unexpected BT status detected: " << static_cast<int>(status) << ", mapping to FAILURE");
            return core::NodeStatus::FAILURE;
    }
}
}  // namespace

TaskManager::TaskManager(std::shared_ptr<core::Blackboard> blackboard)
    : _blackboard(blackboard), _lastStatus(core::NodeStatus::IDLE), _isPaused(false) {}

TaskManager::~TaskManager() {
    _trees.clear();
}

bool TaskManager::preload(const std::string& name, const std::string& resource_path) {
    try {
        if (_trees.find(name) == _trees.end()) {
            auto tree = _factory.createTreeFromFile(resource_path);
            _trees.emplace(name, std::move(tree));
            LOG_INFO_NAMED("TaskManager", "Preloaded tree [" << name << "] from [" << resource_path << "]");
        }
        return true;
    } catch (const std::exception& e) {
        LOG_ERROR_NAMED("TaskManager",
                        "Failed to preload tree [" << name << "] from [" << resource_path << "]: " << e.what());
        return false;
    }
}

bool TaskManager::load(const std::string& name, const std::string& resource_path) {
    try {
        // Ensure tree is loaded (uses preload logic internally)
        if (!preload(name, resource_path)) {
            return false;
        }

        // Halt current tree if any
        if (_currentTreeName.has_value() && _currentTreeName.value() != name) {
            _trees.at(_currentTreeName.value()).haltTree();
        }

        _currentTreeName = name;
        _isPaused = false;

        // Reset the tree to IDLE
        _trees.at(name).haltTree();

#ifdef BTCPP_GROOT_INTERFACE_ENABLED
        // Optional: Groot2 publisher (if not already started)
        if (!_groot_publisher) {
            _groot_publisher = std::make_unique<BT::Groot2Publisher>(_trees.at(name));
        } else {
            // Note: Groot2 publisher v4 doesn't support easy switching between trees in one instance
            // For now, we just update the blackboard
        }
#endif

        // Update blackboard if namespace is set
        if (!_statusNamespace.empty()) {
            std::string base = _statusNamespace + (_statusNamespace.back() == '/' ? "" : "/");
            _blackboard->set(base + "engine_current_tree", name);
            _blackboard->deleteKey(base + "engine_progress");
            _blackboard->deleteKey(base + "engine_status");
            _blackboard->deleteKey(base + "engine_error");
            _blackboard->deleteKey(base + "engine_error_code");
        }

        return true;
    } catch (const std::exception& e) {
        std::cerr << "Failed to load behavior tree [" << name << "] from [" << resource_path << "]: " << e.what()
                  << std::endl;
        return false;
    }
}

void TaskManager::unregisterTree(const std::string& name) {
    if (_currentTreeName == name) {
        abort();
    }
    _trees.erase(name);
}

core::NodeStatus TaskManager::tick() {
    if (!_currentTreeName.has_value()) {
        _lastError = "No tree loaded";
        _errorCode = -1;
        return core::NodeStatus::IDLE;
    }

    if (_isPaused) {
        return core::NodeStatus::RUNNING;
    }

    try {
        auto& tree = _trees.at(_currentTreeName.value());
        auto status = tree.tickOnce();
        _lastStatus = toNodeStatus(status);

        LOG_DEBUG_NAMED("TaskManager", "BT Tree [" << _currentTreeName.value()
                                                   << "] ticked, status=" << static_cast<int>(status) << " -> "
                                                   << static_cast<int>(_lastStatus));

        if (status == BT::NodeStatus::FAILURE) {
            LOG_WARN_NAMED("TaskManager", "BT Tree [" << _currentTreeName.value() << "] returned FAILURE");
        }

        // Clear errors if running or success
        if (_lastStatus != core::NodeStatus::FAILURE) {
            _lastError.clear();
            _errorCode = 0;
        } else {
            _lastError = "BT Execution Failure";
            _errorCode = 1;
        }

        return _lastStatus;
    } catch (const std::exception& e) {
        _lastStatus = core::NodeStatus::FAILURE;
        _lastError = std::string("BT Exception: ") + e.what();
        _errorCode = 2;
        LOG_ERROR_NAMED("TaskManager",
                        "Exception during BT tick for tree [" << _currentTreeName.value() << "]: " << e.what());
        return _lastStatus;
    }
}

void TaskManager::abort() {
    if (_currentTreeName.has_value()) {
        _trees.at(_currentTreeName.value()).haltTree();
    }
}

void TaskManager::reset() {
    abort();
    // Do not clear _currentTreeName here, so the next tick() can restart the current tree.
    // If a different tree is needed, load() will handle it.
    _lastStatus = core::NodeStatus::IDLE;
    _isPaused = false;
    _lastError.clear();
    _errorCode = 0;

    // Clear progress and status in local blackboard if configured
    if (!_statusNamespace.empty()) {
        std::string base = _statusNamespace + (_statusNamespace.back() == '/' ? "" : "/");
        _blackboard->deleteKey(base + "engine_progress");
        _blackboard->deleteKey(base + "engine_current_tree");
        _blackboard->deleteKey(base + "engine_status");
        _blackboard->deleteKey(base + "engine_error");
        _blackboard->deleteKey(base + "engine_error_code");
    }
}

void TaskManager::onPostTick() {
    if (_statusNamespace.empty()) return;

    // Write execution status to blackboard
    std::string base = _statusNamespace + (_statusNamespace.back() == '/' ? "" : "/");

    _blackboard->set(base + "engine_status", static_cast<int>(_lastStatus));
    _blackboard->set(base + "engine_error", _lastError);
    _blackboard->set(base + "engine_error_code", _errorCode);
}

void TaskManager::pause() {
    if (_currentTreeName.has_value() && !_isPaused) {
        _isPaused = true;
    }
}

void TaskManager::resume() {
    if (_currentTreeName.has_value() && _isPaused) {
        _isPaused = false;
    }
}

bool TaskManager::isRunning() const {
    return _currentTreeName.has_value() && !_isPaused;
}

}  // namespace framework
}  // namespace applications
}  // namespace robot_control
