#pragma once

#include <chrono>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <vector>
#include <variant>

#include "robot_control/common/logging.hpp"
#include "robot_control/core/enums.hpp"

namespace robot_control {
namespace core {

struct EvStart {};
struct EvStop {};
struct EvPause {};
struct EvResume {};
struct EvComplete {};
struct EvError { uint16_t code = 0; };
struct EvMountUpContactDone {};
struct EvMountUpClimbDone {};
struct EvUserIdChanged { std::string user_id = "0"; };

using EventV = std::variant<
    EvStart, EvStop, EvPause, EvResume, EvComplete, EvError,
    EvMountUpContactDone, EvMountUpClimbDone, EvUserIdChanged
>;

enum class EventType {
    // User commands
    USER_COMMAND_FOLLOW,
    USER_COMMAND_WAKEUP,
    USER_COMMAND_STOP_FOLLOW,
    USER_COMMAND_FOLLOW_SPEED_UP,
    USER_COMMAND_FOLLOW_SPEED_DOWN,
    USER_COMMAND_FOLLOW_DISTANCE_NEAR,
    USER_COMMAND_FOLLOW_DISTANCE_FAR,
    USER_COMMAND_FOLLOW_LOCATION,
    USER_COMMAND_PHOTO,
    USER_COMMAND_STOP,
    USER_COMMAND_CHARGE,
    USER_COMMAND_BOARDING,
    FOLLOW_ACTIVATION_REQUESTED,

    // System events
    EMERGENCY_STOP,

    // Navigation events
    TARGET_DETECTED,
    TARGET_LOST,
    TARGET_RECOVERED,
    NAVIGATION_FAILED,
    NAVIGATION_COMPLETED,
    NAV_TASK_ACTION_RESULT,

    // Function events
    FUNCTION_STARTED,
    FUNCTION_COMPLETED,
    FUNCTION_FAILED,
    FUNCTION_PAUSED,
    FUNCTION_RESUMED,

    // Task events
    TASK_STARTED,
    TASK_COMPLETED,
    TASK_FAILED,
    LOAD_BT_FACE_RECOG,
    LOAD_BT_GESTURE_FACE_RECOG,
    FACE_RECOG_RESULT,
    GESTURE_FACE_RECOG_RESULT,
    FOLLOW_ACTIVATE_RESULT,
    FOLLOW_HEARTBEAT,
    HMI_INTERACTION_REQUEST,
    PLANNER_RESERVED,

    // Feedback specific events
    FEEDBACK_FOLLOW_LOST_EXIT,
    FEEDBACK_FOLLOW_LOST,
    FEEDBACK_FOLLOW_START_FAIL_INVALID_USER,
    FEEDBACK_FOLLOW_START_FACE_TO_TP,
    FEEDBACK_FOLLOW_START_FAIL_WITHOUT_USER,
    FEEDBACK_FOLLOW_START_FAIL_NEED_CHECK,
    FEEDBACK_FOLLOW_START_SUCCEED_WITH_UWB,
    FEEDBACK_FOLLOW_START_SUCCEED,
    FEEDBACK_FOLLOW_START_FACE_TO_TP_THUMB_UP,
    FEEDBACK_THUMB_UP,
    FEEDBACK_FOLLOW_START_FAIL_UNKNOWN,
    FEEDBACK_FOLLOW_START_FAIL_WITH_USER_ONLY,
    FEEDBACK_FOLLOW_AGAIN,
    FEEDBACK_FOLLOW_EXEC_EXIT,
    FEEDBACK_FOLLOW_STOP_FAILED,
    FEEDBACK_FOLLOW_STOP_FAILED_INVALID_USER,
    FEEDBACK_WAKE_UP_RELAY,

    // Boarding events
    PASSENGER_DETECTED,
    PASSENGER_BOARDED,
    PASSENGER_ALIGHTED,
    BOARDING_CONFIRMED,
    ALIGHTING_CONFIRMED
};

struct Event {
    EventType event_type;
    double timestamp;
    std::string source;
    std::map<std::string, std::string> data;

    Event() : event_type(EventType::USER_COMMAND_STOP), timestamp(0.0), source("") {}

    Event(EventType type, const std::string& src = "")
        : event_type(type),
          timestamp(std::chrono::duration<double>(std::chrono::system_clock::now().time_since_epoch()).count()),
          source(src) {}
};

class EventBus {
   public:
    using SubscriberId = size_t;
    using EventCallback = std::function<void(const Event&)>;

    // Singleton access
    static EventBus& getInstance() {
        static EventBus instance;
        return instance;
    }

    // Delete copy constructor and assignment operator
    EventBus(const EventBus&) = delete;
    EventBus& operator=(const EventBus&) = delete;

    // Subscribe to events of a specific type
    SubscriberId subscribe(EventType event_type, EventCallback callback) {
        std::lock_guard<std::mutex> lock(mutex_);
        SubscriberId id = next_subscriber_id_++;
        subscribers_[event_type].emplace(id, callback);
        return id;
    }

    // Unsubscribe from events
    bool unsubscribe(EventType event_type, SubscriberId subscriber_id) {
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = subscribers_.find(event_type);
        if (it != subscribers_.end()) {
            return it->second.erase(subscriber_id) > 0;
        }
        return false;
    }

    // Publish an event
    void publish(const Event& event) {
        std::vector<EventCallback> callbacks;
        {
            std::lock_guard<std::mutex> lock(mutex_);

            // Add to history
            history_.push_back(event);
            if (history_.size() > max_history_size_) {
                history_.erase(history_.begin());
            }

            // Snapshot callbacks to avoid iterator invalidation/reentrant mutation issues
            auto it = subscribers_.find(event.event_type);
            if (it != subscribers_.end()) {
                callbacks.reserve(it->second.size());
                for ([[maybe_unused]] const auto& [id, callback] : it->second) {
                    callbacks.push_back(callback);
                }
            }
        }

        for (const auto& callback : callbacks) {
            try {
                callback(event);
            } catch (const std::exception& e) {
                LOG_ERROR("subscriber exception: " << e.what());
            } catch (...) {
                LOG_ERROR("subscriber exception: unknown");
            }
        }
    }

    // Get event history
    std::vector<Event> getHistory(std::optional<EventType> filter = std::nullopt, int limit = 10) const {
        std::lock_guard<std::mutex> lock(mutex_);
        std::vector<Event> result;

        int count = 0;
        for (auto it = history_.rbegin(); it != history_.rend() && count < limit; ++it) {
            if (!filter.has_value() || it->event_type == filter.value()) {
                result.push_back(*it);
                ++count;
            }
        }

        return result;
    }

    // Clear event history
    void clearHistory() {
        std::lock_guard<std::mutex> lock(mutex_);
        history_.clear();
    }

    // Reset for testing (clears subscribers and history)
    static void reset() {
        EventBus& instance = getInstance();
        std::lock_guard<std::mutex> lock(instance.mutex_);
        instance.subscribers_.clear();
        instance.history_.clear();
        instance.next_subscriber_id_ = 1;
    }

   private:
    EventBus() : next_subscriber_id_(1), max_history_size_(1000) {}

    mutable std::mutex mutex_;
    std::map<EventType, std::map<SubscriberId, EventCallback>> subscribers_;
    std::vector<Event> history_;
    SubscriberId next_subscriber_id_;
    size_t max_history_size_;
    std::string _logger_name = "EventBus";
};

}  // namespace core
}  // namespace robot_control
