#pragma once

#include <chrono>
#include <ctime>
#include <iomanip>
#include <rclcpp/logging.hpp>
#include <sstream>

namespace robot_control {
namespace common {
inline std::string formatTimestamp(double timestamp) {
    auto seconds = static_cast<time_t>(timestamp);
    auto milliseconds = static_cast<int>((timestamp - seconds) * 1000);
    struct tm* tm_info = localtime(&seconds);
    char buffer[32];
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", tm_info);
    std::ostringstream oss;
    oss << buffer << "." << std::setfill('0') << std::setw(3) << milliseconds;
    return oss.str();
}

inline std::string formatCurrentTime() {
    auto now = std::chrono::system_clock::now();
    double timestamp = std::chrono::duration<double>(now.time_since_epoch()).count();
    return formatTimestamp(timestamp);
}
}  // namespace common
}  // namespace robot_control

/**
 * @brief Common logging macros for the robot_control project.
 * These macros use RCLCPP_STREAM_LOG to provide a stream-based logging interface
 * similar to std::cout, but integrated with the ROS 2 logging system.
 *
 * LOG_*(msg) macros require `_logger_name` in scope.
 * LOG_*_NAMED(logger_name, msg) macros accept explicit logger name.
 */

#define LOG_DEBUG_NAMED(logger_name, msg)                                                                  \
    RCLCPP_DEBUG_STREAM(rclcpp::get_logger(logger_name), "[" << robot_control::common::formatCurrentTime() \
                                                             << "] [DEBUG] [" << logger_name << "] " << msg)
#define LOG_INFO_NAMED(logger_name, msg)                                                                  \
    RCLCPP_INFO_STREAM(rclcpp::get_logger(logger_name), "[" << robot_control::common::formatCurrentTime() \
                                                            << "] [INFO] [" << logger_name << "] " << msg)
#define LOG_WARN_NAMED(logger_name, msg)                                                                  \
    RCLCPP_WARN_STREAM(rclcpp::get_logger(logger_name), "[" << robot_control::common::formatCurrentTime() \
                                                            << "] [WARN] [" << logger_name << "] " << msg)
#define LOG_ERROR_NAMED(logger_name, msg)                                                                  \
    RCLCPP_ERROR_STREAM(rclcpp::get_logger(logger_name), "[" << robot_control::common::formatCurrentTime() \
                                                             << "] [ERROR] [" << logger_name << "] " << msg)
#define LOG_FATAL_NAMED(logger_name, msg)                                                                  \
    RCLCPP_FATAL_STREAM(rclcpp::get_logger(logger_name), "[" << robot_control::common::formatCurrentTime() \
                                                             << "] [FATAL] [" << logger_name << "] " << msg)

#define LOG_DEBUG(msg) LOG_DEBUG_NAMED(_logger_name, msg)
#define LOG_INFO(msg) LOG_INFO_NAMED(_logger_name, msg)
#define LOG_WARN(msg) LOG_WARN_NAMED(_logger_name, msg)
#define LOG_ERROR(msg) LOG_ERROR_NAMED(_logger_name, msg)
#define LOG_FATAL(msg) LOG_FATAL_NAMED(_logger_name, msg)
