#include "robot_control/core/events.hpp"

namespace robot_control {
namespace core {

// EventBus implementation is mostly in the header file (template/inline methods)
// This file can be used for any non-inline implementations if needed in the future

}  // namespace core
}  // namespace robot_control
