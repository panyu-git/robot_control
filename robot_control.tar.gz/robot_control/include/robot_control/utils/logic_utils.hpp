// Copyright 2026 Robot Control. All Rights Reserved.

#ifndef ROBOT_CONTROL_UTILS_LOGIC_UTILS_H_
#define ROBOT_CONTROL_UTILS_LOGIC_UTILS_H_

#include <array>
#include <chrono>
#include <cmath>
#include <vector>

namespace robot_control {
namespace utils {

/**
 * @brief LogicUtils provides generic, stateless logic evaluation functions.
 * These are pure functions with no side effects and are decoupled from
 * specific business domains.
 */
class LogicUtils {
 public:
  /**
   * @brief Generic timeout check.
   * @param elapsed The time elapsed in seconds.
   * @param threshold The threshold in seconds.
   * @return true if elapsed is greater than or equal to threshold.
   */
  static bool IsTimeout(double elapsed, double threshold) {
    return threshold > 0 && elapsed >= threshold;
  }

  /**
   * @brief Check if a current status is within a set of target statuses.
   * @tparam T The status enum or type.
   * @param current The current status to check.
   * @param targets A list of valid target statuses.
   * @return true if current is found in targets.
   */
  template <typename T>
  static bool IsStatusIn(const T& current, const std::vector<T>& targets) {
    for (const auto& target : targets) {
      if (current == target) {
        return true;
      }
    }
    return false;
  }

  /**
   * @brief Get current time in seconds from steady_clock.
   * @return Current time in seconds.
   */
  static double GetCurrentTimeSec() {
    return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
  }

  /**
   * @brief Helper to calculate elapsed time between two steady_clock points in milliseconds.
   * @param start The start time point.
   * @param end The end time point.
   * @return Elapsed time in milliseconds.
   */
  static int64_t GetElapsedMs(
      const std::chrono::steady_clock::time_point& start,
      const std::chrono::steady_clock::time_point& end) {
    return std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
  }

  /**
   * @brief Check if a duration (in ms) has exceeded a threshold (in ms).
   * @param start The start time point.
   * @param threshold_ms The threshold in milliseconds.
   * @return true if elapsed time is greater than or equal to threshold.
   */
  static bool IsTimeoutMs(const std::chrono::steady_clock::time_point& start, int64_t threshold_ms) {
    if (threshold_ms <= 0) return false;
    return GetElapsedMs(start, std::chrono::steady_clock::now()) >= threshold_ms;
  }

  /**
   * @brief Check if a timestamp (in seconds) has exceeded a threshold (in ms).
   * @param last_time_s The last timestamp in seconds (steady_clock based).
   * @param threshold_ms The threshold in milliseconds.
   * @return true if elapsed time is greater than or equal to threshold.
   */
  static bool IsTimeoutMs(double last_time_s, int64_t threshold_ms) {
    if (threshold_ms <= 0 || last_time_s <= 0.0) return false;
    return (GetCurrentTimeSec() - last_time_s) * 1000.0 >= static_cast<double>(threshold_ms);
  }

  /**
   * @brief Find the index of the level nearest to the given value.
   * @tparam T The numeric type.
   * @tparam N The number of levels.
   * @param value The input value.
   * @param levels The array of levels to search.
   * @return The index of the nearest level.
   */
  template <typename T, size_t N>
  static int NearestLevelIndex(T value, const std::array<T, N>& levels) {
    if (N == 0) return -1;
    int best_idx = 0;
    T best_diff = std::abs(levels[0] - value);
    for (size_t i = 1; i < N; ++i) {
      T diff = std::abs(levels[i] - value);
      if (diff < best_diff) {
        best_diff = diff;
        best_idx = static_cast<int>(i);
      }
    }
    return best_idx;
  }
};

}  // namespace utils
}  // namespace robot_control

#endif  // ROBOT_CONTROL_UTILS_LOGIC_UTILS_H_
