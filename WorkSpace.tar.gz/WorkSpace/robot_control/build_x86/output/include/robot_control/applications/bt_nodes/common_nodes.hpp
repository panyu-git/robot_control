#pragma once

#include <cstdint>
#include <string>

#include "behaviortree_cpp/action_node.h"
#include "behaviortree_cpp/bt_factory.h"

#include "robot_control/applications/bt_nodes/convert_from_string.hpp"
#include "robot_control/core/enums.hpp"

namespace robot_control {
namespace applications {
namespace bt_nodes {

class PublishToEventBus : public BT::SyncActionNode {
   public:
    PublishToEventBus(const std::string& name, const BT::NodeConfig& config) : BT::SyncActionNode(name, config) {}

    BT::NodeStatus tick() override;

    static BT::PortsList providedPorts() {
        return {BT::InputPort<core::EventType>("event_type"),
                BT::InputPort<std::string>("source"),
                BT::InputPort<std::string>("data")};
    }
};

class PublishFuncState : public BT::SyncActionNode {
   public:
    PublishFuncState(const std::string& name, const BT::NodeConfig& config) : BT::SyncActionNode(name, config) {}

    BT::NodeStatus tick() override;

    static BT::PortsList providedPorts() {
        return {BT::InputPort<std::string>("user_id"),
                BT::InputPort<core::FunctionType>("type"),
                BT::InputPort<core::MountupStage>("stage"),
                BT::InputPort<core::FunctionStatus>("status"),
                BT::InputPort<uint16_t>("error_code")};
    }
};

class GrabBootupTime : public BT::SyncActionNode {
   public:
    GrabBootupTime(const std::string& name, const BT::NodeConfig& config) : BT::SyncActionNode(name, config) {}

    BT::NodeStatus tick() override;

    static BT::PortsList providedPorts() {
        return {BT::OutputPort<std::int64_t>("ms")};
    }
};

[[nodiscard]] std::int64_t millis_since_system_boot();

void registerCommonNodes(BT::BehaviorTreeFactory& factory);

}  // namespace bt_nodes
}  // namespace applications
}  // namespace robot_control
