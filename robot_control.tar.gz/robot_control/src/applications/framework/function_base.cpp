#include "robot_control/applications/framework/function_base.hpp"

#include <atomic>
#include <chrono>
#include <sstream>

#include "robot_control/common/logging.hpp"
#include "robot_control/core/enums.hpp"

namespace robot_control {
namespace applications {
namespace framework {

Function::Function(std::shared_ptr<core::Blackboard> blackboard)
    : _blackboard(blackboard),
      function_id_(_createPseudoUuid()),
      // _localBlackboard can't be initialized with functionType() in base constructor
      // because pure virtual methods can't be called during construction.
      // We initialize it with an empty prefix here and re-assign it later or use a workaround.
      _localBlackboard(*blackboard, function_id_),
      _status(core::FunctionStatus::IDLE),
      function_name_("UNNAMED_FUNCTION"),
      scheduler_priority_(0),
      _sessionStartTime(std::chrono::steady_clock::now()) {}

void Function::enter(const std::optional<std::map<std::string, std::any>>& context) {
    _status = core::FunctionStatus::INITIALIZING;
    _sessionStartTime = std::chrono::steady_clock::now();
    if (_blackboard) {
        _blackboard->deleteByPrefix("cmd_");
    }
    onEnter(context);
}

core::PreemptionType Function::preemptionType() const {
    return core::PreemptionType::HARD;
}

bool Function::isRunning() const {
    return _status == core::FunctionStatus::RUNNING;
}

bool Function::isCompleted() const {
    return _status == core::FunctionStatus::COMPLETED || _status == core::FunctionStatus::FAILED;
}

std::optional<std::map<std::string, std::any>> Function::onPause() {
    return onExit();
}

void Function::onResume(const std::map<std::string, std::any>& /*context*/) {
    _status = core::FunctionStatus::RUNNING;
}

bool Function::canTransitionTo(Function& target) const {
    // Higher priority (lower number) can always preempt
    if (static_cast<int>(target.priority()) < static_cast<int>(priority())) {
        return true;
    }

    // Same or lower priority requires completion
    return _status == core::FunctionStatus::IDLE || _status == core::FunctionStatus::COMPLETED ||
           _status == core::FunctionStatus::FAILED;
}

std::map<std::string, std::any> Function::getInfo() const {
    std::map<std::string, std::any> info;
    info["type"] = std::string(core::toString(functionType()));
    info["priority"] = static_cast<int>(priority());
    info["status"] = std::string(core::toString(_status));
    info["preemption_type"] = std::string(core::toString(preemptionType()));
    return info;
}

Function::json Function::toJson() const {
    json data;
    const auto resolved_function_name =
        function_name_ == "UNNAMED_FUNCTION" ? core::toString(functionType()) : function_name_;
    data["function_id"] = function_id_;
    data["function_name"] = resolved_function_name;
    data["status"] = core::toString(_status);
    data["scheduler_priority"] = schedulerPriority();
    data["function_type"] = core::toString(functionType());
    return data;
}

void Function::fromJson(const json& data) {
    try {
        if (data.contains("function_id") && data["function_id"].is_string()) {
            function_id_ = data["function_id"].get<std::string>();
        }

        if (data.contains("function_name") && data["function_name"].is_string()) {
            function_name_ = data["function_name"].get<std::string>();
        }

        if (data.contains("scheduler_priority")) {
            if (data["scheduler_priority"].is_number_integer()) {
                scheduler_priority_ = data["scheduler_priority"].get<int>();
            } else if (data["scheduler_priority"].is_string()) {
                const auto parsed =
                    core::fromString<core::FunctionPriority>(data["scheduler_priority"].get<std::string>());
                scheduler_priority_ = static_cast<int>(parsed);
            }
        }

        if (data.contains("status") && data["status"].is_string()) {
            _status = core::fromString<core::FunctionStatus>(data["status"].get<std::string>());
        }
    } catch (...) {
        // Ignore malformed JSON fields and keep current in-memory state.
    }
}

core::FunctionStatus Function::updateStatusFromEngine() {
    // Ensure localBlackboard prefix matches the current function type string
    // This matches the status namespace set in FunctionManager::transitionTo
    std::string expected_prefix = core::toString(functionType());
    if (_localBlackboard.prefix() != expected_prefix + "/") {
        _localBlackboard.setPrefix(expected_prefix);
    }

    // Read status from the local blackboard view (back-written by engine)
    auto engine_status_int = _localBlackboard.get<int>("engine_status", static_cast<int>(core::NodeStatus::IDLE));
    auto engine_status = static_cast<core::NodeStatus>(engine_status_int);

    if (engine_status != core::NodeStatus::IDLE && engine_status != core::NodeStatus::RUNNING) {
        std::stringstream ss;
        ss << "[" << core::toString(functionType())
           << "] updateStatusFromEngine: status=" << core::toString(engine_status) << " (" << engine_status_int << ")";
        LOG_DEBUG_NAMED("Function", ss.str());
    }

    if (engine_status == core::NodeStatus::SUCCESS) {
        _status = core::FunctionStatus::COMPLETED;
    } else if (engine_status == core::NodeStatus::FAILURE) {
        _status = core::FunctionStatus::FAILED;
    } else if (engine_status == core::NodeStatus::RUNNING || engine_status == core::NodeStatus::SKIPPED) {
        _status = core::FunctionStatus::RUNNING;
    }

    return _status;
}

std::string Function::_createPseudoUuid() {
    static std::atomic<uint64_t> seq{0};
    const auto now_ns =
        std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch())
            .count();
    return "function-" + std::to_string(now_ns) + "-" + std::to_string(seq.fetch_add(1));
}

}  // namespace framework
}  // namespace applications
}  // namespace robot_control
