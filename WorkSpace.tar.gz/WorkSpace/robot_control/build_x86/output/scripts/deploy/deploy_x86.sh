#!/bin/bash
# Deploy Robot Control System
# Usage: ./deploy.sh [target_dir]

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
TARGET_DIR="${1:-/opt/robot_control}"

echo "Deploying Robot Control System..."
echo "  Source: $PROJECT_ROOT"
echo "  Target: $TARGET_DIR"

# Create target directory
sudo mkdir -p "$TARGET_DIR"

# Copy files
sudo cp -r "$PROJECT_ROOT/src" "$TARGET_DIR/"
sudo cp -r "$PROJECT_ROOT/etc" "$TARGET_DIR/"
sudo cp -r "$PROJECT_ROOT/scripts" "$TARGET_DIR/"

# Set permissions
sudo chmod +x "$TARGET_DIR/scripts/"*.sh

echo "Deployment complete."
echo ""
echo "To start the system:"
echo "  $TARGET_DIR/scripts/start_system.sh"
