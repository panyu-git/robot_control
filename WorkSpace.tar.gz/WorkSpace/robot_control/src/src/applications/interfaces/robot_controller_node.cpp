#include "robot_control/applications/interfaces/robot_controller_node.hpp"

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cmath>
#include <ctime>
#include <iomanip>
#include <map>
#include <sstream>

#include "behaviortree_cpp/contrib/magic_enum.hpp"

#include "robot_control/common/blackboard/black_board.hpp"
#include "robot_control/common/logging.hpp"
#include "robot_control/core/enums.hpp"
#include "robot_control/core/robot_control_configs.hpp"
#include "segar/time/clock.h"

namespace robot_control {
namespace applications {
namespace interfaces {

namespace {

constexpr const char* kWakeUpRelay = "wake_up_relay";
constexpr const char* kFeedbackFollowStartFailInvalidUser = "prompt_start_follow_failed_with_invalid_user";
constexpr const char* kFeedbackFollowStartFaceToTp = "prompt_face_to_tp";
constexpr const char* kFeedbackFollowStartFailWithoutUser = "prompt_start_follow_failed_without_user";
constexpr const char* kFeedbackFollowStartFailNeedCheck = "prompt_start_follow_failed_need_check";
constexpr const char* kFeedbackFollowStartSucceedWithUwb = "prompt_start_follow_succeed_with_uwb";
constexpr const char* kFeedbackFollowStartSucceed = "prompt_start_follow_succeed";
constexpr const char* kFeedbackFollowStartFaceToTpThumbUp = "prompt_face_to_tp_thumb_up";
constexpr const char* kFeedbackThumbUp = "prompt_thumb_up";
constexpr const char* kFeedbackFollowStartFailUnknown = "prompt_start_follow_failed_with_unknown_reason";
constexpr const char* kFeedbackFollowStartFailWithUserOnly = "prompt_start_follow_failed_with_user_only";
constexpr const char* kFeedbackFollowAgain = "prompt_follow_again";
constexpr const char* kFeedbackFollowLost = "prompt_follow_lost";
constexpr const char* kFeedbackFollowLostExit = "prompt_follow_lost_exit";
constexpr const char* kFeedbackFollowExecExit = "prompt_follow_exec_exit";
constexpr const char* kFeedbackFollowStopFailed = "prompt_follow_stop_failed";
constexpr const char* kFeedbackFollowStopFailedInvalidUser = "prompt_follow_stop_failed_with_invalid_user";

/**
 * Structure to encapsulate HMI feedback reporting configuration.
 */
struct FeedbackInfo {
    const char* feedback_type;
    const char* task_name;
    const char* task_state;
};

/**
 * Registry of events that should be reported to the HMI/State topic.
 * Maps core::EventType to its associated feedback configuration.
 */
static const std::map<core::EventType, FeedbackInfo> kEventFeedbackRegistry = {
    {core::EventType::FEEDBACK_WAKE_UP_RELAY, {kWakeUpRelay, "WAKEUP_TASK", ""}},
    {core::EventType::FEEDBACK_FOLLOW_START_FAIL_INVALID_USER,
     {kFeedbackFollowStartFailInvalidUser, "FOLLOW_TASK", "FAILED"}},
    {core::EventType::FEEDBACK_FOLLOW_START_FACE_TO_TP, {kFeedbackFollowStartFaceToTp, "FOLLOW_TASK", ""}},
    {core::EventType::FEEDBACK_FOLLOW_START_FAIL_WITHOUT_USER,
     {kFeedbackFollowStartFailWithoutUser, "FOLLOW_TASK", "FAILED"}},
    {core::EventType::FEEDBACK_FOLLOW_START_FAIL_NEED_CHECK,
     {kFeedbackFollowStartFailNeedCheck, "FOLLOW_TASK", "FAILED"}},
    {core::EventType::FEEDBACK_FOLLOW_START_SUCCEED_WITH_UWB,
     {kFeedbackFollowStartSucceedWithUwb, "FOLLOW_TASK", "RUNNING"}},
    {core::EventType::FEEDBACK_FOLLOW_START_SUCCEED, {kFeedbackFollowStartSucceed, "FOLLOW_TASK", "RUNNING"}},
    {core::EventType::FEEDBACK_FOLLOW_START_FACE_TO_TP_THUMB_UP,
     {kFeedbackFollowStartFaceToTpThumbUp, "FOLLOW_TASK", ""}},
    {core::EventType::FEEDBACK_THUMB_UP, {kFeedbackThumbUp, "FOLLOW_TASK", ""}},
    {core::EventType::FEEDBACK_FOLLOW_START_FAIL_UNKNOWN, {kFeedbackFollowStartFailUnknown, "FOLLOW_TASK", "FAILED"}},
    {core::EventType::FEEDBACK_FOLLOW_START_FAIL_WITH_USER_ONLY,
     {kFeedbackFollowStartFailWithUserOnly, "FOLLOW_TASK", "FAILED"}},
    {core::EventType::FEEDBACK_FOLLOW_AGAIN, {kFeedbackFollowAgain, "FOLLOW_TASK", ""}},
    {core::EventType::FEEDBACK_FOLLOW_LOST, {kFeedbackFollowLost, "FOLLOW_TASK", "LOST"}},
    {core::EventType::FEEDBACK_FOLLOW_LOST_EXIT, {kFeedbackFollowLostExit, "FOLLOW_TASK", "EXITED"}},
    {core::EventType::FEEDBACK_FOLLOW_EXEC_EXIT, {kFeedbackFollowExecExit, "FOLLOW_TASK", "COMPLETED"}},
    {core::EventType::FEEDBACK_FOLLOW_STOP_FAILED, {kFeedbackFollowStopFailed, "FOLLOW_TASK", ""}},
    {core::EventType::FEEDBACK_FOLLOW_STOP_FAILED_INVALID_USER,
     {kFeedbackFollowStopFailedInvalidUser, "FOLLOW_TASK", ""}}};

std::string eventTypeToString(core::EventType type) {
    switch (type) {
        case core::EventType::FOLLOW_ACTIVATION_REQUESTED:
            return "FOLLOW_ACTIVATION_REQUESTED";
        case core::EventType::FACE_RECOG_RESULT:
            return "FACE_RECOG_RESULT";
        case core::EventType::FOLLOW_ACTIVATE_RESULT:
            return "FOLLOW_ACTIVATE_RESULT";
        case core::EventType::FOLLOW_HEARTBEAT:
            return "FOLLOW_HEARTBEAT";
        case core::EventType::FUNCTION_STARTED:
            return "FUNCTION_STARTED";
        case core::EventType::FUNCTION_COMPLETED:
            return "FUNCTION_COMPLETED";
        case core::EventType::FUNCTION_FAILED:
            return "FUNCTION_FAILED";
        case core::EventType::HMI_INTERACTION_REQUEST:
            return "HMI_INTERACTION_REQUEST";
        case core::EventType::TARGET_LOST:
            return "TARGET_LOST";
        case core::EventType::USER_COMMAND_WAKEUP:
            return "USER_COMMAND_WAKEUP";
        case core::EventType::USER_COMMAND_STOP_FOLLOW:
            return "USER_COMMAND_STOP_FOLLOW";
        case core::EventType::USER_COMMAND_FOLLOW_SPEED_UP:
            return "USER_COMMAND_FOLLOW_SPEED_UP";
        case core::EventType::USER_COMMAND_FOLLOW_SPEED_DOWN:
            return "USER_COMMAND_FOLLOW_SPEED_DOWN";
        case core::EventType::USER_COMMAND_FOLLOW_DISTANCE_NEAR:
            return "USER_COMMAND_FOLLOW_DISTANCE_NEAR";
        case core::EventType::USER_COMMAND_FOLLOW_DISTANCE_FAR:
            return "USER_COMMAND_FOLLOW_DISTANCE_FAR";
        case core::EventType::USER_COMMAND_FOLLOW_LOCATION:
            return "USER_COMMAND_FOLLOW_LOCATION";
        case core::EventType::FEEDBACK_FOLLOW_LOST_EXIT:
            return "FEEDBACK_FOLLOW_LOST_EXIT";
        case core::EventType::FEEDBACK_FOLLOW_LOST:
            return "FEEDBACK_FOLLOW_LOST";
        case core::EventType::FEEDBACK_FOLLOW_START_FAIL_INVALID_USER:
            return "FEEDBACK_FOLLOW_START_FAIL_INVALID_USER";
        case core::EventType::FEEDBACK_FOLLOW_START_FACE_TO_TP:
            return "FEEDBACK_FOLLOW_START_FACE_TO_TP";
        case core::EventType::FEEDBACK_FOLLOW_START_FAIL_WITHOUT_USER:
            return "FEEDBACK_FOLLOW_START_FAIL_WITHOUT_USER";
        case core::EventType::FEEDBACK_FOLLOW_START_FAIL_NEED_CHECK:
            return "FEEDBACK_FOLLOW_START_FAIL_NEED_CHECK";
        case core::EventType::FEEDBACK_FOLLOW_START_SUCCEED_WITH_UWB:
            return "FEEDBACK_FOLLOW_START_SUCCEED_WITH_UWB";
        case core::EventType::FEEDBACK_FOLLOW_START_SUCCEED:
            return "FEEDBACK_FOLLOW_START_SUCCEED";
        case core::EventType::FEEDBACK_FOLLOW_START_FACE_TO_TP_THUMB_UP:
            return "FEEDBACK_FOLLOW_START_FACE_TO_TP_THUMB_UP";
        case core::EventType::FEEDBACK_THUMB_UP:
            return "FEEDBACK_THUMB_UP";
        case core::EventType::FEEDBACK_FOLLOW_START_FAIL_UNKNOWN:
            return "FEEDBACK_FOLLOW_START_FAIL_UNKNOWN";
        case core::EventType::FEEDBACK_FOLLOW_START_FAIL_WITH_USER_ONLY:
            return "FEEDBACK_FOLLOW_START_FAIL_WITH_USER_ONLY";
        case core::EventType::FEEDBACK_FOLLOW_AGAIN:
            return "FEEDBACK_FOLLOW_AGAIN";
        case core::EventType::FEEDBACK_FOLLOW_EXEC_EXIT:
            return "FEEDBACK_FOLLOW_EXEC_EXIT";
        case core::EventType::FEEDBACK_FOLLOW_STOP_FAILED:
            return "FEEDBACK_FOLLOW_STOP_FAILED";
        case core::EventType::FEEDBACK_FOLLOW_STOP_FAILED_INVALID_USER:
            return "FEEDBACK_FOLLOW_STOP_FAILED_INVALID_USER";
        case core::EventType::FEEDBACK_WAKE_UP_RELAY:
            return "FEEDBACK_WAKE_UP_RELAY";
        default:
            return "UNKNOWN";
    }
}

bool shouldTraceCoreEvent(core::EventType type) {
    switch (type) {
        case core::EventType::FOLLOW_ACTIVATION_REQUESTED:
        case core::EventType::FACE_RECOG_RESULT:
        case core::EventType::FOLLOW_ACTIVATE_RESULT:
        case core::EventType::FUNCTION_STARTED:
        case core::EventType::FUNCTION_COMPLETED:
        case core::EventType::FUNCTION_FAILED:
        case core::EventType::HMI_INTERACTION_REQUEST:
        case core::EventType::TARGET_LOST:
        case core::EventType::USER_COMMAND_WAKEUP:
        case core::EventType::USER_COMMAND_STOP_FOLLOW:
        case core::EventType::USER_COMMAND_FOLLOW_SPEED_UP:
        case core::EventType::USER_COMMAND_FOLLOW_SPEED_DOWN:
        case core::EventType::USER_COMMAND_FOLLOW_DISTANCE_NEAR:
        case core::EventType::USER_COMMAND_FOLLOW_DISTANCE_FAR:
        case core::EventType::USER_COMMAND_FOLLOW_LOCATION:
        case core::EventType::FEEDBACK_FOLLOW_LOST_EXIT:
        case core::EventType::FEEDBACK_FOLLOW_LOST:
        case core::EventType::FEEDBACK_FOLLOW_START_FAIL_INVALID_USER:
        case core::EventType::FEEDBACK_FOLLOW_START_FACE_TO_TP:
        case core::EventType::FEEDBACK_FOLLOW_START_FAIL_WITHOUT_USER:
        case core::EventType::FEEDBACK_FOLLOW_START_FAIL_NEED_CHECK:
        case core::EventType::FEEDBACK_FOLLOW_START_SUCCEED_WITH_UWB:
        case core::EventType::FEEDBACK_FOLLOW_START_SUCCEED:
        case core::EventType::FEEDBACK_FOLLOW_START_FACE_TO_TP_THUMB_UP:
        case core::EventType::FEEDBACK_THUMB_UP:
        case core::EventType::FEEDBACK_FOLLOW_START_FAIL_UNKNOWN:
        case core::EventType::FEEDBACK_FOLLOW_START_FAIL_WITH_USER_ONLY:
        case core::EventType::FEEDBACK_FOLLOW_AGAIN:
        case core::EventType::FEEDBACK_FOLLOW_EXEC_EXIT:
        case core::EventType::FEEDBACK_FOLLOW_STOP_FAILED:
        case core::EventType::FEEDBACK_FOLLOW_STOP_FAILED_INVALID_USER:
        case core::EventType::FEEDBACK_WAKE_UP_RELAY:
            return true;
        default:
            return false;
    }
}

std::string trimCopy(const std::string& text) {
    auto begin = std::find_if_not(text.begin(), text.end(), [](unsigned char c) { return std::isspace(c) != 0; });
    auto end =
        std::find_if_not(text.rbegin(), text.rend(), [](unsigned char c) { return std::isspace(c) != 0; }).base();
    if (begin >= end) {
        return "";
    }
    return std::string(begin, end);
}

std::string getEventData(const core::Event& event, const std::string& key) {
    auto it = event.data.find(key);
    return (it == event.data.end()) ? std::string("") : it->second;
}

}  // namespace

RobotControllerNode::RobotControllerNode()
    : _ready(false), _currentSeq(0), _lastCommandId(""), _lastCommandTime(0.0), _logger_name("RobotControllerNode") {
    _node = rti::segar::CreateNode("robot_controller");
    if (!_node) {
        AFATAL << "Failed to create Segar node";
        return;
    }

    // Default parameters (originally from parameters)
    bool simulated = false;
    bool skip_follow_activation_in_simulated = true;
    double tick_rate = RobotController::DEFAULT_TICK_RATE;

    LOG_INFO("Initializing RobotController (simulated="
             << (simulated ? "true" : "false")
             << ", skip_follow_activation_in_simulated=" << (skip_follow_activation_in_simulated ? "true" : "false")
             << ", tick_rate=" << std::fixed << std::setprecision(1) << tick_rate << ")");

    // Create robot controller
    _controller = std::make_unique<RobotController>(simulated, tick_rate);
    _controller->blackboard->set("skip_follow_activation_in_simulated", skip_follow_activation_in_simulated);

    // =====================================================================
    // Subscriptions
    // =====================================================================
    _hmiCommandSub = _node->CreateReader<HmiCommandMsg>(
        "hmi_control/robot_control", [this](const std::shared_ptr<HmiCommandMsg>& msg) { _handleHmiCommand(msg); });

    // =====================================================================
    // Publishers
    // =====================================================================
    _robotStatePub = _node->CreateWriter<RobotStateMsg>("robot_control/state");
    _tpFunctionStatePub = _node->CreateWriter<TpFunctionStateMsg>("tp/function_state");
    _eventsPub = _node->CreateWriter<std_msgs::msg::String>("/robot/events");

    _ready = true;
    LOG_INFO("RobotControllerNode started");
    LOG_INFO("Writers: robot_control/state, tp/function_state, /robot/events");
    LOG_INFO("Readers: hmi_control/robot_control");
}

bool RobotControllerNode::init() {
    _controller->init(_node);
    // Start the controller
    _bridgeCoreEventsToRos();  // Moved to init() to prevent accessing uninitialized event_bus

    bbd::Sub(core::BlackboardKeys::BT_PUB_FUNCTION_STATE,
        [this](const std::string& usr_id, const core::FunctionType& func_type,
               const core::MountupStage& stage, const core::FunctionStatus& status,
               const uint16_t& error_code) {
        {
            std::lock_guard<std::mutex> lock(_mountup_stage_mutex);
            _mountup_stage = stage;
        }
        LOG_INFO("[/tp/function_state] UserId: " << usr_id);
        LOG_INFO("[/tp/function_state] FunctionType: " << magic_enum::enum_name(func_type));
        LOG_INFO("[/tp/function_state] MountupStage: " << magic_enum::enum_name(stage));
        LOG_INFO("[/tp/function_state] FunctionStatus: " << magic_enum::enum_name(status));
        LOG_INFO("[/tp/function_state] ErrorCode: " << error_code);
    });

    _controller->start();

    // Start periodic state reporting (10Hz)
    _stateTimer = std::make_shared<rti::segar::Timer>(100, [this]() { _publishPeriodicTpFunctionState(); }, false);
    _stateTimer->Start();

    return true;
}

void RobotControllerNode::_handleHmiCommand(const std::shared_ptr<HmiCommandMsg>& msg) {
    using namespace interaction_interfaces::msg::HmiControl2RobotControlMessage_Constants;
    if (msg->cmd_type() == CHAT) {
        LOG_WARN("[hmi_control/robot_control] CHAT cmd is disabled for robot_control");
        return;
    }

    // Deduplication logic: prefer seq, else check timestamp
    bool is_duplicate = false;
    std::string current_cmd_id = std::to_string(msg->seq());
    if (msg->seq() != 0) {
        if (current_cmd_id == _lastCommandId) {
            is_duplicate = true;
        }
    } else {
        // If no seq, check timestamp from header
        double msg_time = static_cast<double>(msg->header().stamp().sec()) +
                          static_cast<double>(msg->header().stamp().nanosec()) / 1e9;
        if (msg_time != 0.0 && msg_time == _lastCommandTime) {
            is_duplicate = true;
        }
    }

    if (is_duplicate) {
        LOG_WARN("[hmi_control/robot_control] Received duplicate cmd. Ignoring. (id=" << current_cmd_id << ")");
        return;
    }

    // Update deduplication state
    if (msg->seq() != 0) {
        _lastCommandId = current_cmd_id;
    }
    _currentSeq = msg->seq();
    _lastCommandTime =
        static_cast<double>(msg->header().stamp().sec()) + static_cast<double>(msg->header().stamp().nanosec()) / 1e9;

    LOG_INFO("[hmi_control/robot_control] Received cmd: " << static_cast<int>(msg->cmd_type())
                                                          << " id: " << current_cmd_id);

    std::string detail_message = "";
    bool ok = _dispatchRobotCommand(msg->cmd_type(), msg->execute_param(), detail_message);

    if (ok) {
        LOG_INFO("[hmi_control/robot_control] Execute Success! cmd_type: " << static_cast<int>(msg->cmd_type())
                                                                           << ", msg: " << detail_message);
    } else {
        LOG_ERROR("[hmi_control/robot_control] Execute Failed! cmd_type: " << static_cast<int>(msg->cmd_type())
                                                                           << ", msg: " << detail_message);
    }
}

std::map<std::string, std::string> RobotControllerNode::_parseExecuteParam(const std::string& execute_param) const {
    std::map<std::string, std::string> parsed;
    std::string text = trimCopy(execute_param);
    if (text.empty()) {
        return parsed;
    }

    // Accept JSON-like one-level payload: {"k":"v","n":1}
    if (text.front() == '{' && text.back() == '}') {
        text = text.substr(1, text.size() - 2);
        std::istringstream stream(text);
        std::string pair;
        while (std::getline(stream, pair, ',')) {
            auto pos = pair.find(':');
            if (pos == std::string::npos) {
                continue;
            }
            std::string key = trimCopy(pair.substr(0, pos));
            std::string value = trimCopy(pair.substr(pos + 1));
            if (key.size() >= 2 && key.front() == '"' && key.back() == '"') {
                key = key.substr(1, key.size() - 2);
            }
            if (value.size() >= 2 && value.front() == '"' && value.back() == '"') {
                value = value.substr(1, value.size() - 2);
            }
            if (!key.empty()) {
                parsed[key] = value;
            }
        }
        return parsed;
    }

    // Accept key=value pairs: a=1,b=2 or a=1;b=2
    std::string normalized = text;
    std::replace(normalized.begin(), normalized.end(), ';', ',');
    std::istringstream stream(normalized);
    std::string pair;
    while (std::getline(stream, pair, ',')) {
        auto pos = pair.find('=');
        if (pos == std::string::npos) {
            continue;
        }
        auto key = trimCopy(pair.substr(0, pos));
        auto value = trimCopy(pair.substr(pos + 1));
        if (!key.empty()) {
            parsed[key] = value;
        }
    }
    if (parsed.empty()) {
        parsed["value"] = text;
    }
    return parsed;
}

bool RobotControllerNode::_dispatchRobotCommand(uint8_t cmd_type, const std::string& execute_param,
                                                std::string& detail_message) {
    const auto params = _parseExecuteParam(execute_param);
    std::map<std::string, std::string> cmd_params = params;

    using namespace interaction_interfaces::msg::HmiControl2RobotControlMessage_Constants;

    if (cmd_type == KWS) {
        if (cmd_params.count("target_yaw") == 0 || cmd_params["target_yaw"].empty()) {
            if (cmd_params.count("wakeup_angle") > 0 && !cmd_params["wakeup_angle"].empty()) {
                cmd_params["target_yaw"] = cmd_params["wakeup_angle"];
            } else if (cmd_params.count("value") > 0 && !cmd_params["value"].empty()) {
                cmd_params["target_yaw"] = cmd_params["value"];
            }
        }

        if (cmd_params.count("max_angular_velocity") == 0 || cmd_params["max_angular_velocity"].empty()) {
            cmd_params["max_angular_velocity"] = "0.5";
        }

        bool ok = _controller->command("wakeup", cmd_params);
        detail_message = ok ? "KWS dispatched" : "KWS failed";
        return ok;
    }
    if (cmd_type == FOLLOW_START) {
        bool ok = _controller->command("follow", cmd_params);
        detail_message = ok ? "FOLLOW_START dispatched" : "FOLLOW_START failed";
        return ok;
    }
    if (cmd_type == FOLLOW_END) {
        bool ok = _controller->command("stop_follow", cmd_params);
        detail_message = ok ? "FOLLOW_END dispatched" : "FOLLOW_END failed";
        return ok;
    }
    if (cmd_type == FOLLOW_DIS) {
        std::string distance_level = "";
        auto dis_it = cmd_params.find("distance");
        if (dis_it != cmd_params.end()) {
            distance_level = dis_it->second;
        } else if (cmd_params.count("value") > 0) {
            distance_level = cmd_params["value"];
        }
        std::transform(distance_level.begin(), distance_level.end(), distance_level.begin(),
                       [](unsigned char c) { return static_cast<char>(std::tolower(c)); });

        bool ok = false;
        if (distance_level == "near") {
            ok = _controller->command("follow_distance_near", cmd_params);
        } else if (distance_level == "far") {
            ok = _controller->command("follow_distance_far", cmd_params);
        } else {
            detail_message = "FOLLOW_DIS failed: distance must be near/far";
            return false;
        }
        detail_message = ok ? "FOLLOW_DIS dispatched" : "FOLLOW_DIS failed";
        return ok;
    }
    if (cmd_type == FOLLOW_LOC) {
        bool ok = _controller->command("follow_location", cmd_params);
        detail_message = ok ? "FOLLOW_LOC dispatched" : "FOLLOW_LOC failed";
        return ok;
    }
    if (cmd_type == CHAT) {
        detail_message = "CHAT is disabled for robot_control";
        return false;
    }

    detail_message = "unsupported cmd_type";
    return false;
}

void RobotControllerNode::shutdown() {
    LOG_INFO("Shutting down RobotControllerNode...");
    _ready = false;
    if (_stateTimer) {
        _stateTimer->Stop();
    }
    if (_controller) {
        _controller->shutdown();
    }
}

void RobotControllerNode::_publishEvent(const std::string& event_type, const std::string& message) {
    auto event_msg = std::make_shared<std_msgs::msg::String>();

    std::ostringstream oss;
    double timestamp = rti::segar::Clock::Now().ToSecond();

    oss << "{\"timestamp\":" << std::fixed << std::setprecision(3) << timestamp << ",\"event_type\":\"" << event_type
        << "\",\"message\":\"" << message << "\"}";

    event_msg->data(oss.str());
    _eventsPub->Write(event_msg);
    LOG_DEBUG("[/robot/events] " << event_type << ": " << message);
}

void RobotControllerNode::_publishEventFromCore(const core::Event& event) {
    std::ostringstream oss;
    oss << "{\"timestamp\":" << std::fixed << std::setprecision(3) << event.timestamp << ",\"event_type\":\""
        << eventTypeToString(event.event_type) << "\",\"source\":\"" << event.source << "\"";
    if (!event.data.empty()) {
        oss << ",\"data\":{";
        bool first = true;
        for (const auto& [k, v] : event.data) {
            if (!first) {
                oss << ",";
            }
            first = false;
            oss << "\"" << k << "\":\"" << v << "\"";
        }
        oss << "}";
    }
    oss << "}";

    auto msg = std::make_shared<std_msgs::msg::String>();
    msg->data(oss.str());
    _eventsPub->Write(msg);

    if (shouldTraceCoreEvent(event.event_type)) {
        LOG_INFO("[/robot/events] " << msg->data());
    } else {
        LOG_DEBUG("[/robot/events] " << msg->data());
    }

    if (auto state_msg = _createFeedbackState(event)) {
        static auto last_state_log_time = std::chrono::steady_clock::now();
        auto now = std::chrono::steady_clock::now();
        if (std::chrono::duration<double>(now - last_state_log_time).count() >= 1.0 ||
            event.event_type != core::EventType::FOLLOW_HEARTBEAT) {
            LOG_INFO("[/robot_control/state] Publish state: task_name="
                     << state_msg->task_name() << ", task_state=" << state_msg->task_state()
                     << ", feedback_type=" << state_msg->feedback_type() << ", message=" << state_msg->message());
            last_state_log_time = now;
        }
        _robotStatePub->Write(std::make_shared<RobotStateMsg>(*state_msg));
    }
}

void RobotControllerNode::_publishPeriodicTpFunctionState() {
    if (!_tpFunctionStatePub) return;

    auto msg = std::make_shared<TpFunctionStateMsg>();
    uint64_t now_ms = rti::segar::Clock::Now().ToMillisecond();
    msg->header().stamp().sec(static_cast<int32_t>(now_ms / 1000));
    msg->header().stamp().nanosec(static_cast<uint32_t>((now_ms % 1000) * 1e6));

    auto current_type = _controller->function_manager->currentType().value_or(core::FunctionType::IDLE);
    auto current_status = _controller->function_manager->currentStatus().value_or(core::FunctionStatus::IDLE);

    using namespace tp_master_interfaces::msg::TpFunctionState_Constants;

    // Map FunctionType
    switch (current_type) {
        case core::FunctionType::FOLLOW:
            msg->function_type(FOLLOW);
            break;
        case core::FunctionType::WAKEUP:
            msg->function_type(NONE);
            break;
        case core::FunctionType::MOUNT_UP:
            msg->function_type(MOUNT_UP);
            break;
        default:
            msg->function_type(NONE);
            break;
    }

    // Map FunctionStatus
    switch (current_status) {
        case core::FunctionStatus::IDLE:
            msg->function_status(STATUS_IDLE);
            break;
        case core::FunctionStatus::INITIALIZING:
        case core::FunctionStatus::RUNNING:
            msg->function_status(STATUS_RUNNING);
            break;
        case core::FunctionStatus::PAUSED:
            msg->function_status(STATUS_PAUSED);
            break;
        case core::FunctionStatus::FAILED:
            msg->function_status(STATUS_ERROR);
            break;
        default:
            msg->function_status(STATUS_IDLE);
            break;
    }

    // Handle Follow-specific stages (Business Logic)
    if (msg->function_type() == FOLLOW) {
        auto follow_phase = _controller->blackboard->get<core::FollowPhase>("follow_phase", core::FollowPhase::IDLE);
        switch (follow_phase) {
            case core::FollowPhase::IDLE:
                msg->stage(FOLLOW_IDLE);
                break;
            case core::FollowPhase::ACTIVATION:
                msg->stage(17);  // FOLLOW_ACTIVATION as per plan
                break;
            case core::FollowPhase::FOLLOW:
                msg->stage(FOLLOW_FOLLOW);
                break;
            case core::FollowPhase::LOST:
                msg->stage(FOLLOW_LOST);
                break;
            case core::FollowPhase::TRAPPED:
                msg->stage(FOLLOW_TRAPPED);
                break;
            case core::FollowPhase::FAULT:
                msg->stage(FOLLOW_EXCEPTION);
                break;
        }
    } else if (current_type == core::FunctionType::MOUNT_UP) {
        std::lock_guard<std::mutex> lock(_mountup_stage_mutex);
        switch (_mountup_stage) {
            case core::MountupStage::IDLE:
                msg->stage(MOUNT_UP_IDLE);
                break;
            case core::MountupStage::CONTACT:
                msg->stage(MOUNT_UP_CONTACT);
                break;
            case core::MountupStage::CLIMBING:
                msg->stage(MOUNT_UP_CLIMB);
                break;
            case core::MountupStage::DOCKING:
                msg->stage(MOUNT_UP_DOCK);
                break;
            case core::MountupStage::FAULT:
                msg->stage(MOUNT_UP_EXCEPTION);
                break;
            default:
                msg->stage(MOUNT_UP_IDLE);
                break;
        }
    }

    _tpFunctionStatePub->Write(msg);
}

std::optional<RobotControllerNode::RobotStateMsg> RobotControllerNode::_createFeedbackState(const core::Event& event) {
    auto it = kEventFeedbackRegistry.find(event.event_type);
    if (it == kEventFeedbackRegistry.end()) {
        return std::nullopt;
    }

    RobotStateMsg state_msg;
    uint64_t now_ms = rti::segar::Clock::Now().ToMillisecond();
    state_msg.header().stamp().sec(static_cast<int32_t>(now_ms / 1000));
    state_msg.header().stamp().nanosec(static_cast<uint32_t>((now_ms % 1000) * 1e6));
    state_msg.seq(_currentSeq);

    const auto& info = it->second;
    state_msg.feedback_type(info.feedback_type);
    state_msg.task_name(info.task_name);
    state_msg.task_state(info.task_state);
    state_msg.message(getEventData(event, "message"));

    // Prefer explicit follow sub-state from blackboard when registry state is not specified.
    if (state_msg.task_state().empty() && state_msg.task_name() == "FOLLOW_TASK" && _controller) {
        auto follow_phase = _controller->blackboard->get<core::FollowPhase>("follow_phase", core::FollowPhase::IDLE);
        state_msg.task_state(core::toString(follow_phase));
    }

    return state_msg;
}

void RobotControllerNode::_bridgeCoreEventsToRos() {
    auto* bus = _controller->event_bus;
    auto subscribe_bridge = [this, bus](core::EventType type) {
        bus->subscribe(type, [this](const core::Event& event) { _publishEventFromCore(event); });
    };

    // Original events for general bridging
    subscribe_bridge(core::EventType::HMI_INTERACTION_REQUEST);
    subscribe_bridge(core::EventType::USER_COMMAND_WAKEUP);
    subscribe_bridge(core::EventType::USER_COMMAND_STOP_FOLLOW);
    subscribe_bridge(core::EventType::USER_COMMAND_FOLLOW_SPEED_UP);
    subscribe_bridge(core::EventType::USER_COMMAND_FOLLOW_SPEED_DOWN);
    subscribe_bridge(core::EventType::USER_COMMAND_FOLLOW_DISTANCE_NEAR);
    subscribe_bridge(core::EventType::USER_COMMAND_FOLLOW_DISTANCE_FAR);
    subscribe_bridge(core::EventType::USER_COMMAND_FOLLOW_LOCATION);
    subscribe_bridge(core::EventType::FOLLOW_HEARTBEAT);
    subscribe_bridge(core::EventType::FOLLOW_ACTIVATION_REQUESTED);
    subscribe_bridge(core::EventType::FOLLOW_ACTIVATE_RESULT);
    subscribe_bridge(core::EventType::FUNCTION_STARTED);
    subscribe_bridge(core::EventType::FUNCTION_COMPLETED);
    subscribe_bridge(core::EventType::FUNCTION_FAILED);
    subscribe_bridge(core::EventType::FACE_RECOG_RESULT);
    subscribe_bridge(core::EventType::TARGET_LOST);

    // Feedback specific events
    for (const auto& [type, info] : kEventFeedbackRegistry) {
        subscribe_bridge(type);
    }
}

}  // namespace interfaces
}  // namespace applications
}  // namespace robot_control
