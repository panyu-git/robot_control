#include "robot_control/applications/bt_nodes/mountup_nodes.hpp"

#include <string>

#include "robot_control/common/logging.hpp"

namespace robot_control {
namespace applications {
namespace bt_nodes {

namespace {

BT::NodeStatus pollPhaseStatus(const char* logger_name, const BT::Expected<core::FunctionStatus>& status) {
    if (!status) {
        LOG_ERROR_NAMED(logger_name, "missing status: " << status.error());
        return BT::NodeStatus::FAILURE;
    }
    if (*status == core::FunctionStatus::COMPLETED) {
        return BT::NodeStatus::SUCCESS;
    }
    if (*status == core::FunctionStatus::FAILED) {
        return BT::NodeStatus::FAILURE;
    }
    return BT::NodeStatus::RUNNING;
}

}  // namespace

ContactAction::ContactAction(const std::string& name, const BT::NodeConfig& config,
                             const interfaces::RobotContext* context)
    : BT::StatefulActionNode(name, config), _logger_name(name), _context(context) {}

BT::NodeStatus ContactAction::onStart() {
    std::string user_id;
    if (auto bb = config().blackboard) {
        user_id = bb->get<std::string>("bb_user_id");
    }

    LOG_INFO_NAMED(_logger_name.c_str(), "ContactAction: enter contact phase, user_id=" << user_id);
    return BT::NodeStatus::RUNNING;
}

BT::NodeStatus ContactAction::onRunning() {
    return pollPhaseStatus(_logger_name.c_str(), getInput<core::FunctionStatus>("status"));
}

void ContactAction::onHalted() {}

MountUpAction::MountUpAction(const std::string& name, const BT::NodeConfig& config)
    : BT::StatefulActionNode(name, config), _logger_name(name) {}

BT::NodeStatus MountUpAction::onStart() {
    const auto main_mode = getInput<core::MainMode>("main_mode");
    const auto sub_mode = getInput<core::SubMode>("sub_mode");
    if (!main_mode || !sub_mode) {
        LOG_ERROR_NAMED(_logger_name.c_str(), "MountUpAction: missing main_mode or sub_mode");
        return BT::NodeStatus::FAILURE;
    }
    (void)main_mode;
    (void)sub_mode;
    // TODO: navigation->startMountUp(*main_mode, *sub_mode);
    return BT::NodeStatus::RUNNING;
}

BT::NodeStatus MountUpAction::onRunning() {
    // _context->navigation->checkMountUpRuntime();
    return pollPhaseStatus(_logger_name.c_str(), getInput<core::FunctionStatus>("status"));
}

void MountUpAction::onHalted() {}

}  // namespace bt_nodes
}  // namespace applications
}  // namespace robot_control
