#pragma once

#include <cstdint>
#include <mutex>
#include <optional>
#include <rclcpp/rclcpp.hpp>
#include <rclcpp_action/rclcpp_action.hpp>
#include <string>
#include <tuple>

#include "perception_interfaces/action/target_tracking.hpp"
#include "robot_control/core/enums.hpp"
#include "robot_control/core/robot_control_configs.hpp"
#include "robot_control/services/service_base.hpp"

namespace robot_control {
namespace services {

struct TargetInfo {
    std::tuple<double, double, double> position;
    double confidence;
    std::tuple<double, double> velocity;
    double last_seen;
    std::string user_id;
};

class PerceptionService : public ServiceBase {
   public:
    static constexpr double CONFIDENCE_THRESHOLD = 0.3;

    PerceptionService(bool simulated = false);
    ~PerceptionService() override;

    void init(rclcpp::Node::SharedPtr node);

    bool _doInitialize() override;
    void _doShutdown() override;

    bool startActivationTracking(const std::string& user_id);
    void stopTracking();

    bool isTrackingServerOnline() const;
    bool isPerceptionFeedbackFresh(int64_t timeout_ms = core::FollowConfigs::kPerceptionTimeoutMs) const;
    bool targetLocked() const;
    bool faceAuthenticated() const;
    std::optional<std::tuple<double, double, double>> targetPosition() const;

    void updateSimulatedTarget(const TargetInfo& target);
    void clearTarget();

   private:
    bool _isPerceptionFeedbackFresh(int64_t timeout_ms) const;

    rclcpp_action::Client<perception_interfaces::action::TargetTracking>::SharedPtr _perception_client;
    rclcpp::Node::SharedPtr _node;

    /// Last accepted target_tracking goal (for async_cancel_goal).
    std::shared_ptr<rclcpp_action::ClientGoalHandle<perception_interfaces::action::TargetTracking>>
        _active_tracking_goal_handle;

    mutable std::mutex _mutex;
    std::optional<TargetInfo> _target;
    bool _face_authenticated;
    double _last_perception_feedback_time;
    mutable double _last_tracking_server_warn_time;
    std::uint64_t _follow_auth_session_id;
};

}  // namespace services
}  // namespace robot_control
