#pragma once

#include <atomic>
#include <map>
#include <memory>
#include <optional>
#include <rclcpp/rclcpp.hpp>
#include <string>
#include <thread>

#include "robot_control/applications/framework/function_manager.hpp"
#include "robot_control/applications/framework/task_manager.hpp"
#include "robot_control/applications/interfaces/command_handler.hpp"
#include "robot_control/applications/interfaces/robot_context.hpp"
#include "robot_control/core/blackboard.hpp"
#include "robot_control/core/events.hpp"
#include "robot_control/services/navigation_service.hpp"
#include "robot_control/services/perception_service.hpp"

namespace robot_control {
namespace applications {
namespace interfaces {

class RobotController {
   public:
    static constexpr double DEFAULT_TICK_RATE = 20.0;  // Hz
    static constexpr double WAKEUP_TIMEOUT_SEC = 10.0;

    RobotController(bool simulated = true, std::optional<double> tick_rate = std::nullopt);
    void init(rclcpp::Node::SharedPtr node);

    ~RobotController();

    // Public members for node access
    std::shared_ptr<core::Blackboard> blackboard;
    core::EventBus* event_bus;
    std::shared_ptr<services::NavigationService> navigation;
    std::shared_ptr<services::PerceptionService> perception;
    std::shared_ptr<framework::TaskManager> task_manager;
    std::shared_ptr<framework::FunctionManager> function_manager;
    std::shared_ptr<CommandHandler> command_handler;
    std::unique_ptr<RobotContext> robot_context;

    // Public API
    void start();
    void shutdown();

    bool command(const std::string& cmd, const std::map<std::string, std::string>& params = {});

   private:
    void _initComponents(rclcpp::Node::SharedPtr node);
    void _registerFunctions();

    void _controlLoop();

    std::atomic<bool> _running;
    std::unique_ptr<std::thread> _controlThread;
    double _tickRate;
    double _tickInterval;
    bool _simulated;
    std::string _logger_name = "RobotController";
};

}  // namespace interfaces
}  // namespace applications
}  // namespace robot_control
