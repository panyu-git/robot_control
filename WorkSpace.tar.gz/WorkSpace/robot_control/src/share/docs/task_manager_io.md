# Task Manager - Input/Output Specification

## Overview

The `TaskManager` is the Behavior Tree (BT) executor that manages task execution within functions.

---

## Constructor

### Input
```python
TaskManager(blackboard: Blackboard)
```

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `blackboard` | `Blackboard` | Yes | Shared state container |

### Output
- Returns: `TaskManager` instance

---

## Methods

### 1. register_tree()

Register a behavior tree.

#### Input
```python
register_tree(tree: BehaviorTree) -> None
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `tree` | `BehaviorTree` | Behavior tree to register |

#### Output
- Returns: `None`

#### Example
```python
tree = BehaviorTree("BT_FOLLOW", root_node)
manager.register_tree(tree)
# Input:  tree with name="BT_FOLLOW"
# Output: None (tree stored internally)
```

---

### 2. load_tree()

Load and activate a behavior tree.

#### Input
```python
load_tree(name: str) -> bool
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | `str` | Name of registered tree (e.g., "BT_FOLLOW") |

#### Output
- Returns: `bool` - `True` if loaded successfully

#### Example
```python
success = manager.load_tree("BT_FOLLOW")
# Input:  name="BT_FOLLOW"
# Output: True

success = manager.load_tree("BT_NONEXISTENT")
# Input:  name="BT_NONEXISTENT"
# Output: False
```

#### Side Effects
- Aborts currently running tree (if any)
- Resets the new tree
- Updates `blackboard.bt_execution.current_tree`
- Clears progress data

---

### 3. tick()

Execute one tick of the current behavior tree.

#### Input
```python
tick() -> Optional[NodeStatus]
```
- No parameters

#### Output
- Returns: `NodeStatus` or `None`

| Return Value | Description |
|--------------|-------------|
| `NodeStatus.SUCCESS` | Tree completed successfully |
| `NodeStatus.FAILURE` | Tree failed |
| `NodeStatus.RUNNING` | Tree still executing |
| `None` | No tree loaded or tree is paused |

#### Example
```python
manager.load_tree("BT_FOLLOW")

status = manager.tick()
# Input:  (none)
# Output: NodeStatus.RUNNING

# ... after tree completes ...
status = manager.tick()
# Output: NodeStatus.SUCCESS
```

---

### 4. abort()

Abort current tree execution.

#### Input
```python
abort() -> None
```
- No parameters

#### Output
- Returns: `None`

#### Side Effects
- Calls `tree.abort()` on current tree
- Sets `current_tree` to `None`
- Clears `blackboard.bt_execution.current_tree`

---

### 5. pause()

Pause tree execution.

#### Input
```python
pause() -> None
```
- No parameters

#### Output
- Returns: `None`

#### Side Effects
- Sets internal `_is_paused = True`
- `tick()` will return `None` while paused

---

### 6. resume()

Resume tree execution.

#### Input
```python
resume() -> None
```
- No parameters

#### Output
- Returns: `None`

#### Side Effects
- Sets internal `_is_paused = False`
- `tick()` will resume normal execution

---

### 7. get_tree()

Get a registered tree by name.

#### Input
```python
get_tree(name: str) -> Optional[BehaviorTree]
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | `str` | Tree name |

#### Output
- Returns: `BehaviorTree` or `None`

---

### 8. list_trees()

List all registered tree names.

#### Input
```python
list_trees() -> list
```
- No parameters

#### Output
- Returns: `list[str]` - List of tree names

#### Example
```python
names = manager.list_trees()
# Output: ["BT_FOLLOW", "BT_PHOTO", "BT_CHARGE"]
```

---

### 9. get_progress()

Get current execution progress.

#### Input
```python
get_progress() -> Dict[str, Any]
```
- No parameters

#### Output
- Returns: `Dict[str, Any]`

```python
{
    "tree": "BT_FOLLOW",        # Current tree name
    "tick_count": 150,          # Number of ticks executed
    "is_running": True,         # Whether tree is running
    "is_paused": False,         # Whether tree is paused
    # ... custom progress data from save_progress() ...
    "follow_ticks": 100,
    "follow_duration": 5.0,
}
```

---

### 10. save_progress()

Save progress data to blackboard.

#### Input
```python
save_progress(key: str, value: Any) -> None
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `key` | `str` | Progress data key |
| `value` | `Any` | Progress data value |

#### Output
- Returns: `None`

#### Example
```python
manager.save_progress("follow_ticks", 100)
manager.save_progress("follow_duration", 5.0)
# Stored in blackboard.bt_execution.progress
```

---

### 11. clear_progress()

Clear all progress data.

#### Input
```python
clear_progress() -> None
```
- No parameters

#### Output
- Returns: `None`

---

## Properties (Read-only Output)

| Property | Type | Description |
|----------|------|-------------|
| `current_tree` | `Optional[BehaviorTree]` | Current tree instance |
| `current_tree_name` | `Optional[str]` | Current tree name |
| `is_running` | `bool` | True if tree loaded and not paused |
| `is_paused` | `bool` | True if paused |

---

## Blackboard Writes (Output)

| Field | Type | Purpose |
|-------|------|---------|
| `bt_execution.current_tree` | `str` | Current tree name |
| `bt_execution.progress` | `Dict` | Progress data |

---

## BehaviorTree Class

### Constructor Input
```python
BehaviorTree(name: str, root: BTNode)
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | `str` | Tree identifier |
| `root` | `BTNode` | Root node of the tree |

### Methods

| Method | Input | Output | Description |
|--------|-------|--------|-------------|
| `tick()` | None | `NodeStatus` | Execute one tick |
| `reset()` | None | None | Reset tree state |
| `abort()` | None | None | Abort execution |

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `name` | `str` | Tree name |
| `root` | `BTNode` | Root node |
| `tick_count` | `int` | Number of ticks executed |

---

## Complete Usage Example

```python
from core.blackboard import Blackboard
from core.enums import NodeStatus
from applications.framework.task_manager import TaskManager, BehaviorTree
from applications.framework.bt_nodes import Sequence, SuccessNode

# Setup
blackboard = Blackboard()
manager = TaskManager(blackboard)

# Create and register tree
root = Sequence("root", blackboard, [
    SuccessNode("step1", blackboard),
    SuccessNode("step2", blackboard),
])
tree = BehaviorTree("BT_TEST", root)

manager.register_tree(tree)
# Input:  tree with name="BT_TEST"
# Output: None

# Load tree
success = manager.load_tree("BT_TEST")
# Input:  name="BT_TEST"
# Output: True

# Execute
while True:
    status = manager.tick()
    # Input:  (none)
    # Output: NodeStatus.RUNNING or SUCCESS or FAILURE

    if status == NodeStatus.SUCCESS:
        print("Tree completed!")
        break
    elif status == NodeStatus.FAILURE:
        print("Tree failed!")
        break

# Get last status
last = manager.last_status()
# Output: NodeStatus.RUNNING or SUCCESS or FAILURE or IDLE

# Get progress
progress = manager.get_progress()
# Output: {"tree": "BT_TEST", "tick_count": 2, "is_running": True, ...}
```

---

## Behavior Tree Node Types - Input/Output

### Composite Nodes

#### Sequence
```
Input:  List of child nodes
Output: SUCCESS if all children succeed
        FAILURE on first child failure
        RUNNING if current child is running
```

#### Selector
```
Input:  List of child nodes
Output: SUCCESS on first child success
        FAILURE if all children fail
        RUNNING if current child is running
```

#### Parallel
```
Input:  List of child nodes, success_threshold, failure_threshold
Output: SUCCESS if success_threshold met
        FAILURE if failure_threshold met
        RUNNING otherwise
```

### Decorator Nodes

#### Retry
```
Input:  Child node, max_attempts
Output: Child's SUCCESS
        FAILURE after max_attempts failures
        RUNNING while retrying
```

#### Timeout
```
Input:  Child node, timeout_seconds
Output: Child's result if completed in time
        FAILURE if timeout exceeded
```

#### Loop
```
Input:  Child node, max_iterations, stop_on_failure
Output: SUCCESS when iterations complete
        FAILURE if stop_on_failure and child fails
        RUNNING while looping
```

### Leaf Nodes

#### ActionNode
```
Input:  execute() method implementation
Output: NodeStatus from execute()
```

#### ConditionNode
```
Input:  check() method implementation (returns bool)
Output: SUCCESS if check() returns True
        FAILURE if check() returns False
```
