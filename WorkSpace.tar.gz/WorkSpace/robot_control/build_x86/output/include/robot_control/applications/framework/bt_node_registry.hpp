#pragma once

#include <memory>

#include "behaviortree_cpp/bt_factory.h"
#include "robot_control/core/blackboard.hpp"
#include "robot_control/services/navigation_service.hpp"
#include "robot_control/services/perception_service.hpp"

namespace robot_control {
namespace applications {
namespace framework {

/**
 * @brief BTNodeRegistry provides a centralized place to register all custom BT nodes.
 */
class BTNodeRegistry {
   public:
    /**
     * @brief Registers all custom nodes to the provided factory.
     */
    static void registerAllNodes(BT::BehaviorTreeFactory& factory, std::shared_ptr<core::Blackboard> blackboard);
};

}  // namespace framework
}  // namespace applications
}  // namespace robot_control
