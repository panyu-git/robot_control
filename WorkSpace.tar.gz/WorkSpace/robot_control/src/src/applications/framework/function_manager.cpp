#include "robot_control/applications/framework/function_manager.hpp"

#include <string>
#include <vector>

#include "robot_control/applications/framework/function_base.hpp"
#include "robot_control/applications/framework/function_registry.hpp"
#include "robot_control/common/logging.hpp"
#include "robot_control/core/enums.hpp"
#include "robot_control/core/robot_control_configs.hpp"

namespace robot_control {
namespace applications {
namespace framework {

FunctionManager::FunctionManager(std::shared_ptr<core::Blackboard> blackboard, IExecutionEngine* engine,
                                 core::EventBus* event_bus)
    : _blackboard(blackboard),
      _engine(engine),
      _eventBus(event_bus),
      _functionScheduler(std::make_unique<FunctionScheduler>()) {
    _eventBus = event_bus ? event_bus : &core::EventBus::getInstance();

    _setupPriorityValidators();
    _setupRequestTriggers();
}

void FunctionManager::registerRequestTrigger(const std::string& blackboard_key, core::FunctionType target_type) {
    _triggerMap.push_back({blackboard_key, target_type});
}

void FunctionManager::_setupRequestTriggers() {
    registerRequestTrigger(core::BlackboardKeys::CMD_FOLLOW_REQUEST, core::FunctionType::FOLLOW);
    registerRequestTrigger(core::BlackboardKeys::CMD_WAKEUP_REQUEST, core::FunctionType::WAKEUP);
}

void FunctionManager::_setupPriorityValidators() {
    _functionScheduler->registerValidation(
        core::FunctionType::FOLLOW,
        [](core::FunctionType /*target*/, core::FunctionType current_function) -> TransitionValidationResult {
            // Allow FOLLOW to preempt IDLE, WAKEUP, or another FOLLOW
            if (current_function != core::FunctionType::IDLE && current_function != core::FunctionType::FOLLOW &&
                current_function != core::FunctionType::WAKEUP) {
                return {false, "提醒用户当前状态不可进入跟随"};
            }
            return {true, ""};
        });

    _functionScheduler->registerValidation(
        core::FunctionType::WAKEUP,
        [](core::FunctionType /*target*/, core::FunctionType current_function) -> TransitionValidationResult {
            if (current_function == core::FunctionType::FOLLOW) {
                return {false, "提醒用户当前正在跟随，无法进行唤醒操作"};
            }
            return {true, ""};
        });
}

void FunctionManager::_updateFSMState(core::FunctionType target) {
    if (_blackboard->has(core::BlackboardKeys::FSM_CURRENT_STATE)) {
        auto prev_state =
            _blackboard->get<core::FunctionType>(core::BlackboardKeys::FSM_CURRENT_STATE, core::FunctionType::IDLE);
        _blackboard->set<std::optional<core::FunctionType>>(core::BlackboardKeys::FSM_PREVIOUS_STATE, prev_state);
    } else {
        _blackboard->set<std::optional<core::FunctionType>>(core::BlackboardKeys::FSM_PREVIOUS_STATE, std::nullopt);
    }
    _blackboard->set<core::FunctionType>(core::BlackboardKeys::FSM_CURRENT_STATE, target);
    _blackboard->set<std::chrono::steady_clock::time_point>(core::BlackboardKeys::FSM_STATE_START_TIME,
                                                            std::chrono::steady_clock::now());

    int transition_count = _blackboard->get<int>(core::BlackboardKeys::FSM_TRANSITION_COUNT, 0);
    _blackboard->set<int>(core::BlackboardKeys::FSM_TRANSITION_COUNT, transition_count + 1);
}

std::optional<core::FunctionType> FunctionManager::currentType() const {
    if (auto current = _functionScheduler->currentFunction()) {
        return current->functionType();
    }
    return std::nullopt;
}

std::optional<core::FunctionStatus> FunctionManager::currentStatus() const {
    if (auto current = _functionScheduler->currentFunction()) {
        return current->status();
    }
    return std::nullopt;
}

void FunctionManager::registerFunction(std::unique_ptr<Function> function) {
    auto shared_function = std::shared_ptr<Function>(std::move(function));
    auto func_type = shared_function->functionType();
    _functions[func_type] = shared_function;
}

Function* FunctionManager::getFunction(core::FunctionType func_type) {
    auto it = _functions.find(func_type);
    if (it != _functions.end()) {
        return it->second.get();
    }
    return nullptr;
}

bool FunctionManager::transitionTo(core::FunctionType target, bool save_context, bool restore_context, bool force) {
    (void)save_context;
    (void)restore_context;
    if (_functions.find(target) == _functions.end()) {
        return false;
    }

    auto before = _functionScheduler->currentFunction();
    std::optional<std::string> before_function_name;
    if (before) {
        before_function_name = core::toString(before->functionType());
    }

    bool transitioned = false;
    if (force && target == core::FunctionType::IDLE) {
        _functionScheduler->clear();
        transitioned = _functionScheduler->submitFunction(_functions[target]);
    } else if (target == core::FunctionType::IDLE) {
        // IDLE has LOW scheduler priority; to converge to baseline, drain scheduler first.
        if (before && before->functionType() == core::FunctionType::IDLE) {
            transitioned = true;
        } else {
            if (!_functionScheduler->drainUntilOrEmpty(core::FunctionType::IDLE)) {
                return false;
            }
            auto cur = _functionScheduler->currentFunction();
            const bool scheduler_empty = !cur;
            if (scheduler_empty) {
                transitioned = _functionScheduler->submitFunction(_functions[target]);
            } else {
                transitioned = (cur->functionType() == core::FunctionType::IDLE);
            }
        }
    } else {
        transitioned = _functionScheduler->submitFunction(_functions[target]);
    }

    if (!transitioned) {
        return false;
    }

    auto after = _functionScheduler->currentFunction();
    std::optional<std::string> after_function_name;
    if (after) {
        after_function_name = core::toString(after->functionType());
    }
    const bool running_presence_changed = before_function_name.has_value() != after_function_name.has_value();
    const bool running_type_changed = before_function_name.has_value() && after_function_name.has_value() &&
                                      before_function_name.value() != after_function_name.value();
    const bool changed = running_presence_changed || running_type_changed;

    if (before_function_name.has_value() && changed) {
        core::Event exit_event(core::EventType::FUNCTION_COMPLETED, "FunctionManager");
        exit_event.data["function"] = before_function_name.value();
        _eventBus->publish(exit_event);
    }

    if (after && changed) {
        _ensureEngineSynced();

        core::Event enter_event(core::EventType::FUNCTION_STARTED, "FunctionManager");
        enter_event.data["function"] = core::toString(after->functionType());
        _eventBus->publish(enter_event);
    }

    return true;
}

std::optional<core::FunctionStatus> FunctionManager::tick() {
    _checkPriorityEvents();
    auto current = _functionScheduler->currentFunction();
    if (!current) return std::nullopt;

    _ensureEngineSynced();

    // 1. Pre-execution (Business rules & Health checks)
    auto status = current->preTick();

    // 2. Core Execution (Only if not already finished in preTick)
    if (status != core::FunctionStatus::COMPLETED && status != core::FunctionStatus::FAILED) {
        core::NodeStatus engine_status = core::NodeStatus::IDLE;
        const bool uses_shared_engine = current->functionType() != core::FunctionType::MOUNT_UP;
        if (uses_shared_engine && _engine && _engine->isRunning() &&
            current->functionType() != core::FunctionType::IDLE) {
            engine_status = _engine->tick();
            _engine->onPostTick();
        }

        status = current->postTick();

        // Recovery: Reset engine for retry if business logic allows.
        // If the engine finished (SUCCESS or FAILURE) but the function is still RUNNING,
        // it means we need to restart the engine to handle the next phase or retry.
        if (engine_status != core::NodeStatus::RUNNING && engine_status != core::NodeStatus::IDLE &&
            status == core::FunctionStatus::RUNNING) {
            if (_engine) _engine->reset();
        }
    }

    // 3. Finalization: Handle terminal states
    switch (status) {
        case core::FunctionStatus::COMPLETED:
            _handleFunctionCompleted();
            break;
        case core::FunctionStatus::FAILED:
            _handleFunctionFailed();
            break;
        default:
            break;
    }

    return status;
}

void FunctionManager::warmup() {
    if (!_engine) return;

    auto preloads = FunctionRegistry::getInstance().getAllPreload();
    for (const auto& desc : preloads) {
        if (!desc.resource_path.empty()) {
            _engine->preload(desc.resource_name, desc.resource_path);
        }
    }
}

void FunctionManager::_checkPriorityEvents() {
    if (_blackboard->get<bool>(core::BlackboardKeys::SENSOR_EMERGENCY_STOP, false)) {
        auto current_type = currentType();
        if (!current_type.has_value() || current_type.value() != core::FunctionType::IDLE) {
            if (transitionTo(core::FunctionType::IDLE, false, false, true)) {
                _blackboard->set(core::BlackboardKeys::SENSOR_EMERGENCY_STOP, false);
            } else {
                LOG_ERROR_NAMED("FunctionManager", "CRITICAL: Failed to transition to IDLE during emergency stop!");
            }
        } else {
            _blackboard->set(core::BlackboardKeys::SENSOR_EMERGENCY_STOP, false);
        }
        return;
    }

    _candidatesBuffer.clear();
    for (const auto& [key, type] : _triggerMap) {
        if (_blackboard->get<bool>(key, false)) {
            if (auto func = _functions[type]) {
                _candidatesBuffer.push_back(func);
            }
            _blackboard->set(key, false);
        }
    }

    if (!_candidatesBuffer.empty()) {
        auto result = _functionScheduler->submitBestOf(_candidatesBuffer);

        if (!result.validation.allowed) {
            int session_id = _blackboard->get<int>(core::BlackboardKeys::FOLLOW_ACTIVATION_SESSION_ID, 0);
            _sendInteractionFeedback(result.validation.reject_message, session_id);
        } else if (!result.success && result.winner_type != core::FunctionType::IDLE) {
            int session_id = _blackboard->get<int>(core::BlackboardKeys::FOLLOW_ACTIVATION_SESSION_ID, 0);
            _sendInteractionFeedback("状态切换失败: " + core::toString(result.winner_type), session_id);
        }
    }
}

void FunctionManager::_ensureEngineSynced() {
    auto target = currentType();

    // 1. Early exit if state hasn't changed
    if (_lastSyncedType == target) {
        return;
    }

    // 2. Sync Execution Engine
    if (_engine) {
        if (target.has_value()) {
            LOG_INFO_NAMED("FunctionManager", "Syncing engine resource for: " << core::toString(target.value()));
            _engine->setStatusNamespace(core::toString(target.value()));

            auto* desc = FunctionRegistry::getInstance().get(target.value());
            if (desc && !desc->resource_path.empty()) {
                if (!_engine->load(desc->resource_name, desc->resource_path)) {
                    LOG_ERROR_NAMED("FunctionManager", "Failed to load resource [" << desc->resource_path << "] for "
                                                                                   << core::toString(target.value()));
                    // DO NOT update _lastSyncedType, allow retry on next tick
                    return;
                }
            } else {
                _engine->reset();
            }
        } else {
            LOG_INFO_NAMED("FunctionManager", "Engine reset: no active function");
            _engine->reset();
        }
    }

    // 3. Sync FSM State (Blackboard)
    if (target.has_value()) {
        _updateFSMState(target.value());
    }

    // 4. Update tracking state
    _lastSyncedType = target;
}

void FunctionManager::_sendInteractionFeedback(const std::string& message, int session_id) {
    if (!_eventBus) return;
    core::Event event(core::EventType::HMI_INTERACTION_REQUEST, "FunctionManager");
    event.data["message"] = message;
    event.data["session_id"] = std::to_string(session_id);
    _eventBus->publish(event);
}

void FunctionManager::_handleFunctionCompleted() {
    if (!_functionScheduler->currentFunction()) return;
    _functionScheduler->completeCurrentFunction();
    auto current = _functionScheduler->currentFunction();
    if (!current) {
        transitionTo(core::FunctionType::IDLE, false, false, false);
    }
}

void FunctionManager::_handleFunctionFailed() {
    auto current_type = currentType();
    if (!current_type.has_value()) {
        return;
    }

    // Publish failure event
    core::Event failure_event(core::EventType::FUNCTION_FAILED, "FunctionManager");
    failure_event.data["function"] = core::toString(current_type.value());
    _eventBus->publish(failure_event);

    _functionScheduler->failCurrentFunction();
    auto current = _functionScheduler->currentFunction();
    if (!current) {
        transitionTo(core::FunctionType::IDLE, false, false, false);
    }
}

}  // namespace framework
}  // namespace applications
}  // namespace robot_control
