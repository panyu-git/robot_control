#include "robot_control/services/sensor_data_service.hpp"

#include <iomanip>
#include <sstream>

namespace robot_control {
namespace services {

SensorDataService::SensorDataService(bool simulated)
    : ServiceBase("SensorDataService", simulated),
      _cmd_id(0),
      _wheel_raw(0),
      _grip_raw(0),
      _lock_raw(0),
      _motor_raw(0),
      _lock_motor(0),
      _version(0) {}

SensorDataService::~SensorDataService() {
    _doShutdown();
}

void SensorDataService::init(rclcpp::Node::SharedPtr node) {
    _node = node;
    if (_node) {
        _subscribe_topic = _node->declare_parameter<std::string>("sensor_subscribe_topic", "/sensor_raw_data");
        _publish_topic = _node->declare_parameter<std::string>("sensor_publish_topic", "/sensor_command");
    }
    initialize();
}

bool SensorDataService::_doInitialize() {
    if (!_node) {
        LOG_ERROR("[SensorDataService] Node is null, cannot initialize");
        return false;
    }

    _subscription = _node->create_subscription<std_msgs::msg::UInt8MultiArray>(
        _subscribe_topic, 10, std::bind(&SensorDataService::topicCallback, this, std::placeholders::_1));

    _publisher = _node->create_publisher<std_msgs::msg::UInt8MultiArray>(_publish_topic, 10);

    LOG_INFO("[SensorDataService] Subscribed to topic: " << _subscribe_topic);
    LOG_INFO("[SensorDataService] Publishing to topic: " << _publish_topic);

    return true;
}

void SensorDataService::_doShutdown() {
    _subscription.reset();
    _publisher.reset();
    _node.reset();
}

void SensorDataService::sendCompleteProtocol(uint16_t report_period, const std::array<uint8_t, 6>& wheel_states,
                                             bool grip_success, bool lock_success, bool unlock_success) {
    std::vector<uint8_t> packet;
    packet.reserve(15);

    packet.push_back(0x01);
    packet.push_back(static_cast<uint8_t>(report_period & 0xFF));
    packet.push_back(static_cast<uint8_t>((report_period >> 8) & 0xFF));

    uint16_t packed_states = 0;
    for (int i = 0; i < 6; ++i) {
        uint8_t state = wheel_states[i] & 0x03;
        packed_states |= (static_cast<uint16_t>(state) << (i * 2));
    }
    packet.push_back(0x03);
    packet.push_back(static_cast<uint8_t>(packed_states & 0xFF));
    packet.push_back(static_cast<uint8_t>((packed_states >> 8) & 0xFF));

    packet.push_back(0x04);
    packet.push_back(grip_success ? 0 : 1);

    packet.push_back(0x05);

    packet.push_back(0x06);
    packet.push_back(lock_success ? 0 : 1);

    packet.push_back(0x07);

    packet.push_back(0x08);
    packet.push_back(unlock_success ? 0 : 1);

    packet.push_back(0x02);

    publishCommand(packet);
}

void SensorDataService::sendRawData(const std::vector<uint8_t>& data) {
    publishCommand(data);
}

void SensorDataService::publishCommand(const std::vector<uint8_t>& data) {
    if (!_publisher) {
        LOG_WARN("[SensorDataService] Publisher not initialized, cannot send data");
        return;
    }

    auto msg = std_msgs::msg::UInt8MultiArray();
    msg.data = data;
    _publisher->publish(msg);
}

void SensorDataService::topicCallback(const std_msgs::msg::UInt8MultiArray::SharedPtr msg) {
    if (msg->data.size() < 12) {
        LOG_WARN("[SensorDataService] 收到数据不足12字节，忽略 (size=" << msg->data.size() << ")");
        return;
    }

    const auto& d = msg->data;

    uint8_t cmd_id = d[0];
    uint32_t wheel_raw = (static_cast<uint32_t>(d[1])) | (static_cast<uint32_t>(d[2]) << 8) |
                         (static_cast<uint32_t>(d[3]) << 16) | (static_cast<uint32_t>(d[4]) << 24);
    uint16_t grip_raw = (static_cast<uint16_t>(d[5])) | (static_cast<uint16_t>(d[6]) << 8);
    uint8_t lock_raw = d[7];
    uint16_t motor_raw = (static_cast<uint16_t>(d[8])) | (static_cast<uint16_t>(d[9]) << 8);
    uint8_t lock_motor = d[10];
    uint8_t version = d[11];

    std::lock_guard<std::mutex> lock(_mutex);
    _latest_data = msg->data;
    _cmd_id = cmd_id;
    _wheel_raw = wheel_raw;
    _grip_raw = grip_raw;
    _lock_raw = lock_raw;
    _motor_raw = motor_raw;
    _lock_motor = lock_motor;
    _version = version;
}

bool SensorDataService::getLatestSensorData(std::vector<uint8_t>& data) const {
    std::lock_guard<std::mutex> lock(_mutex);
    if (_latest_data.empty()) {
        return false;
    }
    data = _latest_data;
    return true;
}

std::map<std::string, std::string> SensorDataService::getSensorInfo() const {
    std::lock_guard<std::mutex> lock(_mutex);
    std::map<std::string, std::string> info;

    info["cmd_id"] = std::to_string(static_cast<int>(_cmd_id));
    info["version"] = std::to_string(static_cast<int>(_version));
    info["lock_motor"] = (_lock_motor == 0) ? "locked" : "unlocked";

    std::ostringstream wheel_oss;
    for (int i = 0; i < 22; ++i) {
        wheel_oss << ((_wheel_raw >> i) & 0x01);
        if (i < 21) {
            wheel_oss << ",";
        }
    }
    info["wheel_sensors"] = wheel_oss.str();

    return info;
}

}  // namespace services
}  // namespace robot_control
