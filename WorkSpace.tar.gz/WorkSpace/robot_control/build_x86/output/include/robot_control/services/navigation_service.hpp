#pragma once

#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <nlohmann/json.hpp>
#include <optional>
#include <string>
#include <tuple>

#include "nav_interfaces/action/NavTaskJson.hpp"
#include "nav_interfaces/msg/FollowTask.hpp"
#include "robot_control/core/enums.hpp"
#include "robot_control/services/service_base.hpp"
#include "segar/segar.h"
#include "usr_msg/geometry_msgs/msg/Pose2D.hpp"

namespace robot_control {
namespace services {

enum class NavigationMode { IDLE, FOLLOW_HUMAN, NAVIGATE_TO_POSE, NAVIGATE_TO_LOCATION };

// GoalStatus mapping for Segar
enum class GoalStatus { UNKNOWN, ACCEPTED, EXECUTING, CANCELING, SUCCEEDED, CANCELED, ABORTED };

class NavigationService : public ServiceBase {
   public:
    static constexpr double CONFIDENCE_THRESHOLD = 0.3;

    NavigationService(bool simulated = false);
    virtual ~NavigationService();

    void init(std::shared_ptr<rti::segar::Node> node);

    // Lifecycle overrides
    bool _doInitialize() override;
    void _doShutdown() override;

    // Commands
    bool startFollow(const std::string& mode, double distance, double speed, const std::string& user_id = "");
    bool requestFollowTask(const std::string& task, const std::string& user_id,
                           const std::map<std::string, std::string>& params = {});
    bool updateFollowParams(std::optional<double> distance, std::optional<double> speed);
    bool updateFollowPosition(const std::string& mode);
    void stopFollow();
    std::map<std::string, std::string> pauseFollow();
    bool resumeFollow(const std::map<std::string, std::string>& context);
    void resetFollowState();

    core::NavigationStatus update();

    bool navigateToPose(double x, double y, double theta, std::function<void(bool)> callback = nullptr);
    bool navigateToLocation(const std::string& name, std::function<void(bool)> callback = nullptr);
    bool navigateToChargingStation(std::function<void(bool)> callback = nullptr);
    bool cancelNavigation();
    bool stopNavigation();

    // Status checks
    bool isReady() const;
    bool isNavServerOnline() const;
    bool isNavigationComplete() const;
    bool isNavigationSuccessful() const;
    bool isNavFeedbackFresh(int64_t timeout_ms = 3000) const;

    // Properties
    core::NavigationStatus navigationStatus() const;
    bool isNavFeedbackInterrupted() const;
    double getLastNavFeedbackTime() const;
    std::optional<double> getTargetTimeout() const;
    std::tuple<double, double, double> currentPose() const;

    // Feedback
    std::map<std::string, std::string> getFeedback() const;

   private:
    mutable std::mutex _mutex;
    core::NavigationStatus _status_nav;
    NavigationMode _mode;
    std::map<std::string, std::string> _follow_params;
    double _last_follow_trace_time;
    double _last_nav_feedback_time;
    mutable double _last_nav_timeout_warn_time;

    std::string _last_task_name;
    std::string _last_task_state;
    std::string _last_task_message;
    std::optional<double> _target_timeout;

    using ActionClient = rti::segar::action::ActionClient<nav_interfaces::action::NavTaskJson>;
    std::shared_ptr<ActionClient> _nav_client;
    std::shared_ptr<rti::segar::Writer<nav_interfaces::msg::FollowTask>> _follow_task_pub;
    std::shared_ptr<rti::segar::Node> _node;

    rti::segar::action::GoalID _active_goal_id;
    GoalStatus _nav_goal_status;
    uint64_t _current_goal_id = 0;
    geometry_msgs::msg::Pose2D _current_pose;
    std::optional<std::string> _goal_location;
    std::function<void(bool)> _navigation_complete_callback;

    void _processNavStatusJson(const std::string& json_str);

    // Private versions of status checks
    bool _isNavFeedbackFresh(int64_t timeout_ms) const;
    core::NavigationStatus _navigationStatus() const;
    bool _isNavigationComplete() const;
    bool _isNavigationSuccessful() const;
    std::tuple<double, double, double> _currentPose() const;
};

}  // namespace services
}  // namespace robot_control
