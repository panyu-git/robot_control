#pragma once

#include "segar/common/log.h"

/**
 * @brief Common logging macros for the robot_control project.
 * These macros map to the Segar logging system, providing a stream-based interface.
 *
 * LOG_*(msg) macros require `_logger_name` in scope.
 * LOG_*_NAMED(logger_name, msg) macros accept explicit logger name.
 */

#define LOG_DEBUG_NAMED(logger_name, msg) ADEBUG << "[" << logger_name << "] " << msg
#define LOG_INFO_NAMED(logger_name, msg) AINFO << "[" << logger_name << "] " << msg
#define LOG_WARN_NAMED(logger_name, msg) AWARN << "[" << logger_name << "] " << msg
#define LOG_ERROR_NAMED(logger_name, msg) AERROR << "[" << logger_name << "] " << msg
#define LOG_FATAL_NAMED(logger_name, msg) AFATAL << "[" << logger_name << "] " << msg

#define LOG_DEBUG(msg) LOG_DEBUG_NAMED(_logger_name, msg)
#define LOG_INFO(msg) LOG_INFO_NAMED(_logger_name, msg)
#define LOG_WARN(msg) LOG_WARN_NAMED(_logger_name, msg)
#define LOG_ERROR(msg) LOG_ERROR_NAMED(_logger_name, msg)
#define LOG_FATAL(msg) LOG_FATAL_NAMED(_logger_name, msg)
