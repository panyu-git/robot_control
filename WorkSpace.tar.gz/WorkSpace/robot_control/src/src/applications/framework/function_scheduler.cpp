#include "robot_control/applications/framework/function_scheduler.hpp"

#include <algorithm>
#include <sstream>
#include <utility>

namespace robot_control {
namespace applications {
namespace framework {

void FunctionScheduler::registerValidation(core::FunctionType target, ValidationFn validator) {
    std::lock_guard<std::mutex> lock(mutex_);
    _validators[target] = std::move(validator);
}

TransitionValidationResult FunctionScheduler::validate(core::FunctionType target, core::FunctionType current_function) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = _validators.find(target);
    if (it != _validators.end()) {
        return it->second(target, current_function);
    }
    return {true, ""};
}

std::string FunctionScheduler::FunctionBundle::bundleName() const {
    std::ostringstream oss;
    oss << "{";
    for (std::size_t i = 0; i < functions.size(); ++i) {
        if (i > 0) {
            oss << "+";
        }
        const auto& fn = functions[i];
        oss << (fn ? fn->functionName() : "null");
    }
    oss << "}";
    return oss.str();
}

void FunctionScheduler::registerFunctionFactory(const std::string& function_name, FunctionFactory factory) {
    std::lock_guard<std::mutex> lock(mutex_);
    function_factories_[function_name] = std::move(factory);
}

SubmissionResult FunctionScheduler::submitBestOf(const std::vector<std::shared_ptr<Function>>& candidates) {
    std::shared_ptr<Function> best_valid = nullptr;
    std::shared_ptr<Function> best_overall = nullptr;
    auto current_type = currentFunction() ? currentFunction()->functionType() : core::FunctionType::IDLE;

    for (const auto& c : candidates) {
        if (!c) continue;

        int p = c->schedulerPriority();

        // 1. Track the most preferred candidate regardless of validity for feedback
        if (!best_overall || p > best_overall->schedulerPriority()) {
            best_overall = c;
        }

        // 2. Lazy Validation: only validate if it's potentially better than our current best_valid
        if (!best_valid || p > best_valid->schedulerPriority()) {
            if (validate(c->functionType(), current_type).allowed) {
                best_valid = c;
            }
        }
    }

    SubmissionResult result;
    if (best_valid) {
        result.winner_type = best_valid->functionType();
        result.success = submitFunction(best_valid);
        result.validation = {true, ""};
    } else if (best_overall) {
        // Return validation error of the best overall candidate
        result.winner_type = best_overall->functionType();
        result.validation = validate(result.winner_type, current_type);
    }
    return result;
}

bool FunctionScheduler::submitFunction(const std::shared_ptr<Function>& function) {
    return submitFunctionBundle({function});
}

bool FunctionScheduler::submitFunctionBundle(const std::vector<std::shared_ptr<Function>>& functions) {
    if (functions.empty()) {
        return false;
    }
    for (const auto& function : functions) {
        if (!function) {
            return false;
        }
    }

    std::lock_guard<std::mutex> lock(mutex_);
    auto bundle = _createBundleFromFunctionsUnlocked(functions);
    if (bundle.functions.empty()) {
        return false;
    }

    if (!running_bundle_.has_value()) {
        auto first = bundle.currentFunction();
        if (!first) {
            return false;
        }
        first->setStatus(core::FunctionStatus::RUNNING);
        running_bundle_ = std::move(bundle);
        running_bundle_->currentFunction()->onEnter(std::nullopt);
        return true;
    }

    if (bundle.effective_priority >= running_bundle_->effective_priority) {
        auto running_current = running_bundle_->currentFunction();
        if (!running_current) {
            return false;
        }
        running_current->setStatus(core::FunctionStatus::PAUSED);
        const auto paused_context = running_current->onPause();
        if (paused_context.has_value()) {
            pause_contexts_[running_current->functionId()] = *paused_context;
        }
        paused_function_stack_.push(*running_bundle_);

        auto first = bundle.currentFunction();
        if (!first) {
            return false;
        }
        first->setStatus(core::FunctionStatus::RUNNING);
        running_bundle_ = std::move(bundle);
        running_bundle_->currentFunction()->onEnter(std::nullopt);
        return true;
    }

    for (const auto& waiting_fn : bundle.functions) {
        waiting_fn->setStatus(core::FunctionStatus::PAUSED);
    }
    _insertWaitingFunctionUnlocked(std::move(bundle));
    return true;
}

bool FunctionScheduler::stopCurrentFunction() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!running_bundle_.has_value()) {
        return false;
    }

    auto current = running_bundle_->currentFunction();
    if (!current) {
        running_bundle_.reset();
        return _promoteNextFunctionUnlocked();
    }
    current->onExit();

    if (_promoteNextFunctionInRunningBundleUnlocked()) {
        return true;
    }

    running_bundle_.reset();
    return _promoteNextFunctionUnlocked();
}

bool FunctionScheduler::failCurrentFunction() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!running_bundle_.has_value()) {
        return false;
    }

    auto current = running_bundle_->currentFunction();
    if (current) {
        current->onExit();
    }

    running_bundle_.reset();
    return _promoteNextFunctionUnlocked();
}

bool FunctionScheduler::drainUntilOrEmpty(core::FunctionType target_type) {
    std::lock_guard<std::mutex> lock(mutex_);
    while (true) {
        if (!running_bundle_.has_value()) {
            return true;
        }
        auto current = running_bundle_->currentFunction();
        if (current && current->functionType() == target_type) {
            return true;
        }

        if (current) {
            current->onExit();
        }
        running_bundle_.reset();
        if (!_promoteNextFunctionUnlocked()) {
            if (!running_bundle_.has_value()) {
                return true;
            }
            return false;
        }
    }
}

std::string FunctionScheduler::dumpToJsonString() const {
    std::lock_guard<std::mutex> lock(mutex_);
    try {
        json payload;

        const auto serialize_bundle = [&](const FunctionBundle& bundle) {
            json bundle_json;
            bundle_json["bundle_id"] = bundle.bundle_id;
            bundle_json["bundle_name"] = bundle.bundleName();
            bundle_json["current_index"] = bundle.current_index;
            bundle_json["effective_priority"] = bundle.effective_priority;
            bundle_json["functions"] = json::array();
            for (const auto& function : bundle.functions) {
                bundle_json["functions"].push_back(function ? function->toJson() : json(nullptr));
            }
            return bundle_json;
        };

        payload["running_bundle"] = running_bundle_.has_value() ? serialize_bundle(*running_bundle_) : json(nullptr);
        payload["paused_bundles"] = json::array();
        const auto paused_snapshot = _pausedTopFirstUnlocked();
        for (const auto& bundle : paused_snapshot) {
            payload["paused_bundles"].push_back(serialize_bundle(bundle));
        }

        payload["waiting_bundles"] = json::array();
        for (const auto& bundle : waiting_function_queue_) {
            payload["waiting_bundles"].push_back(serialize_bundle(bundle));
        }

        payload["running_function"] = (running_bundle_.has_value() && running_bundle_->currentFunction())
                                          ? running_bundle_->currentFunction()->toJson()
                                          : json(nullptr);
        payload["paused_functions"] = json::array();
        for (const auto& bundle : paused_snapshot) {
            auto fn = bundle.currentFunction();
            payload["paused_functions"].push_back(fn ? fn->toJson() : json(nullptr));
        }
        payload["waiting_functions"] = json::array();
        for (const auto& bundle : waiting_function_queue_) {
            auto fn = bundle.currentFunction();
            payload["waiting_functions"].push_back(fn ? fn->toJson() : json(nullptr));
        }

        return payload.dump();
    } catch (...) {
        return "{}";
    }
}

bool FunctionScheduler::loadFromJsonString(const std::string& json_str) {
    json payload;
    try {
        payload = json::parse(json_str);
    } catch (...) {
        return false;
    }

    std::lock_guard<std::mutex> lock(mutex_);
    _resetRuntimeStateUnlocked();
    return _loadRunningBundleUnlocked(payload) && _loadPausedBundlesUnlocked(payload) &&
           _loadWaitingBundlesUnlocked(payload);
}

void FunctionScheduler::_resetRuntimeStateUnlocked() {
    running_bundle_.reset();
    paused_function_stack_ = std::stack<FunctionBundle>();
    waiting_function_queue_.clear();
    pause_contexts_.clear();
}

bool FunctionScheduler::_loadRunningBundleUnlocked(const json& payload) {
    if (payload.contains("running_bundle") && !payload["running_bundle"].is_null()) {
        FunctionBundle running_bundle;
        if (!_bundleFromJsonUnlocked(payload["running_bundle"], core::FunctionStatus::RUNNING, &running_bundle)) {
            return false;
        }
        running_bundle_ = std::move(running_bundle);
        return true;
    }

    const auto running_key = payload.contains("running_function") ? "running_function" : "running_task";
    if (!payload.contains(running_key) || payload[running_key].is_null()) {
        return true;
    }

    auto running = _createFunctionFromJsonUnlocked(payload[running_key]);
    if (!running) {
        return false;
    }
    running->setStatus(core::FunctionStatus::RUNNING);
    running_bundle_ = _bundleFromLegacyFunctionUnlocked(running);
    return true;
}

bool FunctionScheduler::_loadPausedBundlesUnlocked(const json& payload) {
    if (payload.contains("paused_bundles")) {
        return _loadBundleArrayUnlocked(payload, "paused_bundles", nullptr, &paused_function_stack_);
    }

    const auto paused_key = payload.contains("paused_functions") ? "paused_functions" : "paused_stack";
    if (!payload.contains(paused_key) || !payload[paused_key].is_array()) {
        return true;
    }

    std::vector<FunctionBundle> paused_buffer;
    for (const auto& function_json : payload[paused_key]) {
        auto function = _createFunctionFromJsonUnlocked(function_json);
        if (!function) {
            return false;
        }
        function->setStatus(core::FunctionStatus::PAUSED);
        paused_buffer.push_back(_bundleFromLegacyFunctionUnlocked(function));
    }
    for (auto it = paused_buffer.rbegin(); it != paused_buffer.rend(); ++it) {
        paused_function_stack_.push(*it);
    }
    return true;
}

bool FunctionScheduler::_loadWaitingBundlesUnlocked(const json& payload) {
    if (payload.contains("waiting_bundles")) {
        return _loadBundleArrayUnlocked(payload, "waiting_bundles", &waiting_function_queue_, nullptr);
    }

    const auto waiting_key = payload.contains("waiting_functions") ? "waiting_functions" : "waiting_queue";
    if (!payload.contains(waiting_key) || !payload[waiting_key].is_array()) {
        return true;
    }

    for (const auto& function_json : payload[waiting_key]) {
        auto function = _createFunctionFromJsonUnlocked(function_json);
        if (!function) {
            return false;
        }
        function->setStatus(core::FunctionStatus::PAUSED);
        waiting_function_queue_.push_back(_bundleFromLegacyFunctionUnlocked(function));
    }
    return true;
}

bool FunctionScheduler::_bundleFromJsonUnlocked(const json& bundle_json, core::FunctionStatus current_status,
                                                FunctionBundle* out_bundle) {
    if (!out_bundle || !bundle_json.is_object() || !bundle_json.contains("functions") ||
        !bundle_json["functions"].is_array()) {
        return false;
    }

    std::vector<std::shared_ptr<Function>> functions;
    for (const auto& function_json : bundle_json["functions"]) {
        auto function = _createFunctionFromJsonUnlocked(function_json);
        if (!function) {
            return false;
        }
        functions.push_back(function);
    }
    if (functions.empty()) {
        return false;
    }

    auto bundle = _createBundleFromFunctionsUnlocked(functions);
    if (bundle_json.contains("bundle_id") && bundle_json["bundle_id"].is_string()) {
        bundle.bundle_id = bundle_json["bundle_id"].get<std::string>();
    }
    if (bundle_json.contains("current_index") && bundle_json["current_index"].is_number_unsigned()) {
        bundle.current_index = bundle_json["current_index"].get<std::size_t>();
        if (bundle.current_index >= bundle.functions.size()) {
            return false;
        }
    }
    if (bundle_json.contains("effective_priority") && bundle_json["effective_priority"].is_number_integer()) {
        bundle.effective_priority = bundle_json["effective_priority"].get<int>();
    }
    auto current = bundle.currentFunction();
    if (!current) {
        return false;
    }
    current->setStatus(current_status);
    *out_bundle = std::move(bundle);
    return true;
}

std::shared_ptr<Function> FunctionScheduler::currentFunction() const {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!running_bundle_.has_value()) {
        return nullptr;
    }
    return running_bundle_->currentFunction();
}

std::size_t FunctionScheduler::pausedFunctionSize() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return paused_function_stack_.size();
}

std::size_t FunctionScheduler::waitingFunctionSize() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return waiting_function_queue_.size();
}

std::vector<std::string> FunctionScheduler::pausedFunctionNamesTopFirst() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<std::string> names;
    const auto paused_snapshot = _pausedTopFirstUnlocked();
    names.reserve(paused_snapshot.size());
    for (const auto& bundle : paused_snapshot) {
        auto current = bundle.currentFunction();
        if (current) {
            names.push_back(current->functionName());
        }
    }
    return names;
}

std::vector<std::string> FunctionScheduler::waitingFunctionNames() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<std::string> names;
    names.reserve(waiting_function_queue_.size());
    for (const auto& bundle : waiting_function_queue_) {
        auto current = bundle.currentFunction();
        if (current) {
            names.push_back(current->functionName());
        }
    }
    return names;
}

std::vector<std::string> FunctionScheduler::pausedBundleNamesTopFirst() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<std::string> names;
    const auto paused_snapshot = _pausedTopFirstUnlocked();
    names.reserve(paused_snapshot.size());
    for (const auto& bundle : paused_snapshot) {
        names.push_back(bundle.bundleName());
    }
    return names;
}

std::vector<std::string> FunctionScheduler::waitingBundleNames() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<std::string> names;
    names.reserve(waiting_function_queue_.size());
    for (const auto& bundle : waiting_function_queue_) {
        names.push_back(bundle.bundleName());
    }
    return names;
}

void FunctionScheduler::clear() {
    std::lock_guard<std::mutex> lock(mutex_);
    running_bundle_.reset();
    paused_function_stack_ = std::stack<FunctionBundle>();
    waiting_function_queue_.clear();
    pause_contexts_.clear();
}

void FunctionScheduler::_insertWaitingFunctionUnlocked(FunctionBundle bundle) {
    const auto insert_pos = std::find_if(
        waiting_function_queue_.begin(), waiting_function_queue_.end(),
        [&](const FunctionBundle& queued) { return bundle.effective_priority > queued.effective_priority; });
    waiting_function_queue_.insert(insert_pos, std::move(bundle));
}

bool FunctionScheduler::_promoteNextFunctionInRunningBundleUnlocked() {
    if (!running_bundle_.has_value() || !running_bundle_->hasNext()) {
        return false;
    }
    running_bundle_->current_index += 1;
    auto next = running_bundle_->currentFunction();
    if (!next) {
        return false;
    }
    next->setStatus(core::FunctionStatus::RUNNING);
    next->onEnter(std::nullopt);
    return true;
}

bool FunctionScheduler::_promoteNextFunctionUnlocked() {
    std::optional<FunctionBundle> candidate;
    bool from_paused_function_stack = false;

    if (!paused_function_stack_.empty() && !waiting_function_queue_.empty()) {
        const auto& paused_top = paused_function_stack_.top();
        const auto& waiting_top = waiting_function_queue_.front();
        if (paused_top.effective_priority >= waiting_top.effective_priority) {
            candidate = paused_top;
            from_paused_function_stack = true;
        } else {
            candidate = waiting_top;
            waiting_function_queue_.erase(waiting_function_queue_.begin());
        }
    } else if (!paused_function_stack_.empty()) {
        candidate = paused_function_stack_.top();
        from_paused_function_stack = true;
    } else if (!waiting_function_queue_.empty()) {
        candidate = waiting_function_queue_.front();
        waiting_function_queue_.erase(waiting_function_queue_.begin());
    }

    if (!candidate.has_value()) {
        return false;
    }

    if (from_paused_function_stack) {
        paused_function_stack_.pop();
    }

    running_bundle_ = std::move(candidate);
    auto current = running_bundle_->currentFunction();
    if (!current) {
        running_bundle_.reset();
        return false;
    }
    current->setStatus(core::FunctionStatus::RUNNING);

    if (from_paused_function_stack) {
        auto it = pause_contexts_.find(current->functionId());
        if (it != pause_contexts_.end()) {
            current->onResume(it->second);
            pause_contexts_.erase(it);
        } else {
            current->onResume({});
        }
    } else {
        current->onEnter(std::nullopt);
    }
    return true;
}

std::vector<FunctionScheduler::FunctionBundle> FunctionScheduler::_pausedTopFirstUnlocked() const {
    return _pausedTopFirstCopyUnlocked();
}

std::vector<FunctionScheduler::FunctionBundle> FunctionScheduler::_pausedTopFirstCopyUnlocked() const {
    std::vector<FunctionBundle> bundles;
    auto paused_copy = paused_function_stack_;
    while (!paused_copy.empty()) {
        bundles.push_back(paused_copy.top());
        paused_copy.pop();
    }
    return bundles;
}

FunctionScheduler::FunctionBundle FunctionScheduler::_createBundleFromFunctionsUnlocked(
    const std::vector<std::shared_ptr<Function>>& functions) {
    FunctionBundle bundle;
    bundle.bundle_id = _buildBundleIdUnlocked();
    bundle.functions = functions;
    bundle.current_index = 0;
    int max_priority = 0;
    for (const auto& function : bundle.functions) {
        if (function) {
            max_priority = std::max(max_priority, function->schedulerPriority());
        }
    }
    bundle.effective_priority = max_priority;
    return bundle;
}

FunctionScheduler::FunctionBundle FunctionScheduler::_bundleFromLegacyFunctionUnlocked(
    const std::shared_ptr<Function>& function) {
    FunctionBundle bundle;
    bundle.bundle_id = _buildBundleIdUnlocked();
    bundle.functions = {function};
    bundle.current_index = 0;
    bundle.effective_priority = function ? function->schedulerPriority() : 0;
    return bundle;
}

std::string FunctionScheduler::_buildBundleIdUnlocked() {
    return "bundle-" + std::to_string(next_bundle_sequence_++);
}

std::shared_ptr<Function> FunctionScheduler::_createFunctionFromJsonUnlocked(const json& function_json) const {
    if (!function_json.is_object()) {
        return nullptr;
    }

    std::string function_name;
    if (function_json.contains("function_name") && function_json["function_name"].is_string()) {
        function_name = function_json["function_name"].get<std::string>();
    } else if (function_json.contains("function_type") && function_json["function_type"].is_string()) {
        function_name = function_json["function_type"].get<std::string>();
    } else {
        return nullptr;
    }

    auto it = function_factories_.find(function_name);
    if (it == function_factories_.end()) {
        return nullptr;
    }

    auto function = it->second(function_json);
    if (!function) {
        return nullptr;
    }

    function->fromJson(function_json);
    return function;
}

bool FunctionScheduler::_loadBundleArrayUnlocked(const json& payload, const char* key,
                                                 std::vector<FunctionBundle>* out_waiting_bundles,
                                                 std::stack<FunctionBundle>* out_paused_bundles) {
    if (!payload.contains(key)) {
        return true;
    }
    if (!payload[key].is_array()) {
        return false;
    }

    std::vector<FunctionBundle> loaded;
    for (const auto& bundle_json : payload[key]) {
        FunctionBundle bundle;
        if (!_bundleFromJsonUnlocked(bundle_json, core::FunctionStatus::PAUSED, &bundle)) {
            return false;
        }
        loaded.push_back(std::move(bundle));
    }

    if (out_waiting_bundles) {
        for (auto& bundle : loaded) {
            out_waiting_bundles->push_back(std::move(bundle));
        }
    }
    if (out_paused_bundles) {
        for (auto it = loaded.rbegin(); it != loaded.rend(); ++it) {
            out_paused_bundles->push(*it);
        }
    }
    return true;
}

}  // namespace framework
}  // namespace applications
}  // namespace robot_control
