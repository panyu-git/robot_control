#pragma once

#include <memory>
#include <string>

#include "robot_control/applications/framework/bt_nodes.hpp"
#include "robot_control/core/blackboard.hpp"
#include "robot_control/services/navigation_service.hpp"

namespace robot_control {
namespace applications {
namespace bt_nodes {

class ExecuteWakeupRotate : public framework::StatefulActionNode {
   public:
    ExecuteWakeupRotate(const std::string& name, const BT::NodeConfig& config,
                        std::shared_ptr<core::Blackboard> blackboard);

    core::NodeStatus onStartAction() override;
    core::NodeStatus onRunningAction() override;
    void onHaltedAction() override;
    static BT::PortsList providedPorts() {
        return {};
    }

   private:
    std::string _logger_name = "ExecuteWakeupRotate";
    std::chrono::steady_clock::time_point _start_time;
};

class WakeupFsmIs : public framework::ConditionNode {
   public:
    WakeupFsmIs(const std::string& name, const BT::NodeConfig& config, std::shared_ptr<core::Blackboard> blackboard);
    bool check() override;
    static BT::PortsList providedPorts() {
        return {BT::InputPort<std::string>("phase")};
    }
};

class TransitionToWakeup : public framework::ActionNode {
   public:
    TransitionToWakeup(const std::string& name, const BT::NodeConfig& config,
                       std::shared_ptr<core::Blackboard> blackboard);
    core::NodeStatus execute() override;
    static BT::PortsList providedPorts() {
        return {};
    }
};

class WakeupTransitionToIdle : public framework::ActionNode {
   public:
    WakeupTransitionToIdle(const std::string& name, const BT::NodeConfig& config,
                           std::shared_ptr<core::Blackboard> blackboard);
    core::NodeStatus execute() override;
    static BT::PortsList providedPorts() {
        return {};
    }
};

class WakeupTransitionToFault : public framework::ActionNode {
   public:
    WakeupTransitionToFault(const std::string& name, const BT::NodeConfig& config,
                            std::shared_ptr<core::Blackboard> blackboard);
    core::NodeStatus execute() override;
    static BT::PortsList providedPorts() {
        return {};
    }
};

class CleanupWakeupTask : public framework::ActionNode {
   public:
    CleanupWakeupTask(const std::string& name, const BT::NodeConfig& config,
                      std::shared_ptr<core::Blackboard> blackboard);
    core::NodeStatus execute() override;
    static BT::PortsList providedPorts() {
        return {};
    }
};

class CheckWakeupNavStatus : public framework::ConditionNode {
   public:
    CheckWakeupNavStatus(const std::string& name, const BT::NodeConfig& config,
                         std::shared_ptr<core::Blackboard> blackboard);
    bool check() override;
    static BT::PortsList providedPorts() {
        return {};
    }
};

}  // namespace bt_nodes
}  // namespace applications
}  // namespace robot_control
