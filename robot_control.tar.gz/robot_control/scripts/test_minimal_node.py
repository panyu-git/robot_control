#!/usr/bin/env python3
"""
Minimal ROS2 Node Test
最小化 ROS2 节点测试 - 用于排查问题
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from std_srvs.srv import Trigger


class MinimalNode(Node):
    def __init__(self):
        super().__init__('minimal_test_node')
        
        self.get_logger().info('Creating service...')
        self._test_srv = self.create_service(
            Trigger, '/test/trigger', self._handle_trigger)
        
        self.get_logger().info('Creating publisher...')
        self._test_pub = self.create_publisher(String, '/test/status', 10)
        
        self.get_logger().info('Creating timer...')
        self._timer = self.create_timer(1.0, self._timer_callback)
        
        self.get_logger().info('MinimalNode started - all good!')
        self.get_logger().info('Test with: ros2 service call /test/trigger std_srvs/srv/Trigger')
    
    def _handle_trigger(self, request, response):
        self.get_logger().info('Trigger service called!')
        response.success = True
        response.message = 'Hello from minimal node!'
        return response
    
    def _timer_callback(self):
        msg = String()
        msg.data = 'heartbeat'
        self._test_pub.publish(msg)


def main():
    rclpy.init()
    node = MinimalNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
