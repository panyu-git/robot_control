#pragma once

#include <chrono>
#include <memory>
#include <optional>

#include "robot_control/applications/framework/function_base.hpp"
#include "robot_control/applications/interfaces/robot_context.hpp"

namespace robot_control {
namespace applications {
namespace functions {

class FollowFunction : public framework::Function {
   public:
    FollowFunction(std::shared_ptr<core::Blackboard> blackboard, const interfaces::RobotContext& context);

    core::FunctionType functionType() const override;
    core::FunctionPriority priority() const override;
    core::PreemptionType preemptionType() const override;

    void onEnter(const std::optional<std::map<std::string, std::any>>& context = std::nullopt) override;
    std::optional<std::map<std::string, std::any>> onExit() override;
    std::optional<std::map<std::string, std::any>> onPause() override;
    void onResume(const std::map<std::string, std::any>& context) override;

    core::FunctionStatus preTick() override;
    core::FunctionStatus postTick() override;

    // Follow Policy Helpers (Moved from FollowPolicy)
    static core::FollowFailReason mapStatusToReason(core::NodeStatus bt_status, core::NavigationStatus nav_status,
                                                    bool nav_online, bool perception_online, bool nav_ready);
    static std::string getHmiMessage(core::FollowFailReason reason);
    static core::FollowFailReason stringToReason(const std::string& reason_str);
    static std::string reasonToString(core::FollowFailReason reason);

   private:
    core::FunctionStatus _checkUserCommands();
    void _handleInternalCommands();
    void _maybePublishActivationResult(core::NodeStatus bt_status);

    void _handleSpeedChange(int direction);
    void _handleDistanceChange(int direction);
    void _handleLocationChange(const std::string& location);
    void _publishHeartbeatIfNeeded();
    std::string _formatPosition(double x, double y, double z);
    int _getActivationSessionId() const;

    const interfaces::RobotContext& _context;
    bool _activationResultPublished;
    std::optional<std::chrono::steady_clock::time_point> _lastRetryTime;
    std::chrono::steady_clock::time_point _lastHeartbeat;
};

}  // namespace functions
}  // namespace applications
}  // namespace robot_control
