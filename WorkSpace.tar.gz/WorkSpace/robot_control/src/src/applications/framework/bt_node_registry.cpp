#include "robot_control/applications/framework/bt_node_registry.hpp"

#include "robot_control/applications/bt_nodes/follow_nodes.hpp"
#include "robot_control/applications/bt_nodes/wakeup_nodes.hpp"
#include "robot_control/applications/framework/bt_nodes.hpp"

namespace robot_control {
namespace applications {
namespace framework {

void BTNodeRegistry::registerAllNodes(BT::BehaviorTreeFactory& factory, std::shared_ptr<core::Blackboard> blackboard) {
    auto bb = blackboard;

    // --- Follow Nodes ---
    factory.registerNodeType<bt_nodes::InitializeFollowParams>("InitializeFollowParams", bb);
    factory.registerNodeType<bt_nodes::StartFollowTask>("StartFollowTask", bb);
    factory.registerNodeType<bt_nodes::CheckNavigationStatus>("CheckNavigationStatus", bb);
    factory.registerNodeType<bt_nodes::CheckStopConditions>("CheckStopConditions", bb);
    factory.registerNodeType<bt_nodes::UpdateProgress>("UpdateProgress", bb);
    factory.registerNodeType<bt_nodes::CleanupFollowTask>("CleanupFollowTask", bb);
    factory.registerNodeType<bt_nodes::FollowFsmIs>("FollowFsmIs", bb);

    factory.registerNodeType<bt_nodes::TransitionToFollow>("TransitionToFollow", bb);
    factory.registerNodeType<bt_nodes::TransitionToLost>("TransitionToLost", bb);
    factory.registerNodeType<bt_nodes::TransitionToTrapped>("TransitionToTrapped", bb);
    factory.registerNodeType<bt_nodes::TransitionToIdle>("TransitionToIdle", bb);
    factory.registerNodeType<bt_nodes::TransitionToFault>("TransitionToFault", bb);

    factory.registerNodeType<bt_nodes::IdleStateExit>("IdleStateExit", bb);
    factory.registerNodeType<bt_nodes::PublishFollowEvent>("PublishFollowEvent", bb);
    factory.registerNodeType<bt_nodes::CheckTargetTimeout>("CheckTargetTimeout", bb);
    factory.registerNodeType<bt_nodes::CheckIsTrapped>("CheckIsTrapped", bb);
    factory.registerNodeType<bt_nodes::DetectFaceAndUserAction>("DetectFaceAndUser", bb);

    factory.registerNodeType<framework::SetRobotBlackboard>("SetRobotBlackboard", bb);
    factory.registerNodeType<RunningNode>("AlwaysRunning");

    // --- Wakeup Nodes ---
    factory.registerNodeType<bt_nodes::ExecuteWakeupRotate>("ExecuteWakeupRotate", bb);
    factory.registerNodeType<bt_nodes::WakeupFsmIs>("WakeupFsmIs", bb);
    factory.registerNodeType<bt_nodes::TransitionToWakeup>("TransitionToWakeup", bb);
    factory.registerNodeType<bt_nodes::WakeupTransitionToIdle>("WakeupTransitionToIdle", bb);
    factory.registerNodeType<bt_nodes::WakeupTransitionToFault>("WakeupTransitionToFault", bb);
    factory.registerNodeType<bt_nodes::CleanupWakeupTask>("CleanupWakeupTask", bb);
    factory.registerNodeType<bt_nodes::CheckWakeupNavStatus>("CheckWakeupNavStatus", bb);
}

}  // namespace framework
}  // namespace applications
}  // namespace robot_control
