#include "robot_control/applications/interfaces/robot_controller_node.hpp"

#include <algorithm>
#include <cctype>
#include <chrono>
#include <cmath>
#include <ctime>
#include <iomanip>
#include <map>
#include <sstream>

#include "robot_control/common/logging.hpp"
#include "robot_control/core/enums.hpp"
#include "robot_control/core/robot_control_configs.hpp"

namespace robot_control {
namespace applications {
namespace interfaces {

namespace {

constexpr const char* kWakeUpRelay = "wake_up_relay";
constexpr const char* kFeedbackFollowStartFailInvalidUser = "prompt_start_follow_failed_with_invalid_user";
constexpr const char* kFeedbackFollowStartFaceToTp = "prompt_face_to_tp";
constexpr const char* kFeedbackFollowStartFailWithoutUser = "prompt_start_follow_failed_without_user";
constexpr const char* kFeedbackFollowStartFailNeedCheck = "prompt_start_follow_failed_need_check";
constexpr const char* kFeedbackFollowStartSucceedWithUwb = "prompt_start_follow_succeed_with_uwb";
constexpr const char* kFeedbackFollowStartSucceed = "prompt_start_follow_succeed";
constexpr const char* kFeedbackFollowStartFaceToTpThumbUp = "prompt_face_to_tp_thumb_up";
constexpr const char* kFeedbackThumbUp = "prompt_thumb_up";
constexpr const char* kFeedbackFollowStartFailUnknown = "prompt_start_follow_failed_with_unknown_reason";
constexpr const char* kFeedbackFollowStartFailWithUserOnly = "prompt_start_follow_failed_with_user_only";
constexpr const char* kFeedbackFollowAgain = "prompt_follow_again";
constexpr const char* kFeedbackFollowLost = "prompt_follow_lost";
constexpr const char* kFeedbackFollowLostExit = "prompt_follow_lost_exit";
constexpr const char* kFeedbackFollowExecExit = "prompt_follow_exec_exit";
constexpr const char* kFeedbackFollowStopFailed = "prompt_follow_stop_failed";
constexpr const char* kFeedbackFollowStopFailedInvalidUser = "prompt_follow_stop_failed_with_invalid_user";

/**
 * Structure to encapsulate HMI feedback reporting configuration.
 */
struct FeedbackInfo {
    const char* feedback_type;
    const char* task_name;
    const char* task_state;
};

/**
 * Registry of events that should be reported to the HMI/State topic.
 * Maps core::EventType to its associated feedback configuration.
 */
static const std::map<core::EventType, FeedbackInfo> kEventFeedbackRegistry = {
    {core::EventType::FEEDBACK_WAKE_UP_RELAY, {kWakeUpRelay, "WAKEUP_TASK", ""}},
    {core::EventType::FEEDBACK_FOLLOW_START_FAIL_INVALID_USER,
     {kFeedbackFollowStartFailInvalidUser, "FOLLOW_TASK", "FAILED"}},
    {core::EventType::FEEDBACK_FOLLOW_START_FACE_TO_TP, {kFeedbackFollowStartFaceToTp, "FOLLOW_TASK", ""}},
    {core::EventType::FEEDBACK_FOLLOW_START_FAIL_WITHOUT_USER,
     {kFeedbackFollowStartFailWithoutUser, "FOLLOW_TASK", "FAILED"}},
    {core::EventType::FEEDBACK_FOLLOW_START_FAIL_NEED_CHECK,
     {kFeedbackFollowStartFailNeedCheck, "FOLLOW_TASK", "FAILED"}},
    {core::EventType::FEEDBACK_FOLLOW_START_SUCCEED_WITH_UWB,
     {kFeedbackFollowStartSucceedWithUwb, "FOLLOW_TASK", "RUNNING"}},
    {core::EventType::FEEDBACK_FOLLOW_START_SUCCEED, {kFeedbackFollowStartSucceed, "FOLLOW_TASK", "RUNNING"}},
    {core::EventType::FEEDBACK_FOLLOW_START_FACE_TO_TP_THUMB_UP,
     {kFeedbackFollowStartFaceToTpThumbUp, "FOLLOW_TASK", ""}},
    {core::EventType::FEEDBACK_THUMB_UP, {kFeedbackThumbUp, "FOLLOW_TASK", ""}},
    {core::EventType::FEEDBACK_FOLLOW_START_FAIL_UNKNOWN, {kFeedbackFollowStartFailUnknown, "FOLLOW_TASK", "FAILED"}},
    {core::EventType::FEEDBACK_FOLLOW_START_FAIL_WITH_USER_ONLY,
     {kFeedbackFollowStartFailWithUserOnly, "FOLLOW_TASK", "FAILED"}},
    {core::EventType::FEEDBACK_FOLLOW_AGAIN, {kFeedbackFollowAgain, "FOLLOW_TASK", ""}},
    {core::EventType::FEEDBACK_FOLLOW_LOST, {kFeedbackFollowLost, "FOLLOW_TASK", "LOST"}},
    {core::EventType::FEEDBACK_FOLLOW_LOST_EXIT, {kFeedbackFollowLostExit, "FOLLOW_TASK", "EXITED"}},
    {core::EventType::FEEDBACK_FOLLOW_EXEC_EXIT, {kFeedbackFollowExecExit, "FOLLOW_TASK", "COMPLETED"}},
    {core::EventType::FEEDBACK_FOLLOW_STOP_FAILED, {kFeedbackFollowStopFailed, "FOLLOW_TASK", ""}},
    {core::EventType::FEEDBACK_FOLLOW_STOP_FAILED_INVALID_USER,
     {kFeedbackFollowStopFailedInvalidUser, "FOLLOW_TASK", ""}}};

std::string eventTypeToString(core::EventType type) {
    switch (type) {
        case core::EventType::FOLLOW_ACTIVATION_REQUESTED:
            return "FOLLOW_ACTIVATION_REQUESTED";
        case core::EventType::FACE_RECOG_RESULT:
            return "FACE_RECOG_RESULT";
        case core::EventType::FOLLOW_ACTIVATE_RESULT:
            return "FOLLOW_ACTIVATE_RESULT";
        case core::EventType::FOLLOW_HEARTBEAT:
            return "FOLLOW_HEARTBEAT";
        case core::EventType::FUNCTION_STARTED:
            return "FUNCTION_STARTED";
        case core::EventType::FUNCTION_COMPLETED:
            return "FUNCTION_COMPLETED";
        case core::EventType::FUNCTION_FAILED:
            return "FUNCTION_FAILED";
        case core::EventType::HMI_INTERACTION_REQUEST:
            return "HMI_INTERACTION_REQUEST";
        case core::EventType::TARGET_LOST:
            return "TARGET_LOST";
        case core::EventType::USER_COMMAND_WAKEUP:
            return "USER_COMMAND_WAKEUP";
        case core::EventType::USER_COMMAND_STOP_FOLLOW:
            return "USER_COMMAND_STOP_FOLLOW";
        case core::EventType::USER_COMMAND_FOLLOW_SPEED_UP:
            return "USER_COMMAND_FOLLOW_SPEED_UP";
        case core::EventType::USER_COMMAND_FOLLOW_SPEED_DOWN:
            return "USER_COMMAND_FOLLOW_SPEED_DOWN";
        case core::EventType::USER_COMMAND_FOLLOW_DISTANCE_NEAR:
            return "USER_COMMAND_FOLLOW_DISTANCE_NEAR";
        case core::EventType::USER_COMMAND_FOLLOW_DISTANCE_FAR:
            return "USER_COMMAND_FOLLOW_DISTANCE_FAR";
        case core::EventType::USER_COMMAND_FOLLOW_LOCATION:
            return "USER_COMMAND_FOLLOW_LOCATION";
        case core::EventType::FEEDBACK_FOLLOW_LOST_EXIT:
            return "FEEDBACK_FOLLOW_LOST_EXIT";
        case core::EventType::FEEDBACK_FOLLOW_LOST:
            return "FEEDBACK_FOLLOW_LOST";
        case core::EventType::FEEDBACK_FOLLOW_START_FAIL_INVALID_USER:
            return "FEEDBACK_FOLLOW_START_FAIL_INVALID_USER";
        case core::EventType::FEEDBACK_FOLLOW_START_FACE_TO_TP:
            return "FEEDBACK_FOLLOW_START_FACE_TO_TP";
        case core::EventType::FEEDBACK_FOLLOW_START_FAIL_WITHOUT_USER:
            return "FEEDBACK_FOLLOW_START_FAIL_WITHOUT_USER";
        case core::EventType::FEEDBACK_FOLLOW_START_FAIL_NEED_CHECK:
            return "FEEDBACK_FOLLOW_START_FAIL_NEED_CHECK";
        case core::EventType::FEEDBACK_FOLLOW_START_SUCCEED_WITH_UWB:
            return "FEEDBACK_FOLLOW_START_SUCCEED_WITH_UWB";
        case core::EventType::FEEDBACK_FOLLOW_START_SUCCEED:
            return "FEEDBACK_FOLLOW_START_SUCCEED";
        case core::EventType::FEEDBACK_FOLLOW_START_FACE_TO_TP_THUMB_UP:
            return "FEEDBACK_FOLLOW_START_FACE_TO_TP_THUMB_UP";
        case core::EventType::FEEDBACK_THUMB_UP:
            return "FEEDBACK_THUMB_UP";
        case core::EventType::FEEDBACK_FOLLOW_START_FAIL_UNKNOWN:
            return "FEEDBACK_FOLLOW_START_FAIL_UNKNOWN";
        case core::EventType::FEEDBACK_FOLLOW_START_FAIL_WITH_USER_ONLY:
            return "FEEDBACK_FOLLOW_START_FAIL_WITH_USER_ONLY";
        case core::EventType::FEEDBACK_FOLLOW_AGAIN:
            return "FEEDBACK_FOLLOW_AGAIN";
        case core::EventType::FEEDBACK_FOLLOW_EXEC_EXIT:
            return "FEEDBACK_FOLLOW_EXEC_EXIT";
        case core::EventType::FEEDBACK_FOLLOW_STOP_FAILED:
            return "FEEDBACK_FOLLOW_STOP_FAILED";
        case core::EventType::FEEDBACK_FOLLOW_STOP_FAILED_INVALID_USER:
            return "FEEDBACK_FOLLOW_STOP_FAILED_INVALID_USER";
        case core::EventType::FEEDBACK_WAKE_UP_RELAY:
            return "FEEDBACK_WAKE_UP_RELAY";
        default:
            return "UNKNOWN";
    }
}

bool shouldTraceCoreEvent(core::EventType type) {
    switch (type) {
        case core::EventType::FOLLOW_ACTIVATION_REQUESTED:
        case core::EventType::FACE_RECOG_RESULT:
        case core::EventType::FOLLOW_ACTIVATE_RESULT:
        case core::EventType::FUNCTION_STARTED:
        case core::EventType::FUNCTION_COMPLETED:
        case core::EventType::FUNCTION_FAILED:
        case core::EventType::HMI_INTERACTION_REQUEST:
        case core::EventType::TARGET_LOST:
        case core::EventType::USER_COMMAND_WAKEUP:
        case core::EventType::USER_COMMAND_STOP_FOLLOW:
        case core::EventType::USER_COMMAND_FOLLOW_SPEED_UP:
        case core::EventType::USER_COMMAND_FOLLOW_SPEED_DOWN:
        case core::EventType::USER_COMMAND_FOLLOW_DISTANCE_NEAR:
        case core::EventType::USER_COMMAND_FOLLOW_DISTANCE_FAR:
        case core::EventType::USER_COMMAND_FOLLOW_LOCATION:
        case core::EventType::FEEDBACK_FOLLOW_LOST_EXIT:
        case core::EventType::FEEDBACK_FOLLOW_LOST:
        case core::EventType::FEEDBACK_FOLLOW_START_FAIL_INVALID_USER:
        case core::EventType::FEEDBACK_FOLLOW_START_FACE_TO_TP:
        case core::EventType::FEEDBACK_FOLLOW_START_FAIL_WITHOUT_USER:
        case core::EventType::FEEDBACK_FOLLOW_START_FAIL_NEED_CHECK:
        case core::EventType::FEEDBACK_FOLLOW_START_SUCCEED_WITH_UWB:
        case core::EventType::FEEDBACK_FOLLOW_START_SUCCEED:
        case core::EventType::FEEDBACK_FOLLOW_START_FACE_TO_TP_THUMB_UP:
        case core::EventType::FEEDBACK_THUMB_UP:
        case core::EventType::FEEDBACK_FOLLOW_START_FAIL_UNKNOWN:
        case core::EventType::FEEDBACK_FOLLOW_START_FAIL_WITH_USER_ONLY:
        case core::EventType::FEEDBACK_FOLLOW_AGAIN:
        case core::EventType::FEEDBACK_FOLLOW_EXEC_EXIT:
        case core::EventType::FEEDBACK_FOLLOW_STOP_FAILED:
        case core::EventType::FEEDBACK_FOLLOW_STOP_FAILED_INVALID_USER:
        case core::EventType::FEEDBACK_WAKE_UP_RELAY:
            return true;
        default:
            return false;
    }
}

std::string trimCopy(const std::string& text) {
    auto begin = std::find_if_not(text.begin(), text.end(), [](unsigned char c) { return std::isspace(c) != 0; });
    auto end =
        std::find_if_not(text.rbegin(), text.rend(), [](unsigned char c) { return std::isspace(c) != 0; }).base();
    if (begin >= end) {
        return "";
    }
    return std::string(begin, end);
}

std::string getEventData(const core::Event& event, const std::string& key) {
    auto it = event.data.find(key);
    return (it == event.data.end()) ? std::string("") : it->second;
}

}  // namespace

RobotControllerNode::RobotControllerNode()
    : Node("robot_controller"),
      _ready(false),
      _currentSeq(0),
      _lastCommandId(""),
      _lastCommandStamp(0, 0, RCL_ROS_TIME),
      _logger_name("RobotControllerNode") {
    // Declare parameters
    this->declare_parameter<bool>("simulated", false);
    this->declare_parameter<bool>("skip_follow_activation_in_simulated", true);
    this->declare_parameter<double>("tick_rate", RobotController::DEFAULT_TICK_RATE);

    // Get parameters
    bool simulated = this->get_parameter("simulated").as_bool();
    bool skip_follow_activation_in_simulated = this->get_parameter("skip_follow_activation_in_simulated").as_bool();
    double tick_rate = this->get_parameter("tick_rate").as_double();

    LOG_INFO("Initializing RobotController (simulated="
             << (simulated ? "true" : "false")
             << ", skip_follow_activation_in_simulated=" << (skip_follow_activation_in_simulated ? "true" : "false")
             << ", tick_rate=" << std::fixed << std::setprecision(1) << tick_rate << ")");

    // Create robot controller
    _controller = std::make_unique<RobotController>(simulated, tick_rate);
    _controller->blackboard->set("skip_follow_activation_in_simulated", skip_follow_activation_in_simulated);

    // Create callback group for timer
    _timerCallbackGroup = this->create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);

    // =====================================================================
    // HMI Topic API
    // =====================================================================
    _hmiCommandSub = this->create_subscription<HmiCommandMsg>(
        "/hmi_control/robot_control", 10,
        std::bind(&RobotControllerNode::_handleHmiCommand, this, std::placeholders::_1));

    // =====================================================================
    // Publishers
    // =====================================================================
    _robotStatePub = this->create_publisher<RobotStateMsg>("robot_control/state", 10);
    _eventsPub = this->create_publisher<std_msgs::msg::String>("/robot/events", 10);

    _ready = true;
    LOG_INFO("RobotControllerNode started");
    LOG_INFO("Publishers: robot_control/state, /robot/events");
    LOG_INFO("Subscriptions: /hmi_control/robot_control, odom, /nav_task_status");
}

void RobotControllerNode::init() {
    _controller->init(shared_from_this());
    // Start the controller
    _bridgeCoreEventsToRos();  // Moved to init() to prevent accessing uninitialized event_bus
    _controller->start();
}

void RobotControllerNode::_handleHmiCommand(const HmiCommandMsg::SharedPtr msg) {
    if (msg->cmd_type == HmiCommandMsg::CHAT) {
        LOG_WARN("[/hmi_control/robot_control] CHAT cmd is disabled for robot_control");
        return;
    }

    // 去重逻辑：优先使用 seq，否则使用 header.stamp
    bool is_duplicate = false;
    std::string current_cmd_id = std::to_string(msg->seq);
    if (msg->seq != 0) {
        if (current_cmd_id == _lastCommandId) {
            is_duplicate = true;
        }
    } else {
        // 如果没有 seq，则检查时间戳
        if (msg->header.stamp.sec != 0 || msg->header.stamp.nanosec != 0) {
            if (rclcpp::Time(msg->header.stamp) == _lastCommandStamp) {
                is_duplicate = true;
            }
        }
    }

    if (is_duplicate) {
        LOG_WARN("[/hmi_control/robot_control] Received duplicate cmd. Ignoring. (id=" << current_cmd_id << ")");
        return;
    }

    // 更新去重状态
    if (msg->seq != 0) {
        _lastCommandId = current_cmd_id;
    }
    _currentSeq = msg->seq;
    if (msg->header.stamp.sec != 0 || msg->header.stamp.nanosec != 0) {
        _lastCommandStamp = msg->header.stamp;
    }

    LOG_INFO("[/hmi_control/robot_control] Received cmd: " << static_cast<int>(msg->cmd_type)
                                                           << " id: " << current_cmd_id);

    std::string detail_message = "";
    bool ok = _dispatchRobotCommand(msg->cmd_type, msg->execute_param, detail_message);

    if (ok) {
        LOG_INFO("[/hmi_control/robot_control] Execute Success! cmd_type: " << static_cast<int>(msg->cmd_type)
                                                                            << ", msg: " << detail_message);
    } else {
        LOG_ERROR("[/hmi_control/robot_control] Execute Failed! cmd_type: " << static_cast<int>(msg->cmd_type)
                                                                            << ", msg: " << detail_message);
    }
}

std::map<std::string, std::string> RobotControllerNode::_parseExecuteParam(const std::string& execute_param) const {
    std::map<std::string, std::string> parsed;
    std::string text = trimCopy(execute_param);
    if (text.empty()) {
        return parsed;
    }

    // Accept JSON-like one-level payload: {"k":"v","n":1}
    if (text.front() == '{' && text.back() == '}') {
        text = text.substr(1, text.size() - 2);
        std::istringstream stream(text);
        std::string pair;
        while (std::getline(stream, pair, ',')) {
            auto pos = pair.find(':');
            if (pos == std::string::npos) {
                continue;
            }
            std::string key = trimCopy(pair.substr(0, pos));
            std::string value = trimCopy(pair.substr(pos + 1));
            if (key.size() >= 2 && key.front() == '"' && key.back() == '"') {
                key = key.substr(1, key.size() - 2);
            }
            if (value.size() >= 2 && value.front() == '"' && value.back() == '"') {
                value = value.substr(1, value.size() - 2);
            }
            if (!key.empty()) {
                parsed[key] = value;
            }
        }
        return parsed;
    }

    // Accept key=value pairs: a=1,b=2 or a=1;b=2
    std::string normalized = text;
    std::replace(normalized.begin(), normalized.end(), ';', ',');
    std::istringstream stream(normalized);
    std::string pair;
    while (std::getline(stream, pair, ',')) {
        auto pos = pair.find('=');
        if (pos == std::string::npos) {
            continue;
        }
        auto key = trimCopy(pair.substr(0, pos));
        auto value = trimCopy(pair.substr(pos + 1));
        if (!key.empty()) {
            parsed[key] = value;
        }
    }
    if (parsed.empty()) {
        parsed["value"] = text;
    }
    return parsed;
}

bool RobotControllerNode::_dispatchRobotCommand(uint8_t cmd_type, const std::string& execute_param,
                                                std::string& detail_message) {
    const auto params = _parseExecuteParam(execute_param);
    std::map<std::string, std::string> cmd_params = params;
    auto params_to_string = [](const std::map<std::string, std::string>& kvs) {
        std::ostringstream oss;
        oss << "{";
        bool first = true;
        for (const auto& [k, v] : kvs) {
            if (!first) {
                oss << ", ";
            }
            first = false;
            oss << k << "=" << v;
        }
        oss << "}";
        return oss.str();
    };

    LOG_INFO("[dispatch] cmd_type=" << static_cast<unsigned int>(cmd_type) << " raw_execute_param='" << execute_param
                                    << "' parsed_params=" << params_to_string(cmd_params));

    // Normalize common protocol fields from execute_param.json:
    // user_id, user_intent, query are pass-through.
    // For wakeup rotate task:
    // - target_yaw (rad) is preferred.
    // - max_angular_velocity (rad/s) defaults to 0.5 when not provided.
    // - timeout (s) is optional.

    if (cmd_type == HmiCommandMsg::KWS) {
        const auto target_yaw_it = cmd_params.find("target_yaw");
        const auto wakeup_angle_it = cmd_params.find("wakeup_angle");
        LOG_INFO("[dispatch][KWS] before normalize target_yaw='"
                 << (target_yaw_it != cmd_params.end() ? target_yaw_it->second : "") << "', wakeup_angle='"
                 << (wakeup_angle_it != cmd_params.end() ? wakeup_angle_it->second : "") << "'");

        // Prefer target_yaw; fall back to wakeup_angle/value for backward compatibility.
        if (cmd_params.count("target_yaw") == 0 || cmd_params["target_yaw"].empty()) {
            if (cmd_params.count("wakeup_angle") > 0 && !cmd_params["wakeup_angle"].empty()) {
                cmd_params["target_yaw"] = cmd_params["wakeup_angle"];
            } else if (cmd_params.count("value") > 0 && !cmd_params["value"].empty()) {
                cmd_params["target_yaw"] = cmd_params["value"];
            }
        }

        // Default max_angular_velocity to 0.5 if missing/empty.
        if (cmd_params.count("max_angular_velocity") == 0 || cmd_params["max_angular_velocity"].empty()) {
            cmd_params["max_angular_velocity"] = "0.5";
        }

        if (cmd_params.count("target_yaw") == 0 || cmd_params["target_yaw"].empty()) {
            LOG_WARN("[dispatch][KWS] missing target_yaw after normalize, params=" << params_to_string(cmd_params));
        } else {
            LOG_INFO("[dispatch][KWS] normalized target_yaw='"
                     << cmd_params["target_yaw"] << "', max_angular_velocity='" << cmd_params["max_angular_velocity"]
                     << "', timeout='" << (cmd_params.count("timeout") ? cmd_params["timeout"] : std::string(""))
                     << "', params=" << params_to_string(cmd_params));
        }

        bool ok = _controller->command("wakeup", cmd_params);
        LOG_INFO("[dispatch][KWS] command wakeup result=" << (ok ? "success" : "failed")
                                                          << ", params=" << params_to_string(cmd_params));
        detail_message = ok ? "KWS dispatched" : "KWS failed";
        return ok;
    }
    if (cmd_type == HmiCommandMsg::FOLLOW_START) {
        auto location_it = cmd_params.find("location");
        if (location_it != cmd_params.end() && !location_it->second.empty()) {
            cmd_params["location"] = location_it->second;
        }
        bool ok = _controller->command("follow", cmd_params);
        detail_message = ok ? "FOLLOW_START dispatched" : "FOLLOW_START failed";
        return ok;
    }
    if (cmd_type == HmiCommandMsg::FOLLOW_END) {
        bool ok = _controller->command("stop_follow", cmd_params);
        detail_message = ok ? "FOLLOW_END dispatched" : "FOLLOW_END failed";
        return ok;
    }
    if (cmd_type == HmiCommandMsg::FOLLOW_DIS) {
        std::string distance_level = "";
        auto dis_it = cmd_params.find("distance");
        if (dis_it != cmd_params.end()) {
            distance_level = dis_it->second;
        } else if (cmd_params.count("value") > 0) {
            distance_level = cmd_params["value"];
        }
        std::transform(distance_level.begin(), distance_level.end(), distance_level.begin(),
                       [](unsigned char c) { return static_cast<char>(std::tolower(c)); });

        bool ok = false;
        if (distance_level == "near") {
            ok = _controller->command("follow_distance_near", cmd_params);
        } else if (distance_level == "far") {
            ok = _controller->command("follow_distance_far", cmd_params);
        } else {
            detail_message = "FOLLOW_DIS failed: distance must be near/far";
            return false;
        }
        detail_message = ok ? "FOLLOW_DIS dispatched" : "FOLLOW_DIS failed";
        return ok;
    }
    if (cmd_type == HmiCommandMsg::FOLLOW_LOC) {
        auto location_it = cmd_params.find("location");
        if (location_it != cmd_params.end() && !location_it->second.empty()) {
            cmd_params["location"] = location_it->second;
        } else if (cmd_params.count("value") > 0) {
            cmd_params["location"] = cmd_params["value"];
        }
        bool ok = _controller->command("follow_location", cmd_params);
        detail_message = ok ? "FOLLOW_LOC dispatched" : "FOLLOW_LOC failed";
        return ok;
    }
    if (cmd_type == HmiCommandMsg::CHAT) {
        detail_message = "CHAT is disabled for robot_control";
        return false;
    }

    detail_message = "unsupported cmd_type";
    return false;
}

void RobotControllerNode::shutdown() {
    LOG_INFO("Shutting down RobotControllerNode...");
    _ready = false;
    if (_controller) {
        _controller->shutdown();
    }
}

void RobotControllerNode::_publishEvent(const std::string& event_type, const std::string& message) {
    auto event_msg = std_msgs::msg::String();

    // Build JSON string manually
    std::ostringstream oss;
    auto now = std::chrono::system_clock::now();
    double timestamp = std::chrono::duration<double>(now.time_since_epoch()).count();

    oss << "{\"timestamp\":" << std::fixed << std::setprecision(3) << timestamp << ",\"event_type\":\"" << event_type
        << "\",\"message\":\"" << message << "\"}";

    event_msg.data = oss.str();
    _eventsPub->publish(event_msg);
    LOG_DEBUG("[/robot/events] " << event_type << ": " << message);
}

void RobotControllerNode::_publishEventFromCore(const core::Event& event) {
    std::ostringstream oss;
    oss << "{\"timestamp\":" << std::fixed << std::setprecision(3) << event.timestamp << ",\"event_type\":\""
        << eventTypeToString(event.event_type) << "\",\"source\":\"" << event.source << "\"";
    if (!event.data.empty()) {
        oss << ",\"data\":{";
        bool first = true;
        for (const auto& [k, v] : event.data) {
            if (!first) {
                oss << ",";
            }
            first = false;
            oss << "\"" << k << "\":\"" << v << "\"";
        }
        oss << "}";
    }
    oss << "}";

    std_msgs::msg::String msg;
    msg.data = oss.str();
    _eventsPub->publish(msg);

    if (shouldTraceCoreEvent(event.event_type)) {
        LOG_INFO("[/robot/events] CORE_" << eventTypeToString(event.event_type) << ": " << msg.data);
    } else {
        LOG_DEBUG("[/robot/events] CORE_" << eventTypeToString(event.event_type) << ": " << msg.data);
    }

    if (auto state_msg = _createFeedbackState(event)) {
        static auto last_state_log_time = std::chrono::steady_clock::now();
        auto now = std::chrono::steady_clock::now();
        if (std::chrono::duration<double>(now - last_state_log_time).count() >= 1.0 ||
            event.event_type != core::EventType::FOLLOW_HEARTBEAT) {
            LOG_INFO("[/robot_control/state] Publish state: task_name="
                     << state_msg->task_name << ", task_state=" << state_msg->task_state
                     << ", feedback_type=" << state_msg->feedback_type << ", message=" << state_msg->message);
            last_state_log_time = now;
        } else {
            LOG_DEBUG("[/robot_control/state] Publish state (throttled): task_name="
                      << state_msg->task_name << ", task_state=" << state_msg->task_state
                      << ", feedback_type=" << state_msg->feedback_type << ", message=" << state_msg->message);
        }
        _robotStatePub->publish(*state_msg);
    }
}

std::optional<RobotControllerNode::RobotStateMsg> RobotControllerNode::_createFeedbackState(const core::Event& event) {
    auto it = kEventFeedbackRegistry.find(event.event_type);
    if (it == kEventFeedbackRegistry.end()) {
        return std::nullopt;
    }

    RobotStateMsg state_msg;
    state_msg.header.stamp = this->get_clock()->now();
    state_msg.seq = _currentSeq;

    const auto& info = it->second;
    state_msg.feedback_type = info.feedback_type;
    state_msg.task_name = info.task_name;
    state_msg.task_state = info.task_state;
    state_msg.message = getEventData(event, "message");

    // Prefer explicit follow sub-state from blackboard when registry state is not specified.
    if (std::string(state_msg.task_state).empty() && std::string(state_msg.task_name) == "FOLLOW_TASK" && _controller) {
        auto follow_phase = _controller->blackboard->get<core::FollowPhase>("follow_phase", core::FollowPhase::IDLE);
        state_msg.task_state = core::toString(follow_phase);
    }

    return state_msg;
}

void RobotControllerNode::_bridgeCoreEventsToRos() {
    auto* bus = _controller->event_bus;
    auto subscribe_bridge = [this, bus](core::EventType type) {
        bus->subscribe(type, [this](const core::Event& event) { _publishEventFromCore(event); });
    };

    // Original events for general bridging
    subscribe_bridge(core::EventType::HMI_INTERACTION_REQUEST);
    subscribe_bridge(core::EventType::USER_COMMAND_WAKEUP);
    subscribe_bridge(core::EventType::USER_COMMAND_STOP_FOLLOW);
    subscribe_bridge(core::EventType::USER_COMMAND_FOLLOW_SPEED_UP);
    subscribe_bridge(core::EventType::USER_COMMAND_FOLLOW_SPEED_DOWN);
    subscribe_bridge(core::EventType::USER_COMMAND_FOLLOW_DISTANCE_NEAR);
    subscribe_bridge(core::EventType::USER_COMMAND_FOLLOW_DISTANCE_FAR);
    subscribe_bridge(core::EventType::USER_COMMAND_FOLLOW_LOCATION);
    subscribe_bridge(core::EventType::FOLLOW_HEARTBEAT);
    subscribe_bridge(core::EventType::FOLLOW_ACTIVATION_REQUESTED);
    subscribe_bridge(core::EventType::FOLLOW_ACTIVATE_RESULT);
    subscribe_bridge(core::EventType::FUNCTION_STARTED);
    subscribe_bridge(core::EventType::FUNCTION_COMPLETED);
    subscribe_bridge(core::EventType::FUNCTION_FAILED);
    subscribe_bridge(core::EventType::FACE_RECOG_RESULT);
    subscribe_bridge(core::EventType::TARGET_LOST);

    // Feedback specific events
    for (const auto& [type, info] : kEventFeedbackRegistry) {
        subscribe_bridge(type);
    }
}

}  // namespace interfaces
}  // namespace applications
}  // namespace robot_control