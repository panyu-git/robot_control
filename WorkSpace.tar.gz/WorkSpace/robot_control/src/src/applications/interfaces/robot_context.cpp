#include "robot_control/applications/interfaces/robot_context.hpp"

#include "robot_control/common/logging.hpp"
#include "robot_control/core/events.hpp"
#include "robot_control/core/robot_control_configs.hpp"
#include "robot_control/utils/logic_utils.hpp"

namespace robot_control {
namespace applications {
namespace interfaces {

core::FunctionStatus RobotContext::checkHealth(core::FunctionType function_type,
                                               std::chrono::steady_clock::time_point session_start_time) const {
    bool nav_feedback_interrupted = navigation && navigation->isNavFeedbackInterrupted();
    bool nav_server_offline = navigation && !navigation->isNavServerOnline();

    if (nav_feedback_interrupted || nav_server_offline) {
        // Grace period for new session initialization
        if (!nav_server_offline &&
            !utils::LogicUtils::IsTimeoutMs(session_start_time, core::FollowConfigs::kHealthGracePeriodMs)) {
            return core::FunctionStatus::RUNNING;  // Assume running during grace period
        }

        bool timed_out = false;
        std::string error_msg;

        if (nav_server_offline) {
            timed_out = true;
            error_msg = "导航服务异常（服务器离线）";
        } else if (nav_feedback_interrupted) {
            double last_feedback_time = navigation ? navigation->getLastNavFeedbackTime() : 0.0;
            timed_out =
                utils::LogicUtils::IsTimeoutMs(last_feedback_time, core::FollowConfigs::kSystemWatchdogTimeoutMs);
            error_msg = "导航数据流断开（超时）";
        }

        if (timed_out) {
            LOG_ERROR_NAMED("RobotContext",
                            "Health check FAILED for " << core::toString(function_type) << ": " << error_msg);

            // Publish failure event
            core::Event error_event(core::EventType::FUNCTION_FAILED, "RobotContext");
            error_event.data["function"] = core::toString(function_type);
            error_event.data["message"] = error_msg;
            core::EventBus::getInstance().publish(error_event);

            // Send HMI interaction if possible
            core::Event interaction_event(core::EventType::HMI_INTERACTION_REQUEST, "RobotContext");
            interaction_event.data["message"] = "提醒用户系统服务异常：" + error_msg;
            core::EventBus::getInstance().publish(interaction_event);

            return core::FunctionStatus::FAILED;
        }
    }

    return core::FunctionStatus::RUNNING;  // Default to running if no issues
}

}  // namespace interfaces
}  // namespace applications
}  // namespace robot_control
