#include "robot_control/core/robot_control_configs.hpp"

#include <ament_index_cpp/get_package_share_directory.hpp>
#include <filesystem>

namespace robot_control {
namespace core {

std::string BTConfig::xmlPathFollow() {
    return resolveXmlPath(kXmlRelativeFollow);
}

std::string BTConfig::xmlPathWakeup() {
    return resolveXmlPath(kXmlRelativeWakeup);
}

std::string BTConfig::resolveXmlPath(const std::string& relative_path) {
    namespace fs = std::filesystem;

    try {
        const auto share_dir = ament_index_cpp::get_package_share_directory("robot_control");
        const auto installed_path = fs::path(share_dir) / relative_path;
        if (fs::exists(installed_path)) {
            return installed_path.string();
        }
    } catch (const std::exception&) {
        // Fallback below for source-tree or unusual launch contexts.
    }

    const auto source_layout = fs::path("robot_control/config") / relative_path;
    if (fs::exists(source_layout)) {
        return fs::absolute(source_layout).string();
    }

    const auto package_root_layout = fs::path("config") / relative_path;
    if (fs::exists(package_root_layout)) {
        return fs::absolute(package_root_layout).string();
    }

    const auto workspace_install_layout = fs::path("install/robot_control/share/robot_control") / relative_path;
    if (fs::exists(workspace_install_layout)) {
        return fs::absolute(workspace_install_layout).string();
    }

    // Last resort: return a stable relative install-style path.
    return (fs::path("share/robot_control") / relative_path).string();
}

}  // namespace core
}  // namespace robot_control
