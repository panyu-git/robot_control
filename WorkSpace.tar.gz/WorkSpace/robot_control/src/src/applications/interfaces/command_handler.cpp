#include "robot_control/applications/interfaces/command_handler.hpp"

#include <algorithm>
#include <cctype>

#include "robot_control/common/logging.hpp"
#include "robot_control/core/enums.hpp"
#include "robot_control/core/robot_control_configs.hpp"

namespace robot_control {
namespace applications {
namespace interfaces {

namespace {
std::string parseStringFromParams(const std::map<std::string, std::string>& params,
                                const std::initializer_list<std::string>& keys,
                                const std::string& default_value = "0") {
    for (const auto& key : keys) {
        auto it = params.find(key);
        if (it != params.end() && !it->second.empty()) {
            return it->second;
        }
    }
    return default_value;
}

uint16_t parseIntFromParams(const std::map<std::string, std::string>& params,
                            const std::initializer_list<std::string>& keys,
                            uint16_t default_value = 0) {
    for (const auto& key : keys) {
        auto it = params.find(key);
        if (it == params.end() || it->second.empty()) {
            continue;
        }

        try {
            size_t pos = 0;
            uint16_t value = static_cast<uint16_t>(std::stoi(it->second, &pos));
            if (pos == it->second.size()) {
                return value;
            }
        } catch (...) {
            // Ignore invalid numeric values and try the next key.
        }
    }
    return default_value;
}

void normalizeIdentityParams(std::map<std::string, std::string>& params) {
    if (params.count("user_id") == 0 || params["user_id"].empty()) {
        auto sid_it = params.find("speaker_id");
        if (sid_it != params.end() && !sid_it->second.empty()) {
            params["user_id"] = sid_it->second;
        }
    }
    if (params.count("user_id") == 0 || params["user_id"].empty()) {
        auto vid_it = params.find("voiceprint_id");
        if (vid_it != params.end() && !vid_it->second.empty()) {
            params["user_id"] = vid_it->second;
        }
    }
}
}  // namespace

const std::set<std::string> CommandHandler::VALID_INTENTS = {"wakeup",
                                                             "wake_up",
                                                             "follow",
                                                             "stop_follow",
                                                             "unfollow",
                                                             "follow_speed_up",
                                                             "follow_speed_down",
                                                             "follow_distance_near",
                                                             "follow_distance_far",
                                                             "follow_location",
                                                             "stop",
                                                             "idle"};

CommandHandler::CommandHandler(std::shared_ptr<core::Blackboard> blackboard, core::EventBus* event_bus)
    : _blackboard(blackboard), _eventBus(event_bus ? event_bus : &core::EventBus::getInstance()) {}

bool CommandHandler::processCommand(const std::string& command, const std::map<std::string, std::string>& params) {
    std::string cmd_lower = toLower(command);

    if (cmd_lower == "wakeup" || cmd_lower == "wake_up") {
        return _handleWakeupCommand(params);
    } else if (cmd_lower == "follow") {
        return _handleFollowCommand(params);
    } else if (cmd_lower == "stop_follow" || cmd_lower == "unfollow") {
        return _handleStopFollowCommand(params);
    } else if (cmd_lower == "follow_speed_up") {
        return _handleFollowSpeedUpCommand(params);
    } else if (cmd_lower == "follow_speed_down") {
        return _handleFollowSpeedDownCommand(params);
    } else if (cmd_lower == "follow_distance_near") {
        return _handleFollowDistanceNearCommand(params);
    } else if (cmd_lower == "follow_distance_far") {
        return _handleFollowDistanceFarCommand(params);
    } else if (cmd_lower == "follow_location") {
        return _handleFollowLocationCommand(params);
    } else if (cmd_lower == "stop") {
        return _handleStopCommand(params);
    }

    return false;
}

std::vector<std::string> CommandHandler::getAvailableCommands() const {
    std::vector<std::string> commands(VALID_INTENTS.begin(), VALID_INTENTS.end());
    std::sort(commands.begin(), commands.end());
    return commands;
}

std::optional<core::EventV> CommandHandler::convertCommand(const std::string& command,
                                                           const std::map<std::string, std::string>& params) const {
    const std::string cmd = toLower(command);

    if (cmd == "mountup") {
        return core::EvStart{};
    } else if (cmd == "mountup_contact_done") {
        return core::EvMountUpContactDone{};
    } else if (cmd == "mountup_climb_done") {
        return core::EvMountUpClimbDone{};
    } else if (cmd == "mountup_error") {
        return core::EvError{parseIntFromParams(params, {"code", "error_code"})};
    } else if (cmd == "mountup_bb_user_id") {
        return core::EvUserIdChanged{parseStringFromParams(params, {"user_id", "value"})};
    } else if (cmd == "stop") {
        return core::EvStop{};
    }
    return std::nullopt;
}


bool CommandHandler::_handleWakeupCommand(const std::map<std::string, std::string>& params) {
    std::map<std::string, std::string> normalized = params;
    normalizeIdentityParams(normalized);
    // Wakeup rotate task parameters:
    // - target_yaw (rad) is required (fallback to wakeup_angle for compatibility).
    // - max_angular_velocity (rad/s) defaults to 0.5 if missing.
    // - timeout (s) is optional.
    if (normalized.count("target_yaw") == 0 || normalized["target_yaw"].empty()) {
        auto wakeup_it = normalized.find("wakeup_angle");
        if (wakeup_it != normalized.end() && !wakeup_it->second.empty()) {
            normalized["target_yaw"] = wakeup_it->second;
        }
    }
    if (normalized.count("target_yaw") == 0 || normalized["target_yaw"].empty()) {
        return false;
    }
    if (normalized.count("max_angular_velocity") == 0 || normalized["max_angular_velocity"].empty()) {
        normalized["max_angular_velocity"] = "0.5";
    }

    // user_id is optional for wakeup
    if (normalized.count("user_id") == 0 || normalized["user_id"].empty()) {
        normalized["user_id"] = "default_user";
    }

    // Data distribution: store raw params in blackboard
    for (const auto& [key, value] : normalized) {
        _blackboard->set(std::string(core::BlackboardKeys::LAST_WAKEUP_PREFIX) + key, value);
    }
    _blackboard->set(core::BlackboardKeys::CMD_WAKEUP_REQUEST, true);

    core::Event event(core::EventType::USER_COMMAND_WAKEUP, "CommandHandler");
    for (const auto& [key, value] : normalized) {
        event.data[key] = value;
    }
    event.data["task"] = "ROTATE_TASK";
    event.data["request_start"] = "true";
    _eventBus->publish(event);
    return true;
}

bool CommandHandler::_handleFollowCommand(const std::map<std::string, std::string>& params) {
    std::map<std::string, std::string> normalized = params;
    normalizeIdentityParams(normalized);

    // Update task params if provided
    auto distance_it = normalized.find("distance");
    if (distance_it != normalized.end()) {
        try {
            double distance = std::stod(distance_it->second);
            _blackboard->set(core::BlackboardKeys::TASK_FOLLOW_DISTANCE, distance);
        } catch (...) {
            // Ignore conversion errors
        }
    }

    auto speed_it = normalized.find("speed");
    if (speed_it != normalized.end()) {
        try {
            double speed = std::stod(speed_it->second);
            _blackboard->set(core::BlackboardKeys::TASK_FOLLOW_SPEED, speed);
        } catch (...) {
            // Ignore conversion errors
        }
    }

    // "location" is accepted as follow-mode/location parameter.
    auto location_it = normalized.find("location");
    if (location_it != normalized.end() && !location_it->second.empty()) {
        auto location = toLower(location_it->second);
        if (location == "left" || location == "right" || location == "back") {
            _blackboard->set(core::BlackboardKeys::TASK_FOLLOW_MODE, location);
            normalized["mode"] = location;
            normalized["param_follow_dir"] = (location == "left") ? "1" : ((location == "right") ? "2" : "0");
        } else {
            // Preserve non-enum location for downstream use (e.g. remote pose/name).
            normalized["remote_pose"] = location_it->second;
        }
    }

    // Data distribution: store raw params in blackboard
    for (const auto& [key, value] : normalized) {
        _blackboard->set(std::string(core::BlackboardKeys::FOLLOW_REQUEST_PREFIX) + key, value);
    }

    // Increment session ID in blackboard
    int session_id = _blackboard->get<int>(core::BlackboardKeys::FOLLOW_ACTIVATION_SESSION_ID, 0);
    _blackboard->set(core::BlackboardKeys::FOLLOW_ACTIVATION_SESSION_ID, session_id + 1);

    _blackboard->set(core::BlackboardKeys::CMD_FOLLOW_REQUEST, true);

    // Publish follow activation event only (single source of truth).
    core::Event activation_event(core::EventType::FOLLOW_ACTIVATION_REQUESTED, "CommandHandler");
    for (const auto& [key, value] : normalized) {
        activation_event.data[key] = value;
    }
    if (activation_event.data.count("activation_mode") == 0) {
        activation_event.data["activation_mode"] = "face_only";
    }
    if (activation_event.data.count("task") == 0) {
        auto task_it = activation_event.data.find("follow");
        activation_event.data["task"] = (task_it != activation_event.data.end() && !task_it->second.empty())
                                            ? task_it->second
                                            : std::string("FOLLOW_TASK");
    }
    if (activation_event.data.count("request_start") == 0) {
        activation_event.data["request_start"] = "true";
    }
    _eventBus->publish(activation_event);

    return true;
}

bool CommandHandler::_handleStopFollowCommand(const std::map<std::string, std::string>& params) {
    _blackboard->set(core::BlackboardKeys::CMD_STOP_REQUEST, true);
    core::Event event(core::EventType::USER_COMMAND_STOP_FOLLOW, "CommandHandler");
    for (const auto& [key, value] : params) {
        event.data[key] = value;
    }
    _eventBus->publish(event);
    return true;
}

bool CommandHandler::_handleFollowSpeedUpCommand(const std::map<std::string, std::string>& params) {
    _blackboard->set(core::BlackboardKeys::CMD_FOLLOW_SPEED_UP, true);
    core::Event event(core::EventType::USER_COMMAND_FOLLOW_SPEED_UP, "CommandHandler");
    event.data["delta"] = params.count("delta") > 0 ? params.at("delta") : "0.1";
    if (params.count("user_id") > 0) {
        event.data["user_id"] = params.at("user_id");
    }
    _eventBus->publish(event);
    return true;
}

bool CommandHandler::_handleFollowSpeedDownCommand(const std::map<std::string, std::string>& params) {
    _blackboard->set(core::BlackboardKeys::CMD_FOLLOW_SPEED_DOWN, true);
    core::Event event(core::EventType::USER_COMMAND_FOLLOW_SPEED_DOWN, "CommandHandler");
    event.data["delta"] = params.count("delta") > 0 ? params.at("delta") : "0.1";
    if (params.count("user_id") > 0) {
        event.data["user_id"] = params.at("user_id");
    }
    _eventBus->publish(event);
    return true;
}

bool CommandHandler::_handleFollowDistanceNearCommand(const std::map<std::string, std::string>& params) {
    _blackboard->set(core::BlackboardKeys::CMD_FOLLOW_DISTANCE_NEAR, true);
    core::Event event(core::EventType::USER_COMMAND_FOLLOW_DISTANCE_NEAR, "CommandHandler");
    event.data["delta"] = params.count("delta") > 0 ? params.at("delta") : "0.2";
    if (params.count("user_id") > 0) {
        event.data["user_id"] = params.at("user_id");
    }
    _eventBus->publish(event);
    return true;
}

bool CommandHandler::_handleFollowDistanceFarCommand(const std::map<std::string, std::string>& params) {
    _blackboard->set(core::BlackboardKeys::CMD_FOLLOW_DISTANCE_FAR, true);
    core::Event event(core::EventType::USER_COMMAND_FOLLOW_DISTANCE_FAR, "CommandHandler");
    event.data["delta"] = params.count("delta") > 0 ? params.at("delta") : "0.2";
    if (params.count("user_id") > 0) {
        event.data["user_id"] = params.at("user_id");
    }
    _eventBus->publish(event);
    return true;
}

bool CommandHandler::_handleFollowLocationCommand(const std::map<std::string, std::string>& params) {
    std::string location =
        params.count("location") > 0 ? params.at("location") : (params.count("value") > 0 ? params.at("value") : "");
    if (!location.empty()) {
        _blackboard->set(core::BlackboardKeys::CMD_FOLLOW_LOCATION_REQUEST, location);
    }

    core::Event event(core::EventType::USER_COMMAND_FOLLOW_LOCATION, "CommandHandler");
    if (params.count("location") > 0) {
        event.data["location"] = params.at("location");
    } else if (params.count("value") > 0) {
        event.data["location"] = params.at("value");
    } else {
        return false;
    }
    if (params.count("user_id") > 0) {
        event.data["user_id"] = params.at("user_id");
    }
    _eventBus->publish(event);
    return true;
}

bool CommandHandler::_handleStopCommand(const std::map<std::string, std::string>& params) {
    // Set stop request flag
    _blackboard->set(core::BlackboardKeys::CMD_STOP_REQUEST, true);

    // Publish event
    core::Event event(core::EventType::USER_COMMAND_STOP, "CommandHandler");
    for (const auto& [key, value] : params) {
        event.data[key] = value;
    }
    _eventBus->publish(event);

    return true;
}

std::string CommandHandler::toLower(const std::string& str) const {
    std::string result = str;
    std::transform(result.begin(), result.end(), result.begin(), [](unsigned char c) { return std::tolower(c); });
    return result;
}

}  // namespace interfaces
}  // namespace applications
}  // namespace robot_control
