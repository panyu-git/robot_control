# Function Manager - Input/Output Specification

## Overview

The `FunctionManager` is the FSM (Finite State Machine) controller that manages robot functions (IDLE, FOLLOW, PHOTO, CHARGE).

---

## Constructor

### Input
```python
FunctionManager(blackboard: Blackboard, event_bus: EventBus = None)
```

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `blackboard` | `Blackboard` | Yes | Shared state container |
| `event_bus` | `EventBus` | No | Event bus for publishing events (default: creates new) |

### Output
- Returns: `FunctionManager` instance

---

## Methods

### 1. register_function()

Register a function with the manager.

#### Input
```python
register_function(function: Function) -> None
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `function` | `Function` | Function instance (IdleFunction, FollowFunction, etc.) |

#### Output
- Returns: `None`

#### Example
```python
manager.register_function(IdleFunction(blackboard, task_manager))
manager.register_function(FollowFunction(blackboard, task_manager, navigation))
```

---

### 2. transition_to()

Transition to a new function state.

#### Input
```python
transition_to(
    target: FunctionType,
    save_context: bool = False,
    restore_context: bool = False,
    force: bool = False
) -> bool
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `target` | `FunctionType` | - | Target function (IDLE, FOLLOW, PHOTO, CHARGE) |
| `save_context` | `bool` | `False` | Save current function's context for later resume |
| `restore_context` | `bool` | `False` | Restore target function's previously saved context |
| `force` | `bool` | `False` | Force transition, bypass priority check |

#### Output
- Returns: `bool` - `True` if transition succeeded, `False` if blocked

#### Examples
```python
# Simple transition
manager.transition_to(FunctionType.FOLLOW)
# Input:  target=FOLLOW, save_context=False, restore_context=False, force=False
# Output: True (if allowed) or False (if blocked by priority)

# Soft preemption (pause FOLLOW for PHOTO)
manager.transition_to(FunctionType.PHOTO, save_context=True)
# Input:  target=PHOTO, save_context=True
# Output: True
# Effect: FOLLOW context saved, can be restored later

# Restore after PHOTO completes
manager.transition_to(FunctionType.FOLLOW, restore_context=True)
# Input:  target=FOLLOW, restore_context=True
# Output: True
# Effect: FOLLOW resumes with saved context

# Force transition (for CHARGE)
manager.transition_to(FunctionType.CHARGE, force=True)
# Input:  target=CHARGE, force=True
# Output: True (always succeeds)
```

---

### 3. tick()

Execute one tick of the function manager (called in control loop).

#### Input
```python
tick() -> Optional[FunctionStatus]
```
- No parameters

#### Output
- Returns: `FunctionStatus` or `None`

| Return Value | Description |
|--------------|-------------|
| `FunctionStatus.IDLE` | Function is idle |
| `FunctionStatus.RUNNING` | Function is executing |
| `FunctionStatus.PAUSED` | Function is paused |
| `FunctionStatus.COMPLETED` | Function completed successfully |
| `FunctionStatus.FAILED` | Function failed |
| `None` | No current function |

#### Example
```python
status = manager.tick()
# Input:  (none)
# Output: FunctionStatus.RUNNING

# Internal behavior:
# 1. Checks blackboard for low battery -> triggers CHARGE if needed
# 2. Checks blackboard for emergency stop -> triggers IDLE if needed
# 3. Calls current_function.tick()
# 4. If COMPLETED -> handles completion (restore previous or go to IDLE)
# 5. If FAILED -> handles failure (go to IDLE)
```

---

### 4. can_transition_to()

Check if transition to target function is allowed.

#### Input
```python
can_transition_to(target: FunctionType, save_context: bool = False) -> bool
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `target` | `FunctionType` | - | Target function type |
| `save_context` | `bool` | `False` | If True, allows same-priority soft preemption |

#### Output
- Returns: `bool` - `True` if transition allowed

#### Priority Rules
```
Priority: CHARGE(1) > FOLLOW(2) = PHOTO(2) > IDLE(3)

Transition allowed if:
1. Target has higher priority (lower number) than current
2. save_context=True AND same priority AND current allows soft preemption
3. Current function is COMPLETED, FAILED, or IDLE
```

#### Examples
```python
# Current: FOLLOW (priority 2)
manager.can_transition_to(FunctionType.CHARGE)
# Output: True (CHARGE priority 1 > FOLLOW priority 2)

manager.can_transition_to(FunctionType.PHOTO)
# Output: False (same priority, no save_context)

manager.can_transition_to(FunctionType.PHOTO, save_context=True)
# Output: True (same priority with soft preemption)

manager.can_transition_to(FunctionType.IDLE)
# Output: False (IDLE priority 3 < FOLLOW priority 2)
```

---

### 5. get_function()

Get a registered function by type.

#### Input
```python
get_function(func_type: FunctionType) -> Optional[Function]
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `func_type` | `FunctionType` | Function type to retrieve |

#### Output
- Returns: `Function` instance or `None` if not registered

---

### 6. has_saved_context()

Check if a function has saved context.

#### Input
```python
has_saved_context(func_type: FunctionType) -> bool
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `func_type` | `FunctionType` | Function type to check |

#### Output
- Returns: `bool` - `True` if context exists

---

### 7. clear_saved_context()

Clear saved context for a function or all functions.

#### Input
```python
clear_saved_context(func_type: FunctionType = None) -> None
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `func_type` | `FunctionType` | `None` | Specific function, or None for all |

#### Output
- Returns: `None`

---

### 8. get_state_info()

Get current state information for debugging.

#### Input
```python
get_state_info() -> Dict[str, Any]
```
- No parameters

#### Output
- Returns: `Dict[str, Any]`

```python
{
    "current_function": "FOLLOW",           # Current function name or None
    "current_status": "RUNNING",            # Current status name or None
    "previous_function": "IDLE",            # Previous function name or None
    "state_duration": 5.234,                # Seconds in current state
    "saved_contexts": [FunctionType.FOLLOW], # List of functions with saved context
    "registered_functions": ["IDLE", "FOLLOW", "PHOTO", "CHARGE"]
}
```

---

## Properties (Read-only Output)

| Property | Type | Description |
|----------|------|-------------|
| `current_function` | `Optional[Function]` | Current function instance |
| `current_type` | `Optional[FunctionType]` | Current function type enum |
| `current_status` | `Optional[FunctionStatus]` | Current function status |

---

## Events Published (Output)

The FunctionManager publishes events via EventBus:

| Event | When | Data |
|-------|------|------|
| `FUNCTION_STARTED` | After entering new function | `{"function": "FOLLOW"}` |
| `FUNCTION_COMPLETED` | After exiting function | `{"function": "FOLLOW"}` |
| `FUNCTION_FAILED` | When function fails | `{"function": "FOLLOW"}` |
| `BATTERY_LOW` | When low battery triggers CHARGE | `{"level": 15}` |

---

## Blackboard Reads (Input from Shared State)

| Field | Type | Purpose |
|-------|------|---------|
| `sensor_data.battery_level` | `int` | Check for low battery |
| `sensor_data.emergency_stop` | `bool` | Check for emergency stop |
| `task_params.charge_threshold` | `int` | Battery threshold (default 20%) |
| `fsm_state.previous_state` | `FunctionType` | For restoration logic |

---

## Blackboard Writes (Output to Shared State)

| Field | Type | Purpose |
|-------|------|---------|
| `fsm_state.current_state` | `FunctionType` | Updated on transition |
| `fsm_state.previous_state` | `FunctionType` | Set to old state |
| `fsm_state.state_start_time` | `float` | Timestamp of transition |
| `fsm_state.transition_count` | `int` | Incremented on transition |

---

## Complete Usage Example

```python
from core.blackboard import Blackboard
from core.enums import FunctionType, FunctionStatus
from applications.framework.function_manager import FunctionManager
from applications.framework.task_manager import TaskManager

# Setup
blackboard = Blackboard()
task_manager = TaskManager(blackboard)
manager = FunctionManager(blackboard)

# Register functions
manager.register_function(IdleFunction(blackboard, task_manager))
manager.register_function(FollowFunction(blackboard, task_manager, nav))
manager.register_function(PhotoFunction(blackboard, task_manager, cam))
manager.register_function(ChargeFunction(blackboard, task_manager, bat))

# Start in IDLE
manager.transition_to(FunctionType.IDLE)
# Input:  target=IDLE
# Output: True

# Transition to FOLLOW
manager.transition_to(FunctionType.FOLLOW)
# Input:  target=FOLLOW
# Output: True

# Main control loop
while running:
    status = manager.tick()
    # Input:  (reads blackboard.sensor_data)
    # Output: FunctionStatus.RUNNING

    # Check for photo request
    if blackboard.user_commands.photo_request:
        manager.transition_to(FunctionType.PHOTO, save_context=True)
        # Input:  target=PHOTO, save_context=True
        # Output: True
        # Effect: FOLLOW paused, context saved

# State info
info = manager.get_state_info()
# Output: {"current_function": "PHOTO", "current_status": "RUNNING", ...}
```

---

## State Transition Diagram

```
Input: transition_to(FOLLOW)     Input: transition_to(PHOTO, save_context=True)
            │                                    │
            ▼                                    ▼
┌────────────────┐                    ┌────────────────┐
│      IDLE      │ ──────────────────>│     FOLLOW     │
│  (priority 3)  │                    │  (priority 2)  │
└────────────────┘                    └───────┬────────┘
        ▲                                     │
        │                                     │ save_context=True
        │                                     ▼
        │                             ┌────────────────┐
        │                             │     PHOTO      │
        │                             │  (priority 2)  │
        │                             └───────┬────────┘
        │                                     │
        │   Input: tick() returns COMPLETED   │
        │   Output: restore_context=True      │
        │◄────────────────────────────────────┘
        │
        │   Input: blackboard.battery_level <= 20
        │   Output: force=True transition
        ▼
┌────────────────┐
│     CHARGE     │
│  (priority 1)  │
└────────────────┘
```
