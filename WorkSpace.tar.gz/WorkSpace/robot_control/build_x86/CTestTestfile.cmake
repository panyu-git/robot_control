# CMake generated Testfile for 
# Source directory: /home/lenovo/WorkSpace/robot_control/src
# Build directory: /home/lenovo/WorkSpace/robot_control/build_x86
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(robot_control_ut "/home/lenovo/WorkSpace/robot_control/build_x86/robot_control_ut")
set_tests_properties(robot_control_ut PROPERTIES  _BACKTRACE_TRIPLES "/home/lenovo/WorkSpace/robot_control/src/CMakeLists.txt;164;add_test;/home/lenovo/WorkSpace/robot_control/src/CMakeLists.txt;0;")
subdirs("3rdparty/BehaviorTree.CPP")
