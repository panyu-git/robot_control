#pragma once

#include <any>
#include <map>
#include <memory>
#include <optional>
#include <string>
#include <unordered_map>
#include <vector>

#include "behaviortree_cpp/behavior_tree.h"
#include "behaviortree_cpp/bt_factory.h"

#ifdef BTCPP_GROOT_INTERFACE_ENABLED
#include "behaviortree_cpp/loggers/groot2_publisher.h"
#endif

#include "robot_control/applications/framework/execution_engine.hpp"
#include "robot_control/core/blackboard.hpp"
#include "robot_control/core/enums.hpp"

namespace robot_control {
namespace applications {
namespace framework {

class TaskManager : public IExecutionEngine {
   public:
    TaskManager(std::shared_ptr<core::Blackboard> blackboard);
    ~TaskManager();

    // Node registration
    BT::BehaviorTreeFactory& factory() {
        return _factory;
    }

    // IExecutionEngine implementation
    bool load(const std::string& name, const std::string& resource_path) override;
    bool preload(const std::string& name, const std::string& resource_path) override;
    core::NodeStatus tick() override;
    void abort() override;
    void reset() override;
    void pause() override;
    void resume() override;
    core::NodeStatus lastStatus() const override {
        return _lastStatus;
    }
    bool isRunning() const override;
    bool isPaused() const override {
        return _isPaused;
    }

    // Zero-Binding: Write status to blackboard
    void setStatusNamespace(const std::string& ns) override {
        _statusNamespace = ns;
    }
    void onPostTick() override;

    // Error Handling
    std::string getLastError() const override {
        return _lastError;
    }
    int getErrorCode() const override {
        return _errorCode;
    }

    // Tree specific management
    void unregisterTree(const std::string& name);
    std::optional<std::string> currentTreeName() const {
        return _currentTreeName;
    }

   private:
    std::shared_ptr<core::Blackboard> _blackboard;
    BT::BehaviorTreeFactory _factory;

    std::unordered_map<std::string, BT::Tree> _trees;
    std::optional<std::string> _currentTreeName;
    core::NodeStatus _lastStatus;

    bool _isPaused;
    std::string _lastError;
    int _errorCode = 0;
    std::string _statusNamespace;
#ifdef BTCPP_GROOT_INTERFACE_ENABLED
    std::unique_ptr<BT::Groot2Publisher> _groot_publisher;
#endif
};

}  // namespace framework
}  // namespace applications
}  // namespace robot_control
