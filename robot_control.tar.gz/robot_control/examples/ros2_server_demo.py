#!/usr/bin/env python3
"""
ROS2 Server Demo - 演示如何使用 ROS2 服务端接口

这个脚本演示：
1. 启动 RobotController 和 ROS2Server
2. 通过服务接口发送命令
3. 订阅状态和事件话题
4. 模拟语音/遥控器输入

Usage:
    cd /path/to/robot_control
    python -m examples.ros2_server_demo
"""

import sys
import time
import logging

# Setup path
sys.path.insert(0, 'src')

from applications.interfaces.robot_controller import RobotController
from services.ros2_server import (
    ROS2Server,
    CommandType,
    RobotCommandRequest,
    GetRobotStatusRequest,
    RobotStatusMsg,
    BatteryStatusMsg,
    RobotEventMsg,
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("demo")


def on_status_update(msg: RobotStatusMsg):
    """Callback for /robot/status topic"""
    logger.info(f"[STATUS] State: {msg.state_name}, Battery: {msg.battery_level:.1f}%, "
                f"Task: {msg.current_task}, Position: ({msg.position_x:.2f}, {msg.position_y:.2f})")


def on_battery_update(msg: BatteryStatusMsg):
    """Callback for /robot/battery topic"""
    status = "Charging" if msg.charging else "Discharging"
    logger.info(f"[BATTERY] Level: {msg.level:.1f}%, Voltage: {msg.voltage:.1f}V, "
                f"Current: {msg.current:.2f}A, Status: {status}")


def on_event(msg: RobotEventMsg):
    """Callback for /robot/events topic"""
    logger.info(f"[EVENT] {msg.event_name}: {msg.message}")


def demo_service_calls(server: ROS2Server):
    """演示服务调用"""
    logger.info("\n" + "="*60)
    logger.info("Demo: Service Calls (服务调用)")
    logger.info("="*60)
    
    # 1. Get current status
    logger.info("\n--- 1. Getting robot status (/robot/get_status) ---")
    status_req = GetRobotStatusRequest(include_details=True)
    status_resp = server.handle_get_status(status_req)
    logger.info(f"State: {status_resp.state_name}")
    logger.info(f"Battery: {status_resp.battery_level:.1f}%")
    logger.info(f"Position: ({status_resp.position_x:.2f}, {status_resp.position_y:.2f}, {status_resp.position_theta:.2f})")
    logger.info(f"Details: {status_resp.details_json}")
    
    # 2. Send follow command
    logger.info("\n--- 2. Sending FOLLOW command (/robot/command) ---")
    cmd_req = RobotCommandRequest(command_type=CommandType.FOLLOW)
    cmd_resp = server.handle_command(cmd_req)
    logger.info(f"Success: {cmd_resp.success}, Message: {cmd_resp.message}, TaskID: {cmd_resp.task_id}")
    
    time.sleep(2)
    
    # 3. Send stop command
    logger.info("\n--- 3. Sending STOP command (/robot/command) ---")
    cmd_req = RobotCommandRequest(command_type=CommandType.IDLE)
    cmd_resp = server.handle_command(cmd_req)
    logger.info(f"Success: {cmd_resp.success}, Message: {cmd_resp.message}")
    
    time.sleep(1)


def demo_voice_commands(server: ROS2Server):
    """演示语音命令处理"""
    logger.info("\n" + "="*60)
    logger.info("Demo: Voice Commands (语音命令)")
    logger.info("="*60)
    
    # Simulate voice input
    voice_commands = [
        "跟着我",      # Follow
        "停止",        # Stop
        "拍照",        # Photo
        "充电",        # Charge
    ]
    
    for voice in voice_commands:
        logger.info(f"\n--- Voice: '{voice}' ---")
        server.simulate_voice_input(voice, confidence=0.95)
        time.sleep(2)
    
    # Stop
    server.simulate_voice_input("停止", confidence=0.95)


def demo_navigation_command(server: ROS2Server):
    """演示导航命令"""
    logger.info("\n" + "="*60)
    logger.info("Demo: Navigation Command (导航命令)")
    logger.info("="*60)
    
    # Navigate to specific pose
    logger.info("\n--- Navigating to (5.0, 3.0) ---")
    cmd_req = RobotCommandRequest(
        command_type=CommandType.NAVIGATE,
        target_x=5.0,
        target_y=3.0,
        target_theta=1.57,
        frame_id="odom"
    )
    cmd_resp = server.handle_command(cmd_req)
    logger.info(f"Success: {cmd_resp.success}, Message: {cmd_resp.message}, TaskID: {cmd_resp.task_id}")
    
    # Wait for navigation
    time.sleep(3)
    
    # Check status
    status_req = GetRobotStatusRequest(include_details=True)
    status_resp = server.handle_get_status(status_req)
    logger.info(f"Current position: ({status_resp.position_x:.2f}, {status_resp.position_y:.2f})")


def demo_boarding_flow(server: ROS2Server):
    """演示上下车流程"""
    logger.info("\n" + "="*60)
    logger.info("Demo: Boarding Flow (上下车流程)")
    logger.info("="*60)
    
    # 1. Start boarding
    logger.info("\n--- 1. Starting boarding command ---")
    cmd_req = RobotCommandRequest(command_type=CommandType.BOARDING)
    cmd_resp = server.handle_command(cmd_req)
    logger.info(f"Success: {cmd_resp.success}, Message: {cmd_resp.message}")
    
    time.sleep(2)
    
    # 2. Confirm boarding (after user boards)
    logger.info("\n--- 2. Confirming boarding ---")
    cmd_req = RobotCommandRequest(command_type=CommandType.CONFIRM_BOARDING)
    cmd_resp = server.handle_command(cmd_req)
    logger.info(f"Success: {cmd_resp.success}, Message: {cmd_resp.message}")
    
    time.sleep(1)
    
    # Stop to clean up
    cmd_req = RobotCommandRequest(command_type=CommandType.IDLE)
    server.handle_command(cmd_req)


def main():
    logger.info("="*60)
    logger.info("ROS2 Server Demo")
    logger.info("="*60)
    
    # Create and start controller
    logger.info("\nInitializing RobotController...")
    controller = RobotController(simulated=True)
    controller.start(enable_ros2_server=True)
    
    # Get ROS2 server reference
    server = controller.ros2_server
    
    # Register callbacks for status/events
    server.register_status_callback(on_status_update)
    server.register_battery_callback(on_battery_update)
    server.register_event_callback(on_event)
    
    try:
        # Wait for initial status
        time.sleep(1)
        
        # Run demos
        demo_service_calls(server)
        demo_voice_commands(server)
        # demo_navigation_command(server)  # Uncomment to test
        # demo_boarding_flow(server)       # Uncomment to test
        
        logger.info("\n" + "="*60)
        logger.info("Demo Complete!")
        logger.info("="*60)
        
    except KeyboardInterrupt:
        logger.info("\nInterrupted by user")
    finally:
        controller.shutdown()
        logger.info("Controller shut down")


if __name__ == "__main__":
    main()
