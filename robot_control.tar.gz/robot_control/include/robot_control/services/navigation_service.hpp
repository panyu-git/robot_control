#pragma once

#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <nav_msgs/msg/odometry.hpp>
#include <nlohmann/json.hpp>
#include <optional>
#include <rclcpp/rclcpp.hpp>
#include <rclcpp_action/rclcpp_action.hpp>
#include <std_msgs/msg/string.hpp>
#include <string>
#include <tuple>

#include "nav_interfaces/action/nav_task_json.hpp"
#include "nav_interfaces/msg/follow_task.hpp"
#include "robot_control/core/enums.hpp"
#include "robot_control/services/ros2_interface.hpp"
#include "robot_control/services/service_base.hpp"

namespace robot_control {
namespace services {

enum class NavigationMode { IDLE, FOLLOW_HUMAN, NAVIGATE_TO_POSE, NAVIGATE_TO_LOCATION };

class NavigationService : public ServiceBase {
   public:
    static constexpr double CONFIDENCE_THRESHOLD = 0.3;

    NavigationService(bool simulated = false);
    virtual ~NavigationService();

    void init(rclcpp::Node::SharedPtr node);

    // Lifecycle overrides
    bool _doInitialize() override;
    void _doShutdown() override;

    // Commands
    bool startFollow(const std::string& mode, double distance, double speed, const std::string& user_id = "");
    bool requestFollowTask(const std::string& task, const std::string& user_id,
                           const std::map<std::string, std::string>& params = {});
    bool updateFollowParams(std::optional<double> distance, std::optional<double> speed);
    bool updateFollowPosition(const std::string& mode);
    // Stop follow and reset internal states.
    // Cancels nav_task_request (NavTaskJson) goals.
    void stopFollow();
    std::map<std::string, std::string> pauseFollow();
    bool resumeFollow(const std::map<std::string, std::string>& context);
    void resetFollowState();

    core::NavigationStatus update();

    bool navigateToPose(double x, double y, double theta, std::function<void(bool)> callback = nullptr);
    bool navigateToLocation(const std::string& name, std::function<void(bool)> callback = nullptr);
    bool navigateToChargingStation(std::function<void(bool)> callback = nullptr);
    bool cancelNavigation();
    bool stopNavigation();

    // Status checks
    bool isReady() const;
    bool isNavServerOnline() const;
    bool isNavigationComplete() const;
    bool isNavigationSuccessful() const;
    bool isNavFeedbackFresh(int64_t timeout_ms = 3000) const;

    // Properties
    core::NavigationStatus navigationStatus() const;
    bool isNavFeedbackInterrupted() const;
    double getLastNavFeedbackTime() const;
    std::optional<double> getTargetTimeout() const;
    std::tuple<double, double, double> currentPose() const;

    // Feedback
    std::map<std::string, std::string> getFeedback() const;

   private:
    mutable std::mutex _mutex;
    core::NavigationStatus _status_nav;
    NavigationMode _mode;
    std::map<std::string, std::string> _follow_params;
    double _last_follow_trace_time;
    double _last_nav_feedback_time;
    mutable double _last_nav_timeout_warn_time;

    std::string _last_task_name;
    std::string _last_task_state;
    std::string _last_task_message;
    std::optional<double> _target_timeout;  // Explicit timeout from service progress feedback

    rclcpp_action::Client<nav_interfaces::action::NavTaskJson>::SharedPtr _nav_client;
    rclcpp::Publisher<nav_interfaces::msg::FollowTask>::SharedPtr _follow_task_pub;
    rclcpp::Node::SharedPtr _node;

    /// Last accepted nav_task_request goal (for reliable async_cancel_goal vs cancel_all).
    std::shared_ptr<rclcpp_action::ClientGoalHandle<nav_interfaces::action::NavTaskJson>> _active_nav_goal_handle;

    GoalStatus _nav_goal_status;
    uint64_t _current_goal_id = 0;
    Pose2D _current_pose;
    std::optional<std::string> _goal_location;
    std::function<void(bool)> _navigation_complete_callback;

    void _processNavStatusJson(const std::string& json_str);

    // Private versions of status checks that do not lock, for internal use
    bool _isNavFeedbackFresh(int64_t timeout_ms) const;
    core::NavigationStatus _navigationStatus() const;
    bool _isNavigationComplete() const;
    bool _isNavigationSuccessful() const;
    std::tuple<double, double, double> _currentPose() const;
};

}  // namespace services
}  // namespace robot_control
