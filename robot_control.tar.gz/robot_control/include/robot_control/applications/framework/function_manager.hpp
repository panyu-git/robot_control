#pragma once

#include <map>
#include <memory>
#include <optional>
#include <string>
#include <unordered_map>

#include "robot_control/applications/framework/execution_engine.hpp"
#include "robot_control/applications/framework/function_base.hpp"
#include "robot_control/applications/framework/function_scheduler.hpp"
#include "robot_control/core/blackboard.hpp"
#include "robot_control/core/enums.hpp"
#include "robot_control/core/events.hpp"

namespace robot_control {
namespace applications {
namespace framework {

class FunctionManager {
   public:
    FunctionManager(std::shared_ptr<core::Blackboard> blackboard, IExecutionEngine* engine = nullptr,
                    core::EventBus* event_bus = nullptr);

    // Properties
    Function* currentFunction() const {
        return _functionScheduler ? _functionScheduler->currentFunction().get() : nullptr;
    }
    std::optional<core::FunctionType> currentType() const;
    std::optional<core::FunctionStatus> currentStatus() const;

    // Function registration
    void registerFunction(std::unique_ptr<Function> function);
    Function* getFunction(core::FunctionType func_type);

    /**
     * @brief Register a blackboard key that triggers a function transition.
     */
    void registerRequestTrigger(const std::string& blackboard_key, core::FunctionType target_type);

    // Transition management
    bool canTransitionTo(core::FunctionType target, bool save_context = false);
    bool transitionTo(core::FunctionType target, bool save_context = false, bool restore_context = false,
                      bool force = false);

    // Execution
    std::optional<core::FunctionStatus> tick();
    void warmup();

    // Context management
    bool hasSavedContext(core::FunctionType func_type) const;
    void clearSavedContext(const std::optional<core::FunctionType>& func_type = std::nullopt);

    // State information
    std::map<std::string, std::any> getStateInfo() const;

   private:
    void _checkPriorityEvents();
    void _handleFunctionCompleted();
    void _handleFunctionFailed();
    void _ensureEngineSynced();
    void _setupPriorityValidators();
    void _setupRequestTriggers();
    void _updateFSMState(core::FunctionType target);
    void _sendInteractionFeedback(const std::string& message, int session_id);

    std::shared_ptr<core::Blackboard> _blackboard;
    IExecutionEngine* _engine;
    core::EventBus* _eventBus;
    std::unique_ptr<FunctionScheduler> _functionScheduler;
    std::unordered_map<core::FunctionType, std::shared_ptr<Function>> _functions;
    std::map<core::FunctionType, std::map<std::string, std::any>> _savedContexts;
    std::optional<core::FunctionType> _lastSyncedType;
    // Use a vector of pairs for cache-friendly polling instead of unordered_map
    std::vector<std::pair<std::string, core::FunctionType>> _triggerMap;

    // Pre-allocated buffer to avoid heap allocation in every tick
    std::vector<std::shared_ptr<Function>> _candidatesBuffer;
};

}  // namespace framework
}  // namespace applications
}  // namespace robot_control
