#pragma once

#include <any>
#include <map>
#include <memory>
#include <string>

#include "robot_control/core/enums.hpp"

namespace robot_control {
namespace applications {
namespace framework {

/**
 * @brief Interface for execution engines (Behavior Tree, FSM, etc.)
 */
class IExecutionEngine {
   public:
    virtual ~IExecutionEngine() = default;

    // Lifecycle
    virtual bool load(const std::string& name, const std::string& resource_path) = 0;
    virtual bool preload(const std::string& name, const std::string& resource_path) = 0;

    // Execution
    virtual core::NodeStatus tick() = 0;
    virtual void abort() = 0;
    virtual void reset() = 0;
    virtual void pause() = 0;
    virtual void resume() = 0;

    // Status
    virtual core::NodeStatus lastStatus() const = 0;
    virtual bool isRunning() const = 0;
    virtual bool isPaused() const = 0;

    // Error Handling
    virtual std::string getLastError() const = 0;
    virtual int getErrorCode() const = 0;

    // Zero-Binding: Write status to blackboard
    virtual void setStatusNamespace(const std::string& ns) = 0;
    virtual void onPostTick() = 0;
};

}  // namespace framework
}  // namespace applications
}  // namespace robot_control
