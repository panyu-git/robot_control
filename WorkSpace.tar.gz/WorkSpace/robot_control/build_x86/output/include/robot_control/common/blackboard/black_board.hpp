#pragma once

#include <any>
#include <atomic>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <tuple>
#include <type_traits>
#include <typeindex>
#include <utility>
#include <vector>

#include "robot_control/common/logging.hpp"
#include "thread_pool.hpp"
#include "function_traits.hpp"

namespace robot_control {
namespace bbd {

inline constexpr const char kBlackBoardLoggerName[] = "BlackBoard";

enum PubType { NoSave, Save };
enum SubType { Sync, Async };

struct Handler {
  std::string name;
  uint64_t id;
};

namespace detail {

template <typename Tuple, typename... Args, std::size_t... Is>
void assign_tuple_to_refs(Tuple& t, std::index_sequence<Is...>, Args&... out) {
  ((out = std::get<Is>(t)), ...);
}

template <typename Tuple, typename... Args>
bool assign_tuple_to_refs(Tuple& t, Args&... out) {
  constexpr std::size_t expected = std::tuple_size_v<Tuple>;
  constexpr std::size_t actual = sizeof...(Args);
  if (expected != actual) {
    LOG_ERROR_NAMED(kBlackBoardLoggerName,
                    "Get: argument count does not match stored message, expected " << expected
                                                                                     << " got "
                                                                                     << actual);
    return false;
  }
  assign_tuple_to_refs(t, std::make_index_sequence<actual>{}, out...);
  return true;
}

}  // namespace detail

class BlackBoard {
 public:
  static BlackBoard& GetInstance() {
    static BlackBoard instance;
    return instance;
  }

  BlackBoard(const BlackBoard&) = delete;
  BlackBoard& operator=(const BlackBoard&) = delete;

  // --- Pub-Sub (variadic, same packing style as RPC Call) ---

  template <PubType pub_type, typename... Args>
  bool Pub(const std::string& topic, Args&&... args) {
    using MessageTuple = std::tuple<std::decay_t<Args>...>;
    const std::type_index tuple_type(typeid(MessageTuple));

    auto msg_ptr = std::make_shared<std::any>(MessageTuple(std::forward<Args>(args)...));

    std::vector<std::function<void(const std::string&, std::shared_ptr<std::any>)>> sync_handlers;
    std::vector<std::function<void(const std::string&, std::shared_ptr<std::any>)>> async_handlers;

    {
      std::lock_guard<std::mutex> lk(datas_mutex_);
      auto& slot = datas_[topic];

      if (slot.message_type != std::type_index(typeid(void)) &&
          slot.message_type != tuple_type) {
        LOG_ERROR_NAMED(kBlackBoardLoggerName, "Pub error: type mismatch on topic '" << topic << "'");
        return false;
      }
      slot.message_type = tuple_type;

      if (pub_type == Save) {
        slot.saved_message = msg_ptr;
      } else if (!slot.saved_message) {
        // NoSave: keep first message only for type validation (compatible with legacy behavior)
        slot.saved_message = msg_ptr;
      }

      sync_handlers.reserve(slot.sync_subs.size());
      for (const auto& [_, handler] : slot.sync_subs) {
        sync_handlers.push_back(handler);
      }
      async_handlers.reserve(slot.async_subs.size());
      for (const auto& [_, handler] : slot.async_subs) {
        async_handlers.push_back(handler);
      }
    }

    for (auto& handler : async_handlers) {
      thread_pool_.Enqueue([handler = std::move(handler), topic, msg_ptr]() {
        handler(topic, msg_ptr);
      });
    }
    for (auto& handler : sync_handlers) {
      handler(topic, msg_ptr);
    }
    return true;
  }

  template <SubType sub_type, typename F>
  Handler Sub(const std::string& topic, F&& callback) {
    using ArgsTuple = typename detail::function_traits<std::decay_t<F>>::ArgsTuple;

    auto wrapped = [func = std::forward<F>(callback)](const std::string& topic,
                                                      std::shared_ptr<std::any> msg_ptr) {
      if (!msg_ptr) {
        return;
      }
      auto* tuple_ptr = std::any_cast<ArgsTuple>(msg_ptr.get());
      if (!tuple_ptr) {
        LOG_ERROR_NAMED(kBlackBoardLoggerName,
                        "Sub error: message type mismatch on topic '" << topic << "'");
        return;
      }
      std::apply(func, *tuple_ptr);
    };

    const uint64_t id = ++id_counter_;
    std::lock_guard<std::mutex> lk(datas_mutex_);
    auto& slot = datas_[topic];
    if (sub_type == Sync) {
      slot.sync_subs.emplace(id, std::move(wrapped));
    } else {
      slot.async_subs.emplace(id, std::move(wrapped));
    }
    return {topic, id};
  }

  template <SubType sub_type, typename ReturnType, typename... Args, typename ClassType>
  Handler Sub(const std::string& topic, ReturnType (ClassType::*mem_func)(Args...), ClassType* obj) {
    auto bound = [obj, mem_func](Args... args) -> ReturnType {
      return (obj->*mem_func)(std::forward<Args>(args)...);
    };
    return Sub<sub_type>(topic, std::move(bound));
  }

  template <SubType sub_type, typename ReturnType, typename... Args, typename ClassType>
  Handler Sub(const std::string& topic, ReturnType (ClassType::*mem_func)(Args...) const,
              ClassType* obj) {
    auto bound = [obj, mem_func](Args... args) -> ReturnType {
      return (obj->*mem_func)(std::forward<Args>(args)...);
    };
    return Sub<sub_type>(topic, std::move(bound));
  }

  bool UnSub(Handler handler) {
    std::lock_guard<std::mutex> lk(datas_mutex_);
    auto it = datas_.find(handler.name);
    if (it == datas_.end()) {
      return false;
    }
    const bool removed =
        it->second.sync_subs.erase(handler.id) > 0 || it->second.async_subs.erase(handler.id) > 0;
    return removed;
  }

  template <typename... Args>
  bool Set(const std::string& topic, Args&&... args) {
    using MessageTuple = std::tuple<std::decay_t<Args>...>;
    const std::type_index tuple_type(typeid(MessageTuple));

    std::lock_guard<std::mutex> lk(datas_mutex_);
    auto& slot = datas_[topic];
    if (slot.message_type != std::type_index(typeid(void)) &&
        slot.message_type != tuple_type) {
      LOG_ERROR_NAMED(kBlackBoardLoggerName, "Set error: type mismatch on topic '" << topic << "'");
      return false;
    }
    slot.message_type = tuple_type;
    slot.saved_message = std::make_shared<std::any>(MessageTuple(std::forward<Args>(args)...));
    return true;
  }

  template <typename... Args>
  bool Get(const std::string& topic, Args&... out) {
    using MessageTuple = std::tuple<std::decay_t<Args>...>;
    std::lock_guard<std::mutex> lk(datas_mutex_);
    auto it = datas_.find(topic);
    if (it == datas_.end() || !it->second.saved_message) {
      LOG_ERROR_NAMED(kBlackBoardLoggerName, "Get error: no saved message on topic '" << topic << "'");
      return false;
    }
    if (it->second.message_type != std::type_index(typeid(MessageTuple))) {
      LOG_ERROR_NAMED(kBlackBoardLoggerName, "Get error: type mismatch on topic '" << topic << "'");
      return false;
    }
    try {
      auto& stored = std::any_cast<MessageTuple&>(*it->second.saved_message);
      if (!detail::assign_tuple_to_refs(stored, out...)) {
        return false;
      }
      return true;
    } catch (const std::bad_any_cast&) {
      LOG_ERROR_NAMED(kBlackBoardLoggerName,
                      "Get error: bad_any_cast on topic '" << topic << "'");
      return false;
    }
  }

  template <typename... Args>
  std::optional<std::tuple<std::decay_t<Args>...>> GetTuple(const std::string& topic) {
    using MessageTuple = std::tuple<std::decay_t<Args>...>;
    std::lock_guard<std::mutex> lk(datas_mutex_);
    auto it = datas_.find(topic);
    if (it == datas_.end() || !it->second.saved_message) {
      LOG_ERROR_NAMED(kBlackBoardLoggerName,
                      "GetTuple error: no saved message on topic '" << topic << "'");
      return std::nullopt;
    }
    if (it->second.message_type != std::type_index(typeid(MessageTuple))) {
      LOG_ERROR_NAMED(kBlackBoardLoggerName,
                      "GetTuple error: type mismatch on topic '" << topic << "'");
      return std::nullopt;
    }
    try {
      return std::any_cast<MessageTuple>(*it->second.saved_message);
    } catch (const std::bad_any_cast&) {
      LOG_ERROR_NAMED(kBlackBoardLoggerName,
                      "GetTuple error: bad_any_cast on topic '" << topic << "'");
      return std::nullopt;
    }
  }

  template <typename T>
  std::optional<T> Get(const std::string& topic) {
    T value{};
    if (Get(topic, value)) {
      return value;
    }
    return std::nullopt;
  }

  // --- RPC ---

  template <typename F>
  Handler Register(const std::string& name, F&& f) {
    using Traits = detail::function_traits<std::decay_t<F>>;
    using R = typename Traits::R;
    using ArgsTuple = typename Traits::ArgsTuple;

    auto type_erased_func = [func = std::forward<F>(f)](std::any args_any) -> std::any {
      auto* tuple_ptr = std::any_cast<ArgsTuple>(&args_any);
      if (!tuple_ptr) {
        throw std::bad_any_cast();
      }
      if constexpr (std::is_void_v<R>) {
        std::apply(func, *tuple_ptr);
        return std::any{};
      } else {
        return std::any(std::apply(func, *tuple_ptr));
      }
    };

    std::lock_guard<std::mutex> lk(rpc_mutex_);
    rpc_func_[name] = std::move(type_erased_func);
    return {name, ++id_counter_};
  }

  template <typename R = void, typename... Args>
  auto Call(const std::string& name, Args&&... args) {
    std::any args_any = std::make_tuple(std::forward<Args>(args)...);
    std::function<std::any(std::any)> func;

    {
      std::lock_guard<std::mutex> lk(rpc_mutex_);
      auto it = rpc_func_.find(name);
      if (it == rpc_func_.end()) {
        LOG_ERROR_NAMED(kBlackBoardLoggerName,
                        "Call error: cannot find registered function for '" << name << "'");
        if constexpr (std::is_void_v<R>) return false;
        else return std::optional<R>{};
      }
      func = it->second;
    }

    try {
      std::any ret = func(std::move(args_any));
      if constexpr (std::is_void_v<R>) {
        return true;
      } else {
        return std::optional<R>{std::any_cast<R>(ret)};
      }
    } catch (const std::exception& e) {
      LOG_ERROR_NAMED(kBlackBoardLoggerName,
                      "Call error for '" << name << "': param/return type mismatch");
      if constexpr (std::is_void_v<R>) return false;
      else return std::optional<R>{};
    }
  }

  template <typename... Args>
  bool CallAsync(const std::string& name, Args&&... args) {
    std::any args_any = std::make_tuple(std::forward<Args>(args)...);
    std::function<std::any(std::any)> func;

    {
      std::lock_guard<std::mutex> lk(rpc_mutex_);
      auto it = rpc_func_.find(name);
      if (it == rpc_func_.end()) {
        LOG_ERROR_NAMED(kBlackBoardLoggerName,
                        "Async Call error: cannot find registered function for '" << name << "'");
        return false;
      }
      func = it->second;
    }

    thread_pool_.Enqueue([func = std::move(func), args_any = std::move(args_any), name]() mutable {
      try {
        func(std::move(args_any));
      } catch (const std::exception& e) {
        LOG_ERROR_NAMED(kBlackBoardLoggerName,
                        "Async Call error for '" << name << "': param type mismatch");
      }
    });
    return true;
  }

  void Clear() {
    {
      std::lock_guard<std::mutex> lk(datas_mutex_);
      datas_.clear();
    }
    {
      std::lock_guard<std::mutex> lk(rpc_mutex_);
      rpc_func_.clear();
    }
  }

 private:
  struct TopicSlot {
    std::shared_ptr<std::any> saved_message;
    std::type_index message_type{typeid(void)};
    std::map<uint64_t, std::function<void(const std::string&, std::shared_ptr<std::any>)>>
        sync_subs;
    std::map<uint64_t, std::function<void(const std::string&, std::shared_ptr<std::any>)>>
        async_subs;
  };

  BlackBoard() : thread_pool_(std::thread::hardware_concurrency()) {}
  ~BlackBoard() = default;

  std::mutex datas_mutex_;
  std::map<std::string, TopicSlot> datas_;

  std::mutex rpc_mutex_;
  std::map<std::string, std::function<std::any(std::any)>> rpc_func_;
  ThreadPool thread_pool_;
  std::atomic<uint64_t> id_counter_{0};
};

// --- Pub-Sub 全局便捷接口 ---

template <PubType pub_type = Save, typename... Args>
bool Pub(const std::string& topic, Args&&... args) {
  return BlackBoard::GetInstance().Pub<pub_type>(topic, std::forward<Args>(args)...);
}

template <SubType sub_type = Async, typename F>
Handler Sub(const std::string& topic, F&& callback) {
  return BlackBoard::GetInstance().Sub<sub_type>(topic, std::forward<F>(callback));
}

template <SubType sub_type = Async, typename ReturnType, typename... Args, typename ClassType>
Handler Sub(const std::string& topic, ReturnType (ClassType::*mem_func)(Args...), ClassType* obj) {
  return BlackBoard::GetInstance().Sub<sub_type>(topic, mem_func, obj);
}

template <SubType sub_type = Async, typename ReturnType, typename... Args, typename ClassType>
Handler Sub(const std::string& topic, ReturnType (ClassType::*mem_func)(Args...) const,
            ClassType* obj) {
  return BlackBoard::GetInstance().Sub<sub_type>(topic, mem_func, obj);
}

inline bool UnSub(Handler handler) {
  return BlackBoard::GetInstance().UnSub(handler);
}

template <typename... Args>
bool Set(const std::string& topic, Args&&... args) {
  return BlackBoard::GetInstance().Set(topic, std::forward<Args>(args)...);
}

template <typename... Args>
bool Get(const std::string& topic, Args&... out) {
  return BlackBoard::GetInstance().Get(topic, out...);
}

template <typename... Args>
std::optional<std::tuple<std::decay_t<Args>...>> GetTuple(const std::string& topic) {
  return BlackBoard::GetInstance().GetTuple<Args...>(topic);
}

template <typename T>
std::optional<T> Get(const std::string& topic) {
  return BlackBoard::GetInstance().Get<T>(topic);
}

// --- RPC 全局便捷接口 ---

template <typename R = void, typename... Args>
auto Call(const std::string& name, Args&&... args) {
  return BlackBoard::GetInstance().Call<R>(name, std::forward<Args>(args)...);
}

template <typename... Args>
bool CallAsync(const std::string& name, Args&&... args) {
  return BlackBoard::GetInstance().CallAsync(name, std::forward<Args>(args)...);
}

template <typename F>
Handler Register(const std::string& name, F&& func) {
  return BlackBoard::GetInstance().Register(name, std::forward<F>(func));
}

template <typename ReturnType, typename... Args, typename ClassType>
Handler Register(const std::string& name, ReturnType (ClassType::*mem_func)(Args...),
                 ClassType* obj) {
  auto bound_func = [obj, mem_func](Args... args) -> ReturnType {
    return (obj->*mem_func)(std::forward<Args>(args)...);
  };
  return BlackBoard::GetInstance().Register(name, std::move(bound_func));
}

inline void Clear() {
  BlackBoard::GetInstance().Clear();
}

}  // namespace bbd
}  // namespace robot_control