# com_msgConfig.cmake — CONFIG entry for find_package(com_msg CONFIG)
#
#   find_package(com_msg CONFIG REQUIRED)
#
# Install layout (prefix = directory above lib/):
#   <prefix>/lib/cmake/com_msg/com_msgConfig.cmake
#   <prefix>/lib/libcommunications.so
#   <prefix>/include/...
#   <prefix>/communication_idl/...   (optional)
#
# Sets: com_msg_FOUND, com_msg_INCLUDE_DIRS, com_msg_LIBRARIES, com_msg_ROOT, com_msg_IDL_DIR
# Target: com_msg::com_msg (also com_msg::communications when CMake >= 3.19)

if(NOT DEFINED com_msg_ROOT_DIR)
  get_filename_component(_com_msgModuleDir "${CMAKE_CURRENT_LIST_DIR}" ABSOLUTE)
  get_filename_component(_leaf "${_com_msgModuleDir}" NAME)
  get_filename_component(_parent "${_com_msgModuleDir}/.." ABSOLUTE)
  get_filename_component(_parentName "${_parent}" NAME)
  if(_leaf STREQUAL "com_msg")
    get_filename_component(com_msg_ROOT_DIR "${_com_msgModuleDir}/../../.." ABSOLUTE)
  elseif(_leaf STREQUAL "cmake" AND NOT _parentName STREQUAL "lib")
    get_filename_component(com_msg_ROOT_DIR "${_com_msgModuleDir}/.." ABSOLUTE)
  else()
    get_filename_component(com_msg_ROOT_DIR "${_com_msgModuleDir}/../.." ABSOLUTE)
  endif()
endif()

set(com_msg_ROOT "${com_msg_ROOT_DIR}")

# Headers live directly under prefix/include (do not depend on communication_idl for this).
if(IS_DIRECTORY "${com_msg_ROOT_DIR}/include")
  set(com_msg_INCLUDE_DIRS "${com_msg_ROOT_DIR}/include")
endif()

if(IS_DIRECTORY "${com_msg_ROOT_DIR}/communication_idl")
  set(com_msg_IDL_DIR "${com_msg_ROOT_DIR}/communication_idl")
endif()

find_package(usr_msg REQUIRED)

# NO_CMAKE_FIND_ROOT_PATH: when cross-compiling, still resolve against this install prefix
# (host paths), not only the sysroot.
find_library(com_msg_LIBRARY
  NAMES communications
  HINTS "${com_msg_ROOT_DIR}/lib"
  PATH_SUFFIXES ""
  NO_DEFAULT_PATH
  NO_CMAKE_FIND_ROOT_PATH
)

if(com_msg_LIBRARY)
  add_library(com_msg::communications SHARED IMPORTED)
  set_target_properties(com_msg::communications PROPERTIES
    IMPORTED_LOCATION "${com_msg_LIBRARY}"
    INTERFACE_INCLUDE_DIRECTORIES "${com_msg_INCLUDE_DIRS}"
    INTERFACE_LINK_LIBRARIES usr_msg::usr_msg
  )
  set(com_msg_LIBRARIES com_msg::communications)
else()
  set(com_msg_LIBRARIES "")
endif()

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(com_msg
  REQUIRED_VARS com_msg_LIBRARY com_msg_INCLUDE_DIRS
  VERSION_VAR com_msg_VERSION
)

mark_as_advanced(
  com_msg_ROOT
  com_msg_ROOT_DIR
  com_msg_INCLUDE_DIRS
  com_msg_LIBRARY
  com_msg_IDL_DIR
)
