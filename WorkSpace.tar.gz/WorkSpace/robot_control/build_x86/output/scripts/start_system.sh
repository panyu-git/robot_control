#!/bin/bash
# Start Robot Control System
# Usage: ./start_system.sh [--simulated] [--tick-rate N]

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

# Default values
SIMULATED=true
TICK_RATE=20

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --simulated)
            SIMULATED=true
            shift
            ;;
        --real)
            SIMULATED=false
            shift
            ;;
        --tick-rate)
            TICK_RATE="$2"
            shift 2
            ;;
        *)
            echo "Unknown option: $1"
            exit 1
            ;;
    esac
done

echo "Starting Robot Control System..."
echo "  Project Root: $PROJECT_ROOT"
echo "  Simulated: $SIMULATED"
echo "  Tick Rate: $TICK_RATE Hz"

# Set PYTHONPATH
export PYTHONPATH="$PROJECT_ROOT/src:$PYTHONPATH"

# Run the main application
cd "$PROJECT_ROOT"
python3 -c "
import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

from applications.interfaces import RobotController

controller = RobotController(simulated=$SIMULATED, tick_rate=$TICK_RATE)
controller.start()

print('Robot Control System started. Press Ctrl+C to stop.')

import time
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    print('\\nShutting down...')
    controller.shutdown()
    print('Shutdown complete.')
"
