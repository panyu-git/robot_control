#pragma once

#include <any>
#include <chrono>
#include <map>
#include <memory>
#include <nlohmann/json.hpp>
#include <optional>
#include <string>

#include "robot_control/core/blackboard.hpp"
#include "robot_control/core/enums.hpp"

namespace robot_control {
namespace applications {
namespace framework {

class Function {
   public:
    using json = nlohmann::json;

    Function(std::shared_ptr<core::Blackboard> blackboard);
    virtual ~Function() = default;

    // Pure virtual properties
    virtual core::FunctionType functionType() const = 0;
    virtual core::FunctionPriority priority() const = 0;

    // Virtual properties with defaults
    virtual core::PreemptionType preemptionType() const;

    // Properties
    core::FunctionStatus status() const {
        return _status;
    }
    const std::string& functionId() const {
        return function_id_;
    }
    const std::string& functionName() const {
        return function_name_;
    }
    /**
     * @brief Get scheduler priority used by FunctionScheduler preemption.
     *
     * If @ref setSchedulerPriority was not called (value is 0), this falls back to
     * FunctionPriority mapping: CRITICAL=300, NORMAL=200, LOW=100.
     */
    int schedulerPriority() const {
        if (scheduler_priority_ != 0) {
            return scheduler_priority_;
        }
        switch (priority()) {
            case core::FunctionPriority::CRITICAL:
                return 300;
            case core::FunctionPriority::NORMAL:
                return 200;
            case core::FunctionPriority::LOW:
                return 100;
            default:
                return 0;
        }
    }
    void setFunctionName(const std::string& function_name) {
        function_name_ = function_name;
    }
    void setSchedulerPriority(int priority) {
        scheduler_priority_ = priority;
    }
    void setStatus(core::FunctionStatus status) {
        _status = status;
    }
    void setFunctionId(const std::string& function_id) {
        function_id_ = function_id;
    }
    bool isRunning() const;
    bool isCompleted() const;

    // Lifecycle
    void enter(const std::optional<std::map<std::string, std::any>>& context = std::nullopt);
    virtual void onEnter(const std::optional<std::map<std::string, std::any>>& context) = 0;
    virtual std::optional<std::map<std::string, std::any>> onExit() = 0;
    virtual std::optional<std::map<std::string, std::any>> onPause();
    virtual void onResume(const std::map<std::string, std::any>& context);

    // Tick lifecycle
    virtual core::FunctionStatus preTick() {
        return _status;
    }
    virtual core::FunctionStatus postTick() = 0;

    // Methods
    bool canTransitionTo(Function& target) const;
    std::map<std::string, std::any> getInfo() const;
    /**
     * @brief Serialize function runtime metadata to JSON.
     */
    virtual json toJson() const;
    /**
     * @brief Restore function runtime metadata from JSON.
     *
     * Invalid or mismatched fields are ignored to avoid throwing into scheduler
     * control flow.
     */
    virtual void fromJson(const json& data);

   protected:
    core::FunctionStatus updateStatusFromEngine();
    static std::string _createPseudoUuid();

    std::shared_ptr<core::Blackboard> _blackboard;
    std::string function_id_;
    core::LocalBlackboardView _localBlackboard;
    core::FunctionStatus _status;
    std::string function_name_;
    int scheduler_priority_;
    std::chrono::steady_clock::time_point _sessionStartTime;
};

// FunctionType comparisons
inline bool operator==(const Function& lhs, core::FunctionType rhs) {
    return lhs.functionType() == rhs;
}

inline bool operator!=(const Function& lhs, core::FunctionType rhs) {
    return !(lhs == rhs);
}

inline bool operator==(core::FunctionType lhs, const Function& rhs) {
    return rhs == lhs;
}

inline bool operator!=(core::FunctionType lhs, const Function& rhs) {
    return rhs != lhs;
}

inline bool operator==(const Function* lhs, core::FunctionType rhs) {
    return lhs != nullptr && (*lhs == rhs);
}

inline bool operator!=(const Function* lhs, core::FunctionType rhs) {
    return !(lhs == rhs);
}

inline bool operator==(core::FunctionType lhs, const Function* rhs) {
    return rhs == lhs;
}

inline bool operator!=(core::FunctionType lhs, const Function* rhs) {
    return !(lhs == rhs);
}

// FunctionPriority comparisons
inline bool operator==(const Function& lhs, core::FunctionPriority rhs) {
    return lhs.priority() == rhs;
}

inline bool operator!=(const Function& lhs, core::FunctionPriority rhs) {
    return !(lhs == rhs);
}

inline bool operator==(core::FunctionPriority lhs, const Function& rhs) {
    return rhs == lhs;
}

inline bool operator!=(core::FunctionPriority lhs, const Function& rhs) {
    return rhs != lhs;
}

inline bool operator==(const Function* lhs, core::FunctionPriority rhs) {
    return lhs != nullptr && (*lhs == rhs);
}

inline bool operator!=(const Function* lhs, core::FunctionPriority rhs) {
    return !(lhs == rhs);
}

inline bool operator==(core::FunctionPriority lhs, const Function* rhs) {
    return rhs == lhs;
}

inline bool operator!=(core::FunctionPriority lhs, const Function* rhs) {
    return !(lhs == rhs);
}

// FunctionStatus comparisons
inline bool operator==(const Function& lhs, core::FunctionStatus rhs) {
    return lhs.status() == rhs;
}

inline bool operator!=(const Function& lhs, core::FunctionStatus rhs) {
    return !(lhs == rhs);
}

inline bool operator==(core::FunctionStatus lhs, const Function& rhs) {
    return rhs == lhs;
}

inline bool operator!=(core::FunctionStatus lhs, const Function& rhs) {
    return rhs != lhs;
}

inline bool operator==(const Function* lhs, core::FunctionStatus rhs) {
    return lhs != nullptr && (*lhs == rhs);
}

inline bool operator!=(const Function* lhs, core::FunctionStatus rhs) {
    return !(lhs == rhs);
}

inline bool operator==(core::FunctionStatus lhs, const Function* rhs) {
    return rhs == lhs;
}

inline bool operator!=(core::FunctionStatus lhs, const Function* rhs) {
    return !(lhs == rhs);
}

}  // namespace framework
}  // namespace applications
}  // namespace robot_control
