#include <cstdlib>
#include <rclcpp/rclcpp.hpp>

#include "robot_control/applications/interfaces/robot_controller_node.hpp"
#include "robot_control/common/logging.hpp"

int main(int argc, char* argv[]) {
    // Set ROS 2 console output format to remove the default raw timestamp,
    // as we provide a human-readable one in our logging macros.
    // This must be set before rclcpp::init.
    setenv("RCUTILS_CONSOLE_OUTPUT_FORMAT", "{message}", 1);

    rclcpp::init(argc, argv);

    auto node = std::make_shared<robot_control::applications::interfaces::RobotControllerNode>();

    node->init();

    LOG_INFO_NAMED(node->get_name(), "Robot Control Node started. Spinning...");

    // Use MultiThreadedExecutor so timer callbacks don't block service handling
    rclcpp::executors::MultiThreadedExecutor executor;
    executor.add_node(node);

    try {
        executor.spin();
    } catch (const std::exception& e) {
        LOG_ERROR_NAMED(node->get_name(), "Exception: " << e.what());
    }

    node->shutdown();
    rclcpp::shutdown();

    return 0;
}
