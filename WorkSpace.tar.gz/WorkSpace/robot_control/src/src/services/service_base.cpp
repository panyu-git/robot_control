#include "robot_control/services/service_base.hpp"

#include "robot_control/common/logging.hpp"

namespace robot_control {
namespace services {

ServiceBase::ServiceBase(const std::string& name, bool simulated)
    : _name(name), _simulated(simulated), _status(ServiceStatus::UNINITIALIZED), _logger_name(name) {}

bool ServiceBase::initialize() {
    try {
        LOG_INFO("Initializing " << _name << "...");
        bool success = _doInitialize();
        if (success) {
            _status = ServiceStatus::READY;
            _errorMsg = std::nullopt;
            LOG_INFO(_name << " initialized successfully");
        } else {
            _status = ServiceStatus::ERROR;
            LOG_ERROR(_name << " initialization failed");
        }
        return success;
    } catch (const std::exception& e) {
        _status = ServiceStatus::ERROR;
        _errorMsg = std::string(e.what());
        LOG_ERROR("Error initializing " << _name << ": " << e.what());
        return false;
    }
}

void ServiceBase::shutdown() {
    try {
        LOG_INFO("Shutting down " << _name << "...");
        _doShutdown();
        _status = ServiceStatus::STOPPED;
        LOG_INFO(_name << " shut down");
    } catch (const std::exception& e) {
        LOG_ERROR("Error shutting down " << _name << ": " << e.what());
    }
}

bool ServiceBase::reset() {
    shutdown();
    return initialize();
}

std::map<std::string, std::string> ServiceBase::getStatusInfo() const {
    std::map<std::string, std::string> info;
    info["name"] = _name;
    info["status"] = toString(_status);
    info["simulated"] = _simulated ? "true" : "false";
    if (_errorMsg.has_value()) {
        info["error"] = _errorMsg.value();
    } else {
        info["error"] = "";
    }
    return info;
}

}  // namespace services
}  // namespace robot_control
