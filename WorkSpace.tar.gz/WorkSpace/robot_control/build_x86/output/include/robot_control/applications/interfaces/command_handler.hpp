#pragma once

#include <functional>
#include <map>
#include <memory>
#include <optional>
#include <set>
#include <string>
#include <vector>

#include "robot_control/core/blackboard.hpp"
#include "robot_control/core/events.hpp"

namespace robot_control {
namespace applications {
namespace interfaces {

class CommandHandler {
   public:
    static const std::set<std::string> VALID_INTENTS;

    CommandHandler(std::shared_ptr<core::Blackboard> blackboard, core::EventBus* event_bus = nullptr);

    void registerCallback(const std::string& command, std::function<bool()> callback);

    bool processCommand(const std::string& command, const std::map<std::string, std::string>& params = {});

    std::optional<core::EventV> convertCommand(const std::string& command,
                                               const std::map<std::string, std::string>& params = {}) const;

    std::vector<std::string> getAvailableCommands() const;

   private:
    bool _handleWakeupCommand(const std::map<std::string, std::string>& params);
    bool _handleFollowCommand(const std::map<std::string, std::string>& params);
    bool _handleStopFollowCommand(const std::map<std::string, std::string>& params);
    bool _handleFollowSpeedUpCommand(const std::map<std::string, std::string>& params);
    bool _handleFollowSpeedDownCommand(const std::map<std::string, std::string>& params);
    bool _handleFollowDistanceNearCommand(const std::map<std::string, std::string>& params);
    bool _handleFollowDistanceFarCommand(const std::map<std::string, std::string>& params);
    bool _handleFollowLocationCommand(const std::map<std::string, std::string>& params);
    bool _handleStopCommand(const std::map<std::string, std::string>& params);

    std::string toLower(const std::string& str) const;

    std::shared_ptr<core::Blackboard> _blackboard;
    core::EventBus* _eventBus;
    std::map<std::string, std::function<bool()>> _commandCallbacks;
};

}  // namespace interfaces
}  // namespace applications
}  // namespace robot_control
