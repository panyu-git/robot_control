#include "robot_control/applications/functions/mountup_function.hpp"

#include <gtest/gtest.h>

#include <filesystem>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "robot_control/applications/interfaces/robot_context.hpp"
#include "robot_control/common/blackboard/black_board.hpp"
#include "robot_control/core/enums.hpp"
#include "robot_control/core/events.hpp"
#include "robot_control/core/robot_control_configs.hpp"

#ifndef MOUNTUP_TREE_XML_PATH
#define MOUNTUP_TREE_XML_PATH "etc/bt_trees/mountup_tree.xml"
#endif

namespace robot_control::applications::functions::test {

namespace {

std::string resolveMountupTreePath() {
    const std::filesystem::path configured(MOUNTUP_TREE_XML_PATH);
    if (std::filesystem::exists(configured)) {
        return configured.string();
    }
    const std::filesystem::path relative("etc/bt_trees/mountup_tree.xml");
    if (std::filesystem::exists(relative)) {
        return std::filesystem::absolute(relative).string();
    }
    return configured.string();
}

struct CapturedBtFunctionState {
    std::string user_id;
    core::FunctionType func_type{};
    core::MountupStage stage{};
    core::FunctionStatus status{};
    uint16_t error_code{0};
};

class BtFunctionStateRecorder {
   public:
    void clear() {
        std::lock_guard<std::mutex> lock(mutex_);
        records_.clear();
    }

    const std::vector<CapturedBtFunctionState>& records() const {
        return records_;
    }

    bbd::Handler subscribe() {
        return bbd::Sub<bbd::Sync>(
            core::BlackboardKeys::BT_PUB_FUNCTION_STATE,
            [this](const std::string& user_id, const core::FunctionType& func_type,
                   const core::MountupStage& stage, const core::FunctionStatus& status,
                   const uint16_t& error_code) {
                std::lock_guard<std::mutex> lock(mutex_);
                records_.push_back(CapturedBtFunctionState{user_id, func_type, stage, status, error_code});
            });
    }

   private:
    mutable std::mutex mutex_;
    std::vector<CapturedBtFunctionState> records_;
};

const CapturedBtFunctionState* findLastMatching(
    const std::vector<CapturedBtFunctionState>& records, core::FunctionType func_type) {
    for (auto it = records.rbegin(); it != records.rend(); ++it) {
        if (it->func_type == func_type) {
            return &(*it);
        }
    }
    return nullptr;
}

bool containsStage(const std::vector<CapturedBtFunctionState>& records, core::MountupStage stage) {
    for (const auto& record : records) {
        if (record.func_type == core::FunctionType::MOUNT_UP && record.stage == stage) {
            return true;
        }
    }
    return false;
}

size_t countStage(const std::vector<CapturedBtFunctionState>& records, core::MountupStage stage) {
    size_t count = 0;
    for (const auto& record : records) {
        if (record.func_type == core::FunctionType::MOUNT_UP && record.stage == stage) {
            ++count;
        }
    }
    return count;
}

void expectMountUpPublish(const CapturedBtFunctionState& record, const std::string& user_id,
                          core::MountupStage stage, core::FunctionStatus status, uint16_t error_code = 0) {
    EXPECT_EQ(record.func_type, core::FunctionType::MOUNT_UP);
    EXPECT_EQ(record.user_id, user_id);
    EXPECT_EQ(record.stage, stage);
    EXPECT_EQ(record.status, status);
    EXPECT_EQ(record.error_code, error_code);
}

}  // namespace

class MountUpFunctionTest : public ::testing::Test {
   protected:
    void SetUp() override {
        bbd::Clear();
        state_recorder_ = std::make_unique<BtFunctionStateRecorder>();
        state_sub_ = state_recorder_->subscribe();

        tree_path_ = resolveMountupTreePath();
        ASSERT_TRUE(std::filesystem::exists(tree_path_))
            << "mountup_tree.xml not found at " << tree_path_;
        context_ = std::make_unique<interfaces::RobotContext>(nullptr, nullptr);
        function_ = std::make_unique<MountUpFunction>(tree_path_, *context_);
    }

    void TearDown() override {
        function_.reset();
        context_.reset();
        if (state_sub_.name[0] != '\0') {
            bbd::UnSub(state_sub_);
        }
        state_recorder_.reset();
        bbd::Clear();
    }

    void startMountUp() {
        function_->postEvent(core::EvStart{});
    }

    const std::vector<CapturedBtFunctionState>& publishedStates() const {
        return state_recorder_->records();
    }

    std::string tree_path_;
    std::unique_ptr<interfaces::RobotContext> context_;
    std::unique_ptr<MountUpFunction> function_;
    std::unique_ptr<BtFunctionStateRecorder> state_recorder_;
    bbd::Handler state_sub_{};
};

TEST_F(MountUpFunctionTest, MetadataMatchesExpectedInterface) {
    EXPECT_EQ(function_->functionType(), core::FunctionType::MOUNT_UP);
    EXPECT_EQ(function_->priority(), core::FunctionPriority::NORMAL);
    EXPECT_EQ(function_->preemptionType(), core::PreemptionType::NONE);
}

TEST_F(MountUpFunctionTest, DefaultBbUserIdIsZeroString) {
    EXPECT_EQ(function_->bb_user_id(), "0");
    EXPECT_FALSE(function_->is_started());
}

TEST_F(MountUpFunctionTest, EvUserIdChangedUpdatesBbUserId) {
    function_->postEvent(core::EvUserIdChanged{"alice"});
    EXPECT_EQ(function_->bb_user_id(), "alice");

    function_->postEvent(core::EvUserIdChanged{"bob"});
    EXPECT_EQ(function_->bb_user_id(), "bob");
}

TEST_F(MountUpFunctionTest, EvStartMarksStartedAndEvStopClears) {
    EXPECT_FALSE(function_->is_started());

    startMountUp();
    EXPECT_TRUE(function_->is_started());

    function_->postEvent(core::EvStop{});
    EXPECT_FALSE(function_->is_started());
}

TEST_F(MountUpFunctionTest, DuplicateEvStartIsIgnored) {
    startMountUp();
    ASSERT_TRUE(function_->is_started());

    startMountUp();
    EXPECT_TRUE(function_->is_started());
}

TEST_F(MountUpFunctionTest, EvStopWhenNotStartedIsNoOp) {
    function_->postEvent(core::EvStop{});
    EXPECT_FALSE(function_->is_started());
}

TEST_F(MountUpFunctionTest, EvCompleteClearsStartedFlag) {
    startMountUp();
    ASSERT_TRUE(function_->is_started());

    function_->postEvent(core::EvComplete{});
    EXPECT_FALSE(function_->is_started());
}

TEST_F(MountUpFunctionTest, PhaseDoneEventsRequireStartedSession) {
    function_->postEvent(core::EvMountUpContactDone{});
    function_->postEvent(core::EvMountUpClimbDone{});
    EXPECT_FALSE(function_->is_started());

    startMountUp();
    function_->postEvent(core::EvMountUpContactDone{});
    function_->postEvent(core::EvMountUpClimbDone{});
    EXPECT_TRUE(function_->is_started());
}

TEST_F(MountUpFunctionTest, EvErrorDoesNotClearStartedFlag) {
    startMountUp();
    ASSERT_TRUE(function_->is_started());

    function_->postEvent(core::EvError{42});
    EXPECT_TRUE(function_->is_started());
}

TEST_F(MountUpFunctionTest, EvErrorIgnoredWhenNotStarted) {
    function_->postEvent(core::EvError{7});
    EXPECT_FALSE(function_->is_started());
}

TEST_F(MountUpFunctionTest, OnEnterSetsRunningStatus) {
    function_->onEnter(std::nullopt);
    EXPECT_EQ(function_->status(), core::FunctionStatus::RUNNING);
}

TEST_F(MountUpFunctionTest, OnExitStopsTreeAndClearsStarted) {
    startMountUp();
    ASSERT_TRUE(function_->is_started());

    function_->onExit();
    EXPECT_FALSE(function_->is_started());
}

TEST_F(MountUpFunctionTest, OnResumeRestartsAndSetsRunning) {
    function_->onResume({});
    EXPECT_TRUE(function_->is_started());
    EXPECT_EQ(function_->status(), core::FunctionStatus::RUNNING);
}

TEST_F(MountUpFunctionTest, TickOnceReturnsIdleBeforeStart) {
    EXPECT_EQ(function_->tickOnce(), core::FunctionStatus::IDLE);
    EXPECT_EQ(function_->preTick(), core::FunctionStatus::IDLE);
    EXPECT_EQ(function_->status(), core::FunctionStatus::IDLE);
    EXPECT_TRUE(publishedStates().empty());
}

TEST_F(MountUpFunctionTest, HaltTreeClearsStartedFlag) {
    startMountUp();
    ASSERT_TRUE(function_->is_started());

    function_->haltTree();
    EXPECT_FALSE(function_->is_started());
}

TEST_F(MountUpFunctionTest, StartUsesLatestUserIdOnBlackboard) {
    function_->postEvent(core::EvUserIdChanged{"user-99"});
    startMountUp();
    EXPECT_EQ(function_->bb_user_id(), "user-99");
    EXPECT_TRUE(function_->is_started());
}

TEST_F(MountUpFunctionTest, PostTickReflectsCurrentStatus) {
    function_->onEnter(std::nullopt);
    EXPECT_EQ(function_->postTick(), core::FunctionStatus::RUNNING);
}

TEST_F(MountUpFunctionTest, FirstTickPublishesContactThenWaitsContactStatus) {
    startMountUp();

    const auto tick_status = function_->tickOnce();
    EXPECT_EQ(tick_status, core::FunctionStatus::RUNNING);

    ASSERT_EQ(publishedStates().size(), 1U);
    expectMountUpPublish(publishedStates().front(), "0", core::MountupStage::CONTACT,
                         core::FunctionStatus::RUNNING);
}

TEST_F(MountUpFunctionTest, PreTickUpdatesStatusAndPublishesContact) {
    startMountUp();
    state_recorder_->clear();

    const auto tick_status = function_->preTick();
    EXPECT_EQ(tick_status, core::FunctionStatus::RUNNING);
    EXPECT_EQ(function_->status(), core::FunctionStatus::RUNNING);

    ASSERT_EQ(publishedStates().size(), 1U);
    expectMountUpPublish(publishedStates().front(), "0", core::MountupStage::CONTACT,
                         core::FunctionStatus::RUNNING);
}

TEST_F(MountUpFunctionTest, TickOncePublishesConfiguredUserId) {
    function_->postEvent(core::EvUserIdChanged{"mount-user"});
    startMountUp();
    state_recorder_->clear();

    function_->tickOnce();

    const auto* last = findLastMatching(publishedStates(), core::FunctionType::MOUNT_UP);
    ASSERT_NE(last, nullptr);
    EXPECT_EQ(last->user_id, "mount-user");
}

TEST_F(MountUpFunctionTest, TickOnceAfterStopReturnsIdleWithoutPublish) {
    startMountUp();
    function_->tickOnce();
    state_recorder_->clear();

    function_->postEvent(core::EvStop{});
    const auto tick_status = function_->tickOnce();

    EXPECT_EQ(tick_status, core::FunctionStatus::IDLE);
    EXPECT_TRUE(publishedStates().empty());
}

TEST_F(MountUpFunctionTest, MultipleTicksWhileContactPendingStayRunning) {
    startMountUp();

    EXPECT_EQ(function_->tickOnce(), core::FunctionStatus::RUNNING);
    EXPECT_EQ(function_->tickOnce(), core::FunctionStatus::RUNNING);

    EXPECT_EQ(publishedStates().size(), 1U);
    EXPECT_EQ(countStage(publishedStates(), core::MountupStage::CONTACT), 1U);
}

TEST_F(MountUpFunctionTest, TickOnceAfterContactDonePublishesClimbing) {
    startMountUp();
    ASSERT_EQ(function_->tickOnce(), core::FunctionStatus::RUNNING);
    state_recorder_->clear();

    function_->postEvent(core::EvMountUpContactDone{});
    EXPECT_EQ(function_->tickOnce(), core::FunctionStatus::RUNNING);

    ASSERT_GE(publishedStates().size(), 1U);
    EXPECT_TRUE(containsStage(publishedStates(), core::MountupStage::CLIMBING));
    const auto* last = findLastMatching(publishedStates(), core::FunctionType::MOUNT_UP);
    ASSERT_NE(last, nullptr);
    expectMountUpPublish(*last, "0", core::MountupStage::CLIMBING, core::FunctionStatus::RUNNING);
}

TEST_F(MountUpFunctionTest, TickOnceAfterClimbDonePublishesDocking) {
    startMountUp();
    function_->tickOnce();
    function_->postEvent(core::EvMountUpContactDone{});
    function_->tickOnce();
    state_recorder_->clear();

    function_->postEvent(core::EvMountUpClimbDone{});
    for (int i = 0; i < 16; ++i) {
        function_->tickOnce();
        if (containsStage(publishedStates(), core::MountupStage::DOCKING)) {
            break;
        }
    }

    ASSERT_GE(publishedStates().size(), 1U);
    EXPECT_TRUE(containsStage(publishedStates(), core::MountupStage::DOCKING));
}

TEST_F(MountUpFunctionTest, BbdSubReceivesPhaseProgression) {
    startMountUp();
    function_->tickOnce();
    function_->postEvent(core::EvMountUpContactDone{});
    function_->tickOnce();
    function_->postEvent(core::EvMountUpClimbDone{});

    while (function_->tickOnce() == core::FunctionStatus::RUNNING) {
        if (containsStage(publishedStates(), core::MountupStage::DOCKING)) {
            break;
        }
    }

    EXPECT_TRUE(containsStage(publishedStates(), core::MountupStage::CONTACT));
    EXPECT_TRUE(containsStage(publishedStates(), core::MountupStage::CLIMBING));
    EXPECT_TRUE(containsStage(publishedStates(), core::MountupStage::DOCKING));
}

TEST_F(MountUpFunctionTest, TickOnceAfterErrorReturnsFailed) {
    startMountUp();
    function_->tickOnce();
    function_->postEvent(core::EvError{42});

    const auto tick_status = function_->tickOnce();
    EXPECT_EQ(tick_status, core::FunctionStatus::FAILED);
    EXPECT_TRUE(function_->is_started());
}

}  // namespace robot_control::applications::functions::test
