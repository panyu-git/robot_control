#include "robot_control/applications/interfaces/robot_controller.hpp"

#include <array>
#include <chrono>
#include <cmath>
#include <iostream>
#include <thread>

#include "robot_control/applications/framework/bt_node_registry.hpp"
#include "robot_control/applications/framework/function_registry.hpp"
#include "robot_control/applications/functions/follow_function.hpp"
#include "robot_control/applications/functions/idle_function.hpp"
#include "robot_control/applications/functions/wakeup_function.hpp"
#include "robot_control/core/enums.hpp"
#include "robot_control/core/robot_control_configs.hpp"

namespace robot_control {
namespace applications {
namespace interfaces {

namespace {

void recordFollowDispatchParams(const std::shared_ptr<core::Blackboard>& blackboard) {
    double follow_speed = blackboard->get<double>(core::BlackboardKeys::TASK_FOLLOW_SPEED, 1.0);
    double follow_distance = blackboard->get<double>(core::BlackboardKeys::TASK_FOLLOW_DISTANCE, 1.0);
    std::string follow_mode = blackboard->get<std::string>(core::BlackboardKeys::TASK_FOLLOW_MODE, "human");

    int dir = 0;
    if (follow_mode == "left") {
        dir = 1;
    } else if (follow_mode == "right") {
        dir = 2;
    }
    blackboard->set("follow_last_dispatched_task_name", std::string("FOLLOW_TASK"));
    blackboard->set("follow_last_dispatched_request_start", std::string("true"));
    blackboard->set("follow_last_dispatched_param_speed_ms", follow_speed);
    blackboard->set("follow_last_dispatched_param_follow_dis_m", follow_distance);
    blackboard->set("follow_last_dispatched_param_follow_dir", dir);
}

void setFollowPhase(const std::shared_ptr<core::Blackboard>& blackboard, core::FollowPhase phase) {
    blackboard->set("follow_phase", phase);
}

}  // namespace

RobotController::RobotController(bool simulated, std::optional<double> tick_rate)
    : _running(false),
      _controlThread(nullptr),
      _tickRate(tick_rate.value_or(DEFAULT_TICK_RATE)),
      _tickInterval(1.0 / _tickRate),
      _simulated(simulated) {
    // Initialize core components early to allow access before init()
    blackboard = std::make_shared<core::Blackboard>();
    event_bus = &core::EventBus::getInstance();
}

void RobotController::init(rclcpp::Node::SharedPtr node) {
    _initComponents(node);
}

RobotController::~RobotController() {
    shutdown();
}

void RobotController::_initComponents(rclcpp::Node::SharedPtr node) {
    // Core components are initialized in constructor

    // Services
    navigation = std::make_shared<services::NavigationService>(_simulated);
    navigation->init(node);

    perception = std::make_shared<services::PerceptionService>(_simulated);
    perception->init(node);

    // Context (Composition)
    robot_context = std::make_unique<interfaces::RobotContext>(navigation.get(), perception.get());

    // Managers
    task_manager = std::make_shared<framework::TaskManager>(blackboard);
    function_manager = std::make_shared<framework::FunctionManager>(blackboard, task_manager.get(), event_bus);

    // Command handler
    command_handler = std::make_shared<CommandHandler>(blackboard, event_bus);

    // Register functions
    _registerFunctions();

    // Declarative Resource Registry
    auto& registry = framework::FunctionRegistry::getInstance();
    registry.add({core::FunctionType::FOLLOW, framework::EngineType::BEHAVIOR_TREE, core::BTConfig::kTreeNameFollow,
                  core::BTConfig::xmlPathFollow(), true});
    registry.add({core::FunctionType::WAKEUP, framework::EngineType::BEHAVIOR_TREE, core::BTConfig::kTreeNameWakeup,
                  core::BTConfig::xmlPathWakeup(), true});

    // Global BT node registration
    framework::BTNodeRegistry::registerAllNodes(task_manager->factory(), blackboard);

    // Warm-up resources (Optimization 4)
    function_manager->warmup();

    // Follow defaults: use medium gear for speed/distance.
    blackboard->set(core::BlackboardKeys::TASK_FOLLOW_SPEED,
                    core::FollowConfigs::kSpeedLevels[core::FollowConfigs::kDefaultLevelIndex]);
    blackboard->set(core::BlackboardKeys::TASK_FOLLOW_DISTANCE,
                    core::FollowConfigs::kDistanceLevels[core::FollowConfigs::kDefaultLevelIndex]);
    blackboard->set("follow_speed_level_index", core::FollowConfigs::kDefaultLevelIndex);
    blackboard->set("follow_distance_level_index", core::FollowConfigs::kDefaultLevelIndex);
    setFollowPhase(blackboard, core::FollowPhase::IDLE);
    recordFollowDispatchParams(blackboard);

    // Reserve planner-related keys for future complex-instruction integration
    blackboard->set("planner_status", std::string("reserved"));
    blackboard->set("planner_last_step", std::string(""));
    core::Event planner_event(core::EventType::PLANNER_RESERVED, "RobotController");
    event_bus->publish(planner_event);

    // Start in IDLE
    function_manager->transitionTo(core::FunctionType::IDLE);
}

void RobotController::_registerFunctions() {
    function_manager->registerFunction(std::make_unique<functions::IdleFunction>(blackboard));
    function_manager->registerFunction(std::make_unique<functions::WakeupFunction>(blackboard, *robot_context));
    function_manager->registerFunction(std::make_unique<functions::FollowFunction>(blackboard, *robot_context));
}

void RobotController::start() {
    if (_running) {
        return;
    }

    _running = true;
    _controlThread = std::make_unique<std::thread>(&RobotController::_controlLoop, this);
}

void RobotController::shutdown() {
    if (!_running) return;

    LOG_INFO("Shutdown requested...");
    _running = false;

    if (_controlThread && _controlThread->joinable()) {
        LOG_INFO("Joining control thread...");
        _controlThread->join();
        LOG_INFO("Control thread joined");
    }
    _controlThread.reset();

    // Shutdown services after control thread has exited
    LOG_INFO("Shutting down services...");
    if (navigation) navigation->shutdown();
    if (perception) perception->shutdown();

    LOG_INFO("Services shut down");
    LOG_INFO("Shutdown complete");
}

bool RobotController::command(const std::string& cmd, const std::map<std::string, std::string>& params) {
    // Voice-command JSON path is disabled in this version.
    // Keep command dispatch explicit through HMI intent + params only.
    return command_handler->processCommand(cmd, params);
}

void RobotController::_controlLoop() {
    LOG_INFO("Control loop started (tick_rate=" << _tickRate << " Hz)");
    while (_running) {
        auto start_time = std::chrono::steady_clock::now();

        try {
            // Execute function manager tick
            function_manager->tick();
        } catch (const std::exception& e) {
            LOG_ERROR("Control loop error: " << e.what());
        }

        // Maintain tick rate
        auto elapsed = std::chrono::steady_clock::now() - start_time;
        auto sleep_time = _tickInterval - std::chrono::duration<double>(elapsed).count();
        if (sleep_time > 0) {
            std::this_thread::sleep_for(std::chrono::duration<double>(sleep_time));
        }
    }
    LOG_INFO("Control loop exited");
}

}  // namespace interfaces
}  // namespace applications
}  // namespace robot_control
