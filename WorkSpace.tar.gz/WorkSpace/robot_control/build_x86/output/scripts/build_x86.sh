#!/bin/bash

set -e

# 获取脚本所在目录的绝对路径
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# create.sh 位于 src/robot_control/ 目录下，即当前脚本的上两级目录
CREATE_SH="${SCRIPT_DIR}/../../create.sh"

if [ ! -f "$CREATE_SH" ]; then
    echo "Error: create.sh not found at $CREATE_SH"
    exit 1
fi

echo "Delegating build to create.sh x86..."
# 调用 create.sh 并传递所有参数（如 -r）
bash "$CREATE_SH" x86 "$@"
