#pragma once

#include "behaviortree_cpp/basic_types.h"
#include "behaviortree_cpp/exceptions.h"
#include "behaviortree_cpp/contrib/magic_enum.hpp"

#include "robot_control/core/enums.hpp"
#include "robot_control/core/events.hpp"

#include <cctype>
#include <string>

namespace BT {
namespace {

inline StringView trim_enum_token(StringView s) {
    while (!s.empty() && std::isspace(static_cast<unsigned char>(s.front()))) {
        s.remove_prefix(1);
    }
    while (!s.empty() && std::isspace(static_cast<unsigned char>(s.back()))) {
        s.remove_suffix(1);
    }
    return s;
}

}  // namespace

template <>
[[nodiscard]] inline robot_control::core::EventType convertFromString<robot_control::core::EventType>(StringView str) {
    str = trim_enum_token(str);
    if (const auto parsed =
            magic_enum::enum_cast<robot_control::core::EventType>(str, magic_enum::case_insensitive)) {
        return *parsed;
    }
    throw RuntimeError(std::string("Cannot convert this to EventType: ") + std::string(str));
}

template <>
[[nodiscard]] inline robot_control::core::FunctionStatus convertFromString<robot_control::core::FunctionStatus>(
    StringView str) {
    str = trim_enum_token(str);
    if (const auto parsed =
            magic_enum::enum_cast<robot_control::core::FunctionStatus>(str, magic_enum::case_insensitive)) {
        return *parsed;
    }
    throw RuntimeError(std::string("Cannot convert this to FunctionStatus: ") + std::string(str));
}

template <>
[[nodiscard]] inline robot_control::core::FunctionType convertFromString<robot_control::core::FunctionType>(
    StringView str) {
    str = trim_enum_token(str);
    if (const auto parsed =
            magic_enum::enum_cast<robot_control::core::FunctionType>(str, magic_enum::case_insensitive)) {
        return *parsed;
    }
    throw RuntimeError(std::string("Cannot convert this to FunctionType: ") + std::string(str));
}

template <>
[[nodiscard]] inline robot_control::core::MainMode convertFromString<robot_control::core::MainMode>(StringView str) {
    str = trim_enum_token(str);
    if (const auto parsed = magic_enum::enum_cast<robot_control::core::MainMode>(str, magic_enum::case_insensitive)) {
        return *parsed;
    }
    throw RuntimeError(std::string("Cannot convert this to MainMode: ") + std::string(str));
}

template <>
[[nodiscard]] inline robot_control::core::SubMode convertFromString<robot_control::core::SubMode>(StringView str) {
    str = trim_enum_token(str);
    if (const auto parsed = magic_enum::enum_cast<robot_control::core::SubMode>(str, magic_enum::case_insensitive)) {
        return *parsed;
    }
    throw RuntimeError(std::string("Cannot convert this to SubMode: ") + std::string(str));
}

template <>
[[nodiscard]] inline robot_control::core::MountupStage convertFromString<robot_control::core::MountupStage>(StringView str) {
    str = trim_enum_token(str);
    if (const auto parsed = magic_enum::enum_cast<robot_control::core::MountupStage>(str, magic_enum::case_insensitive)) {
        return *parsed;
    }
    throw RuntimeError(std::string("Cannot convert this to MountupStage: ") + std::string(str));
}
}  // namespace BT
