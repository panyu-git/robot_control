#include "robot_control/services/perception_service.hpp"

#include <atomic>
#include <chrono>
#include <rclcpp_action/exceptions.hpp>

#include "robot_control/utils/logic_utils.hpp"

namespace robot_control {
namespace services {

PerceptionService::PerceptionService(bool simulated)
    : ServiceBase("PerceptionService", simulated),
      _face_authenticated(false),
      _last_perception_feedback_time(0.0),
      _last_tracking_server_warn_time(0.0),
      _follow_auth_session_id(0) {}

PerceptionService::~PerceptionService() {
    _doShutdown();
}

void PerceptionService::init(rclcpp::Node::SharedPtr node) {
    _node = node;
    if (_node) {
        _perception_client =
            rclcpp_action::create_client<perception_interfaces::action::TargetTracking>(_node, "target_tracking");
        LOG_INFO("[PERCEPTION] ROS2 Action Client initialized for target_tracking");
    }
    initialize();
}

bool PerceptionService::_doInitialize() {
    LOG_INFO("[PERCEPTION] Initializing perception interfaces...");
    if (!_perception_client) {
        LOG_ERROR("[PERCEPTION] target_tracking client is null");
        return false;
    }
    if (!_perception_client->wait_for_action_server(std::chrono::seconds(2))) {
        LOG_WARN("[PERCEPTION] /target_tracking server not available yet");
    } else {
        LOG_INFO("[PERCEPTION] /target_tracking server connected");
    }
    return true;
}

void PerceptionService::_doShutdown() {
    stopTracking();  // async_cancel_all_goals + clearTarget + reset feedback time
    _perception_client.reset();
}

bool PerceptionService::startActivationTracking(const std::string& user_id) {
    if (_status != ServiceStatus::READY) {
        LOG_ERROR("[PERCEPTION] Service not ready");
        return false;
    }
    if (!_perception_client) {
        LOG_ERROR("[PERCEPTION] Tracking client is null");
        return false;
    }
    if (!_perception_client->wait_for_action_server(std::chrono::seconds(2))) {
        auto now = std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
        if (now - _last_tracking_server_warn_time >= 2.0) {
            LOG_WARN("[PERCEPTION] server is not ready for activation (timeout=2s)");
            _last_tracking_server_warn_time = now;
        }
        return false;
    }

    // Face auth is intentionally bypassed:
    // - still call perception action server to start tracking
    // - always send empty face_id
    // - do not use feedback/result for authentication decision
    std::string expected_face_id = "";

    perception_interfaces::action::TargetTracking::Goal goal;
    goal.face_id = "";

    auto send_goal_options = rclcpp_action::Client<perception_interfaces::action::TargetTracking>::SendGoalOptions();
    auto activation_matched = std::make_shared<std::atomic_bool>(false);
    auto last_feedback_log_time = std::make_shared<double>(0.0);
    auto last_feedback_face_id = std::make_shared<std::string>("");
    auto last_feedback_match_state = std::make_shared<bool>(false);
    auto has_logged_feedback = std::make_shared<bool>(false);

    send_goal_options.goal_response_callback =
        [this](const rclcpp_action::ClientGoalHandle<perception_interfaces::action::TargetTracking>::SharedPtr&
                   goal_handle) {
            if (!goal_handle) {
                LOG_ERROR("[PERCEPTION] Activation tracking goal was rejected by server");
                return;
            }
            {
                std::lock_guard<std::mutex> lock(_mutex);
                _active_tracking_goal_handle = goal_handle;
            }
            LOG_INFO("[PERCEPTION] Activation tracking goal accepted");
        };

    send_goal_options.feedback_callback =
        [this, expected_face_id, user_id, last_feedback_log_time, last_feedback_face_id, last_feedback_match_state,
         has_logged_feedback, activation_matched](
            rclcpp_action::ClientGoalHandle<perception_interfaces::action::TargetTracking>::SharedPtr,
            const std::shared_ptr<const perception_interfaces::action::TargetTracking::Feedback> feedback) {
            if (activation_matched->load()) {
                return;
            }
            std::lock_guard<std::mutex> lock(_mutex);
            auto now = std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
            _last_perception_feedback_time = now;

            const std::string current_face_id = feedback->face_id;
            const bool got_face_id = !current_face_id.empty();
            const bool id_match = true;  // bypass: always pass
            const bool face_ok = feedback->face_valid && (feedback->face_match_score > 0.8f);

            TargetInfo target;
            target.position = std::make_tuple(0.0, 0.0, 0.0);
            target.confidence = got_face_id ? 1.0 : 0.0;
            target.velocity = std::make_tuple(0.0, 0.0);
            target.last_seen = now;
            // Ensure downstream sees empty face_id as requested.
            target.user_id = "";
            _target = target;

            _face_authenticated = true;
            activation_matched->store(true);
            LOG_INFO("[PERCEPTION] bypass face auth: activation passed (face_id forced empty)");

            const bool state_changed = (!*has_logged_feedback) || (*last_feedback_face_id != current_face_id) ||
                                       (*last_feedback_match_state != id_match);
            const bool heartbeat_due = (now - *last_feedback_log_time) >= 2.0;
            if (state_changed || heartbeat_due) {
                LOG_INFO("[PERCEPTION] feedback user_id="
                         << user_id << ", expected_face_id=" << expected_face_id << ", feedback_face_id="
                         << current_face_id << ", face_valid=" << (feedback->face_valid ? "true" : "false")
                         << ", face_match_score=" << feedback->face_match_score << ", tracking_state="
                         << static_cast<int>(feedback->tracking_state) << ", id_match=" << (id_match ? "true" : "false")
                         << ", face_ok=" << (face_ok ? "true" : "false")
                         << ", face_authenticated=" << (_face_authenticated ? "true" : "false")
                         << ", log_reason=" << (state_changed ? "state_changed" : "heartbeat"));
                *last_feedback_log_time = now;
                *last_feedback_face_id = current_face_id;
                *last_feedback_match_state = id_match;
                *has_logged_feedback = true;
            }
        };

    send_goal_options.result_callback =
        [this, expected_face_id, user_id, activation_matched](
            const rclcpp_action::ClientGoalHandle<perception_interfaces::action::TargetTracking>::WrappedResult&
                result) {
            (void)activation_matched;
            (void)result;
            (void)expected_face_id;
            (void)user_id;
            {
                std::lock_guard<std::mutex> lock(_mutex);
                _active_tracking_goal_handle.reset();
            }
            // NOTE: Execution result handling is intentionally disabled.
            // Keep this block for future restore/debugging:
            /*
            std::lock_guard<std::mutex> lock(_mutex);
            std::string exit_status_str = "<none>";
            if (result.result != nullptr) {
                exit_status_str = std::to_string(result.result->exit_status);
            }
            switch (result.code) {
                case rclcpp_action::ResultCode::SUCCEEDED:
                    LOG_INFO("[PERCEPTION] result SUCCEEDED"
                             << ", user_id=" << user_id
                             << ", expected_face_id=" << expected_face_id
                             << ", exit_status=" << exit_status_str);
                    break;
                case rclcpp_action::ResultCode::ABORTED:
                    LOG_ERROR("[PERCEPTION] result ABORTED"
                              << ", user_id=" << user_id
                              << ", expected_fac    e_id=" << expected_face_id
                              << ", exit_status=" << exit_status_str);
                    // bypass: do not fail auth based on result
                    _face_authenticated = true;
                    break;
                case rclcpp_action::ResultCode::CANCELED:
                    // bypass: do not fail auth based on cancel
                    _face_authenticated = true;
                    LOG_INFO("[PERCEPTION] result CANCELED"
                             << ", user_id=" << user_id
                             << ", expected_face_id=" << expected_face_id
                             << ", exit_status=" << exit_status_str);
                    break;
                default:
                    LOG_ERROR("[PERCEPTION] result UNKNOWN"
                              << ", user_id=" << user_id
                              << ", expected_face_id=" << expected_face_id
                              << ", exit_status=" << exit_status_str);
                    _face_authenticated = true;
                    break;
            }
            */
        };

    _perception_client->async_send_goal(goal, send_goal_options);
    {
        std::lock_guard<std::mutex> lock(_mutex);
        ++_follow_auth_session_id;
        // bypass: mark authenticated immediately; still rely on feedback for target tracking freshness only.
        _face_authenticated = true;
    }
    return true;
}

void PerceptionService::stopTracking() {
    if (_perception_client) {
        std::shared_ptr<rclcpp_action::ClientGoalHandle<perception_interfaces::action::TargetTracking>> gh;
        {
            std::lock_guard<std::mutex> lock(_mutex);
            gh = _active_tracking_goal_handle;
        }

        if (gh) {
            try {
                LOG_INFO("[PERCEPTION] stopTracking: async_cancel_goal(target_tracking)");
                _perception_client->async_cancel_goal(gh);
            } catch (const rclcpp_action::exceptions::UnknownGoalHandleError&) {
                LOG_WARN("[PERCEPTION] async_cancel_goal: handle not tracked by client (already finished?)");
            }
        }

        LOG_INFO("[PERCEPTION] stopTracking: async_cancel_all_goals(target_tracking)");
        _perception_client->async_cancel_all_goals();

        {
            std::lock_guard<std::mutex> lock(_mutex);
            _active_tracking_goal_handle.reset();
        }
    }
    clearTarget();
    std::lock_guard<std::mutex> lock(_mutex);
    _last_perception_feedback_time = 0.0;
}

bool PerceptionService::isTrackingServerOnline() const {
    if (!_perception_client) return false;
    return _perception_client->wait_for_action_server(std::chrono::seconds(0));
}

bool PerceptionService::isPerceptionFeedbackFresh(int64_t timeout_ms) const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _isPerceptionFeedbackFresh(timeout_ms);
}

bool PerceptionService::_isPerceptionFeedbackFresh(int64_t timeout_ms) const {
    return !utils::LogicUtils::IsTimeoutMs(_last_perception_feedback_time, timeout_ms);
}

bool PerceptionService::targetLocked() const {
    std::lock_guard<std::mutex> lock(_mutex);
    if (!_isPerceptionFeedbackFresh(3000)) return false;
    return _target.has_value() && _target.value().confidence > CONFIDENCE_THRESHOLD;
}

bool PerceptionService::faceAuthenticated() const {
    std::lock_guard<std::mutex> lock(_mutex);
    return _face_authenticated;
}

std::optional<std::tuple<double, double, double>> PerceptionService::targetPosition() const {
    std::lock_guard<std::mutex> lock(_mutex);
    if (!_isPerceptionFeedbackFresh(3000)) return std::nullopt;
    if (_target.has_value()) {
        return _target.value().position;
    }
    return std::nullopt;
}

void PerceptionService::updateSimulatedTarget(const TargetInfo& target) {
    std::lock_guard<std::mutex> lock(_mutex);
    _target = target;
    _last_perception_feedback_time =
        std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
    _face_authenticated = true;
}

void PerceptionService::clearTarget() {
    std::lock_guard<std::mutex> lock(_mutex);
    _target = std::nullopt;
    _face_authenticated = false;
}

}  // namespace services
}  // namespace robot_control
