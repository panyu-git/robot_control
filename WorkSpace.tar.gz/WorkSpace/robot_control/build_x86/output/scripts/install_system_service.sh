#!/bin/bash
# Install Robot Control System as systemd service

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
SERVICE_NAME="robot-control"

echo "Installing Robot Control System as systemd service..."

# Create systemd service file
sudo tee /etc/systemd/system/${SERVICE_NAME}.service > /dev/null <<EOF
[Unit]
Description=Robot Control System
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$PROJECT_ROOT
ExecStart=$PROJECT_ROOT/scripts/start_system.sh --simulated
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

# Reload systemd
sudo systemctl daemon-reload

# Enable service
sudo systemctl enable ${SERVICE_NAME}

echo "Service installed."
echo ""
echo "Commands:"
echo "  sudo systemctl start ${SERVICE_NAME}   # Start service"
echo "  sudo systemctl stop ${SERVICE_NAME}    # Stop service"
echo "  sudo systemctl status ${SERVICE_NAME}  # Check status"
echo "  journalctl -u ${SERVICE_NAME} -f       # View logs"
