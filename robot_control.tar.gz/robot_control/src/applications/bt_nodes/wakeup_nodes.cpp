#include "robot_control/applications/bt_nodes/wakeup_nodes.hpp"

#include <map>
#include <string>

#include "robot_control/core/enums.hpp"
#include "robot_control/core/robot_control_configs.hpp"
#include "robot_control/utils/logic_utils.hpp"

namespace robot_control {
namespace applications {
namespace bt_nodes {

ExecuteWakeupRotate::ExecuteWakeupRotate(const std::string& name, const BT::NodeConfig& config,
                                         std::shared_ptr<core::Blackboard> blackboard)
    : framework::StatefulActionNode(name, config, blackboard) {}

core::NodeStatus ExecuteWakeupRotate::onStartAction() {
    auto user_id = _blackboard->get<std::string>(core::BlackboardKeys::LAST_WAKEUP_USER_ID, "");
    auto target_yaw = _blackboard->get<std::string>(core::BlackboardKeys::LAST_WAKEUP_TARGET_YAW, "");
    auto max_angular_velocity =
        _blackboard->get<std::string>(core::BlackboardKeys::LAST_WAKEUP_MAX_ANGULAR_VELOCITY, "0.5");
    auto timeout = _blackboard->get<std::string>(core::BlackboardKeys::LAST_WAKEUP_TIMEOUT, "");
    auto task_id = _blackboard->get<std::string>(core::BlackboardKeys::LAST_WAKEUP_TASK_ID, "");

    LOG_INFO("ExecuteWakeupRotate: onStartAction, user_id=" << user_id << ", target_yaw=" << target_yaw);

    if (user_id.empty() || target_yaw.empty()) {
        LOG_WARN("ExecuteWakeupRotate: missing params, user_id=" << user_id << ", target_yaw=" << target_yaw);
        _blackboard->set("wakeup_fail_reason", std::string("missing_wakeup_params"));
        return core::NodeStatus::FAILURE;
    }

    // Instead of direct service call, request via blackboard
    _blackboard->set("navigation_cmd", std::string("rotate"));
    _blackboard->set("navigation_target_user", user_id);
    _blackboard->set("navigation_target_yaw", target_yaw);
    _blackboard->set("navigation_max_angular_velocity", max_angular_velocity);
    _blackboard->set("navigation_timeout", timeout);
    _blackboard->set("navigation_task_id", task_id);

    // Reset result to prevent using stale success from previous tasks
    _blackboard->set("nav_last_result_success", false);

    _blackboard->set("wakeup_start_time", utils::LogicUtils::GetCurrentTimeSec());
    _start_time = std::chrono::steady_clock::now();
    LOG_INFO("ExecuteWakeupRotate: ROTATE_TASK requested via blackboard");
    return core::NodeStatus::RUNNING;
}

core::NodeStatus ExecuteWakeupRotate::onRunningAction() {
    // Check navigation status from blackboard
    auto nav_status = static_cast<core::NavigationStatus>(
        _blackboard->get<int>("nav_status", static_cast<int>(core::NavigationStatus::IDLE)));

    if (nav_status == core::NavigationStatus::IDLE) {
        // Check if it was successful (need a success flag on blackboard from NavigationService)
        bool success = _blackboard->get<bool>("nav_last_result_success", true);
        LOG_INFO("ExecuteWakeupRotate: navigation complete via blackboard, success="
                 << success << ", phase="
                 << core::toString(_blackboard->get<core::WakeupPhase>("wakeup_phase", core::WakeupPhase::IDLE)));
        _blackboard->set("wakeup_fail_reason", success ? std::string("") : std::string("rotate_task_failed"));
        return success ? core::NodeStatus::SUCCESS : core::NodeStatus::FAILURE;
    } else if (nav_status == core::NavigationStatus::FAILED) {
        _blackboard->set("wakeup_fail_reason", std::string("rotate_task_failed"));
        return core::NodeStatus::FAILURE;
    }

    const double timeout_sec = 15.0;  // 15s max for wakeup rotation
    auto elapsed = std::chrono::steady_clock::now() - _start_time;
    double elapsed_sec = std::chrono::duration<double>(elapsed).count();
    if (elapsed_sec >= timeout_sec) {
        LOG_WARN("ExecuteWakeupRotate: timeout reached (" << elapsed_sec << "s)");
        _blackboard->set("wakeup_fail_reason", std::string("rotate_task_timeout"));
        return core::NodeStatus::FAILURE;
    }

    static int log_counter = 0;
    if (log_counter++ % 20 == 0) {  // Log every 1s at 20Hz
        LOG_DEBUG("ExecuteWakeupRotate: running, elapsed=" << elapsed_sec << "s");
    }

    return core::NodeStatus::RUNNING;
}

void ExecuteWakeupRotate::onHaltedAction() {
    _blackboard->set("navigation_cmd", std::string("cancel"));
}

// WakeupFsmIs
WakeupFsmIs::WakeupFsmIs(const std::string& name, const BT::NodeConfig& config,
                         std::shared_ptr<core::Blackboard> blackboard)
    : ConditionNode(name, config, blackboard) {}

bool WakeupFsmIs::check() {
    auto phase_str = getInput<std::string>("phase").value();
    // Normalize input phase_str to uppercase for comparison
    std::string normalized_expected = phase_str;
    std::transform(normalized_expected.begin(), normalized_expected.end(), normalized_expected.begin(), ::toupper);

    auto current_phase = _blackboard->get<core::WakeupPhase>("wakeup_phase", core::WakeupPhase::IDLE);
    std::string current_phase_str = core::toString(current_phase);

    bool match = (normalized_expected == current_phase_str);

    if (!match) {
        LOG_DEBUG_NAMED("WakeupBT", "WakeupFsmIs: phase mismatch, expected=" << normalized_expected
                                                                             << ", current=" << current_phase_str);
    } else {
        static std::string last_logged_phase = "";
        if (last_logged_phase != normalized_expected) {
            LOG_INFO_NAMED("WakeupBT", "WakeupFsmIs: phase match, phase=" << normalized_expected);
            last_logged_phase = normalized_expected;
        }
    }
    return match;
}

// TransitionToWakeup
TransitionToWakeup::TransitionToWakeup(const std::string& name, const BT::NodeConfig& config,
                                       std::shared_ptr<core::Blackboard> blackboard)
    : ActionNode(name, config, blackboard) {}

core::NodeStatus TransitionToWakeup::execute() {
    _blackboard->set("wakeup_phase", core::WakeupPhase::WAKEUP);
    return core::NodeStatus::SUCCESS;
}

// WakeupTransitionToIdle
WakeupTransitionToIdle::WakeupTransitionToIdle(const std::string& name, const BT::NodeConfig& config,
                                               std::shared_ptr<core::Blackboard> blackboard)
    : ActionNode(name, config, blackboard) {}

core::NodeStatus WakeupTransitionToIdle::execute() {
    LOG_INFO_NAMED("WakeupBT", "WakeupTransitionToIdle: transitioning phase to IDLE");
    _blackboard->set("wakeup_phase", core::WakeupPhase::IDLE);
    return core::NodeStatus::SUCCESS;
}

// WakeupTransitionToFault
WakeupTransitionToFault::WakeupTransitionToFault(const std::string& name, const BT::NodeConfig& config,
                                                 std::shared_ptr<core::Blackboard> blackboard)
    : ActionNode(name, config, blackboard) {}

core::NodeStatus WakeupTransitionToFault::execute() {
    _blackboard->set("wakeup_phase", core::WakeupPhase::FAULT);
    return core::NodeStatus::SUCCESS;
}

// CleanupWakeupTask
CleanupWakeupTask::CleanupWakeupTask(const std::string& name, const BT::NodeConfig& config,
                                     std::shared_ptr<core::Blackboard> blackboard)
    : ActionNode(name, config, blackboard) {}

core::NodeStatus CleanupWakeupTask::execute() {
    LOG_INFO_NAMED("WakeupBT", "CleanupWakeupTask: cleaning up");
    _blackboard->set("navigation_cmd", std::string("cancel"));
    _blackboard->deleteKey("wakeup_start_time");
    return core::NodeStatus::SUCCESS;
}

// CheckWakeupNavStatus
CheckWakeupNavStatus::CheckWakeupNavStatus(const std::string& name, const BT::NodeConfig& config,
                                           std::shared_ptr<core::Blackboard> blackboard)
    : ConditionNode(name, config, blackboard) {}

bool CheckWakeupNavStatus::check() {
    auto status_int = _blackboard->get<int>("nav_status", static_cast<int>(core::NavigationStatus::IDLE));
    auto status = static_cast<core::NavigationStatus>(status_int);

    // 只要任务在运行就算成功
    return (status == core::NavigationStatus::RUNNING);
}

}  // namespace bt_nodes
}  // namespace applications
}  // namespace robot_control
