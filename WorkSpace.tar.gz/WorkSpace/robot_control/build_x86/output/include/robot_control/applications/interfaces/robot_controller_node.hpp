#pragma once

#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <vector>

#include "base_interfaces/msg/Header.hpp"
#include "interaction_interfaces/msg/HmiControl2RobotControlMessage.hpp"
#include "interaction_interfaces/msg/RobotControlStateMessage.hpp"
#include "robot_control/applications/interfaces/robot_controller.hpp"
#include "robot_control/core/enums.hpp"
#include "robot_control/core/events.hpp"
#include "segar/segar.h"
#include "tp_master_interfaces/msg/TpFunctionState.hpp"
#include "usr_msg/std_msgs/msg/String.hpp"

namespace robot_control {
namespace applications {
namespace interfaces {

class RobotControllerNode : public std::enable_shared_from_this<RobotControllerNode> {
   public:
    using HmiCommandMsg = interaction_interfaces::msg::HmiControl2RobotControlMessage;
    using RobotStateMsg = interaction_interfaces::msg::RobotControlStateMessage;
    using TpFunctionStateMsg = tp_master_interfaces::msg::TpFunctionState;

    RobotControllerNode();
    bool init();

    void shutdown();

    std::string get_name() const {
        return "robot_controller";
    }

   private:
    void _handleHmiCommand(const std::shared_ptr<HmiCommandMsg>& msg);

    std::map<std::string, std::string> _parseExecuteParam(const std::string& execute_param) const;
    bool _dispatchRobotCommand(uint8_t cmd_type, const std::string& execute_param, std::string& detail_message);

    // Publishers
    void _publishEvent(const std::string& event_type, const std::string& message);
    void _publishEventFromCore(const core::Event& event);
    void _bridgeCoreEventsToRos();
    std::optional<RobotStateMsg> _createFeedbackState(const core::Event& event);
    void _publishPeriodicTpFunctionState();

    std::shared_ptr<rti::segar::Node> _node;
    std::unique_ptr<RobotController> _controller;

    // Segar Readers
    std::shared_ptr<rti::segar::Reader<HmiCommandMsg>> _hmiCommandSub;

    // Segar Writers
    std::shared_ptr<rti::segar::Writer<RobotStateMsg>> _robotStatePub;
    std::shared_ptr<rti::segar::Writer<TpFunctionStateMsg>> _tpFunctionStatePub;
    std::shared_ptr<rti::segar::Writer<std_msgs::msg::String>> _eventsPub;

    // Segar Timer
    std::shared_ptr<rti::segar::Timer> _stateTimer;

    // State tracking
    bool _ready;
    uint64_t _currentSeq;
    std::string _lastCommandId;
    double _lastCommandTime;
    std::string _logger_name;
    mutable std::mutex _mountup_stage_mutex;
    core::MountupStage _mountup_stage{core::MountupStage::IDLE};
};

}  // namespace interfaces
}  // namespace applications
}  // namespace robot_control
