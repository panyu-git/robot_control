#!/usr/bin/env python3
"""
Robot Control System - Interactive Demo

This demo shows how to use the RobotController API.
Run with: python examples/demo.py
"""
import sys
import os
import time
import logging

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from applications.interfaces import RobotController


def setup_logging():
    """Setup logging configuration"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )


def print_status(controller: RobotController):
    """Print current system status"""
    status = controller.get_status()
    print("\n" + "=" * 50)
    print("System Status:")
    print(f"  Function: {status['function']}")
    print(f"  Status: {status['function_status']}")
    print(f"  Battery: {status['battery_level']}%")
    print(f"  Charging: {status['is_charging']}")
    print(f"  Navigation: {status['navigation_status']}")
    print(f"  Target Locked: {status['target_locked']}")
    print("=" * 50)


def demo_basic_usage():
    """Demonstrate basic API usage"""
    print("\n" + "=" * 60)
    print(" DEMO 1: Basic Usage")
    print("=" * 60)

    # Create controller
    controller = RobotController(simulated=True, tick_rate=20.0)
    controller.start()
    time.sleep(0.2)

    print("\n1. Starting in IDLE state")
    print_status(controller)

    print("\n2. Starting FOLLOW with API call")
    controller.follow(distance=1.5, speed=0.5)
    time.sleep(0.5)
    print_status(controller)

    print("\n3. Taking PHOTO (pauses follow)")
    controller.photo()
    time.sleep(1.0)
    print_status(controller)

    print("\n4. Stopping")
    controller.stop()
    time.sleep(0.3)
    print_status(controller)

    controller.shutdown()
    print("\nDemo 1 complete!")


def demo_voice_commands():
    """Demonstrate voice command processing"""
    print("\n" + "=" * 60)
    print(" DEMO 2: Voice Commands (Chinese)")
    print("=" * 60)

    controller = RobotController(simulated=True)
    controller.start()
    time.sleep(0.2)

    commands = [
        ("跟着我", "Start following"),
        ("拍照", "Take photo"),
        ("停止", "Stop"),
    ]

    for cmd, description in commands:
        print(f"\nCommand: '{cmd}' ({description})")
        controller.command(cmd)
        time.sleep(0.5)
        print_status(controller)

    controller.shutdown()
    print("\nDemo 2 complete!")


def demo_priority_preemption():
    """Demonstrate priority-based preemption"""
    print("\n" + "=" * 60)
    print(" DEMO 3: Priority Preemption (Low Battery)")
    print("=" * 60)

    controller = RobotController(simulated=True)
    controller.start()
    time.sleep(0.2)

    print("\n1. Start following")
    controller.follow()
    time.sleep(0.3)
    print_status(controller)

    print("\n2. Simulate low battery (15%)")
    controller.set_battery_level(15)
    time.sleep(0.5)
    print_status(controller)

    print("\n3. System should have switched to CHARGE")
    print("   (CHARGE has highest priority)")

    # Let it charge for a bit
    time.sleep(2.0)
    print_status(controller)

    controller.shutdown()
    print("\nDemo 3 complete!")


def demo_photo_pause_resume():
    """Demonstrate photo pausing and resuming follow"""
    print("\n" + "=" * 60)
    print(" DEMO 4: Photo Pause/Resume Follow")
    print("=" * 60)

    controller = RobotController(simulated=True)
    controller.start()
    time.sleep(0.2)

    print("\n1. Start following")
    controller.follow()
    time.sleep(0.3)
    print_status(controller)

    print("\n2. Take photo (should pause follow)")
    controller.photo()
    time.sleep(0.2)
    print_status(controller)

    print("\n3. Wait for photo to complete...")
    time.sleep(1.0)
    print_status(controller)

    print("\n4. Follow should resume automatically")
    time.sleep(0.5)
    print_status(controller)

    controller.stop()
    controller.shutdown()
    print("\nDemo 4 complete!")


def interactive_mode():
    """Run interactive command mode"""
    print("\n" + "=" * 60)
    print(" Interactive Mode")
    print("=" * 60)
    print("\nCommands:")
    print("  follow [distance] [speed] - Start following")
    print("  photo                     - Take photo")
    print("  stop                      - Stop current function")
    print("  charge                    - Start charging")
    print("  battery <level>           - Set battery level")
    print("  status                    - Show status")
    print("  quit                      - Exit")
    print("\nVoice commands (Chinese):")
    print("  跟着我, 拍照, 停止, 充电")
    print("=" * 60)

    controller = RobotController(simulated=True)
    controller.start()

    try:
        while True:
            try:
                cmd = input("\n> ").strip()
            except EOFError:
                break

            if not cmd:
                continue

            if cmd == "quit" or cmd == "exit":
                break
            elif cmd == "status":
                print_status(controller)
            elif cmd.startswith("battery "):
                try:
                    level = int(cmd.split()[1])
                    controller.set_battery_level(level)
                    print(f"Battery set to {level}%")
                except (ValueError, IndexError):
                    print("Usage: battery <level>")
            elif cmd.startswith("follow"):
                parts = cmd.split()
                distance = float(parts[1]) if len(parts) > 1 else None
                speed = float(parts[2]) if len(parts) > 2 else None
                controller.follow(distance=distance, speed=speed)
                print("Follow started")
            elif cmd == "photo":
                controller.photo()
                print("Photo requested")
            elif cmd == "stop":
                controller.stop()
                print("Stop requested")
            elif cmd == "charge":
                controller.charge()
                print("Charge requested")
            else:
                # Try as voice command
                if controller.command(cmd):
                    print(f"Command '{cmd}' accepted")
                else:
                    print(f"Unknown command: {cmd}")

    except KeyboardInterrupt:
        print("\n")

    controller.shutdown()
    print("Goodbye!")


def main():
    """Main entry point"""
    setup_logging()

    print("=" * 60)
    print(" Robot Control System - Demo")
    print("=" * 60)
    print("\nSelect demo:")
    print("  1. Basic Usage")
    print("  2. Voice Commands")
    print("  3. Priority Preemption")
    print("  4. Photo Pause/Resume")
    print("  5. Interactive Mode")
    print("  0. Run All Demos")

    try:
        choice = input("\nChoice (0-5): ").strip()
    except EOFError:
        choice = "0"

    if choice == "0":
        demo_basic_usage()
        demo_voice_commands()
        demo_priority_preemption()
        demo_photo_pause_resume()
    elif choice == "1":
        demo_basic_usage()
    elif choice == "2":
        demo_voice_commands()
    elif choice == "3":
        demo_priority_preemption()
    elif choice == "4":
        demo_photo_pause_resume()
    elif choice == "5":
        interactive_mode()
    else:
        print("Invalid choice")


if __name__ == "__main__":
    main()
