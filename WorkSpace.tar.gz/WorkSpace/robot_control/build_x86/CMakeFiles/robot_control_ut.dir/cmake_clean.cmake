file(REMOVE_RECURSE
  "CMakeFiles/robot_control_ut.dir/ut/applications/framework/function_base_test.cpp.o"
  "CMakeFiles/robot_control_ut.dir/ut/applications/framework/function_base_test.cpp.o.d"
  "CMakeFiles/robot_control_ut.dir/ut/applications/framework/function_manager_test.cpp.o"
  "CMakeFiles/robot_control_ut.dir/ut/applications/framework/function_manager_test.cpp.o.d"
  "CMakeFiles/robot_control_ut.dir/ut/applications/framework/function_scheduler_test.cpp.o"
  "CMakeFiles/robot_control_ut.dir/ut/applications/framework/function_scheduler_test.cpp.o.d"
  "CMakeFiles/robot_control_ut.dir/ut/applications/functions/mountup_function_test.cpp.o"
  "CMakeFiles/robot_control_ut.dir/ut/applications/functions/mountup_function_test.cpp.o.d"
  "robot_control_ut"
  "robot_control_ut.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/robot_control_ut.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
