#pragma once

#include <chrono>

#include "robot_control/core/enums.hpp"

namespace robot_control {
namespace services {
class NavigationService;
class PerceptionService;
}  // namespace services

namespace applications {
namespace interfaces {

/**
 * @brief RobotContext groups shared robot services and provides common utility methods.
 * This class is designed to be composed within Functions that need service access.
 */
class RobotContext {
   public:
    RobotContext(services::NavigationService* nav = nullptr, services::PerceptionService* perception = nullptr)
        : navigation(nav), perception(perception) {}

    /**
     * @brief Check health of services within this context.
     * @param function_type Type of the function calling this check (for logging).
     * @param session_start_time Start time of the current function session.
     * @return FAILED if health check fails, otherwise the caller's current status (passed as parameter).
     */
    core::FunctionStatus checkHealth(core::FunctionType function_type,
                                     std::chrono::steady_clock::time_point session_start_time) const;

    services::NavigationService* const navigation;
    services::PerceptionService* const perception;
};

}  // namespace interfaces
}  // namespace applications
}  // namespace robot_control
