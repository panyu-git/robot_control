# Robot Control System (C++)

A modular robot control system implementing Function Management (FSM) and Task Management (Behavior Tree) for autonomous robot operations. Built with **ROS2** and **C++17**.

> **Note**: The original Python implementation is preserved in `backup_python/`.

## Features

- **Function Management (FSM Layer)**: High-level state machine for managing robot capabilities
  - IDLE: System standby
  - FOLLOW: Human tracking and following
  - PHOTO: Camera capture
  - CHARGE: Battery charging (highest priority)
  - BOARDING: Robot dog boarding/alighting via ladder mechanism

- **Task Management (BT Layer)**: Behavior tree execution for detailed task control
  - Sequence, Selector, Parallel composite nodes
  - Retry, Timeout, Loop decorator nodes
  - Action and Condition leaf nodes

- **Decoupled Architecture**: Parallel services for Navigation and Perception
- **Priority-based Preemption**: Higher priority functions can interrupt lower priority ones
- **Bundle Scheduling**: Submit dependent function bundles (e.g. `{A+B+C}`) with all-or-nothing execution
- **Context Preservation**: Soft preemption saves state for later resumption
- **Simulated Hardware**: Full simulation support for development and testing
- **ROS2 Integration**: Services, topics, and actions for external communication

## Project Structure

```
robot_control/
├── CMakeLists.txt                  # CMake build file (ament_cmake)
├── package.xml                     # ROS2 package manifest
├── config/                         # Configuration files
│   ├── bt_trees/                  # Behavior Tree XML definitions
│   │   ├── face_recog_tree.xml
│   │   ├── follow_tree.xml
│   │   └── wakeup_tree.xml
│   ├── default.yaml               # Default configuration
│   └── fastdds.xml                # FastDDS configuration
├── include/robot_control/          # C++ headers
│   ├── core/                      # Core components
│   │   ├── enums.hpp              # Enumerations with string conversion
│   │   ├── events.hpp             # Event system (EventBus singleton)
│   │   └── blackboard.hpp         # Thread-safe shared state container
│   ├── services/                  # Hardware service abstractions
│   │   ├── service_base.hpp       # Abstract service base class
│   │   ├── ros2_interface.hpp     # ROS2 interface simulation
│   │   ├── navigation_service.hpp # Navigation and following
│   │   └── perception_service.hpp # Human perception and face auth
│   └── applications/              # Application layer
│       ├── framework/             # FSM and BT frameworks
│       │   ├── bt_nodes.hpp       # Behavior tree node types
│       │   ├── function_base.hpp  # Abstract function base
│       │   ├── function_manager.hpp # FSM controller
│       │   └── task_manager.hpp   # BT executor
│       ├── functions/             # Function implementations
│       │   ├── idle_function.hpp
│       │   └── follow_function.hpp
│       └── interfaces/            # External interfaces
│           ├── robot_controller.hpp     # Main controller API
│           ├── command_handler.hpp      # Command processing
│           └── robot_controller_node.hpp # ROS2 node wrapper
├── src/                            # C++ source files
│   ├── core/                      # Core implementations
│   ├── services/                  # Service implementations
│   ├── applications/              # Application implementations
│   │   ├── framework/
│   │   ├── functions/
│   │   └── interfaces/
│   └── main.cpp                   # Entry point
├── launch/                         # ROS2 launch files
│   ├── robot_control.launch.py
│   └── robot_control_simple.launch.py
├── test/                           # Tests (GTest)
├── backup_python/                  # Original Python implementation backup
├── scripts/                        # Utility scripts
└── docs/                           # Documentation
```

## Quick Start

### Prerequisites

- ROS2 (Humble or later)
- C++17 compiler (GCC 9+ or Clang 10+)
- colcon build tools

### Build

```bash
# Source ROS2 environment
source /opt/ros/humble/setup.bash

# Build the package
cd robot_control
colcon build --packages-select robot_control

# Source the workspace
source install/setup.bash
```

### Run

```bash
# Launch with default settings (simulated mode)
ros2 launch robot_control robot_control.launch.py

# Launch with custom parameters
ros2 launch robot_control robot_control.launch.py simulated:=true tick_rate:=20.0

# Simple launch
ros2 launch robot_control robot_control_simple.launch.py
```

### Interact via ROS2 Services

```bash
# Start following
ros2 service call /robot/follow std_srvs/srv/Trigger

# Take photo
ros2 service call /robot/photo std_srvs/srv/Trigger

# Stop current function
ros2 service call /robot/stop std_srvs/srv/Trigger

# Start charging
ros2 service call /robot/charge std_srvs/srv/Trigger

# Start boarding
ros2 service call /robot/boarding std_srvs/srv/Trigger

# Get status
ros2 service call /robot/get_status_srv std_srvs/srv/Trigger
```

### Interact via ROS2 Topics

```bash
# Send command
ros2 topic pub /robot/command std_msgs/msg/String "data: 'follow'"

# Send voice command (JSON)
ros2 topic pub /voice/command std_msgs/msg/String "data: '{\"intent\":\"follow\",\"text\":\"跟随\"}'"

# Monitor status
ros2 topic echo /robot/status_json

# Monitor battery
ros2 topic echo /robot/battery

# Monitor state changes
ros2 topic echo /robot/state

# Monitor events
ros2 topic echo /robot/events
```

## Architecture

Scheduler design and usage details: [`docs/function_scheduler.md`](docs/function_scheduler.md)

Function scheduler supports both:

- Single function submit (`submitFunction`) as a one-item bundle.
- Ordered bundle submit (`submitFunctionBundle`) for dependent execution.
- Bundle-level priority computed as max priority in bundle.
- Bundle failure semantics: current step fails -> remaining steps in bundle are skipped.

### FSM (Function State Machine)

The FSM manages high-level robot functions with priority-based transitions:

```
Priority: CHARGE(1) > FOLLOW/PHOTO/BOARDING(2) > IDLE(3)

State Transitions:
  IDLE ──────────> FOLLOW (user command)
  IDLE ──────────> BOARDING (user command)
  FOLLOW ────────> PHOTO (pause, save context)
  PHOTO ─────────> FOLLOW (resume with context)
  ANY ───────────> CHARGE (low battery, hard preempt)
  CHARGE ────────> IDLE (charging complete)
  FOLLOW ────────> IDLE (stop command)
```

### BT (Behavior Tree)

Each function uses a behavior tree for task execution:

```
BT_FOLLOW:
  Sequence
  ├── InitializeFollowParams
  ├── Retry(3) -> StartFollowTask
  ├── Loop -> MonitorSequence
  │           ├── CheckNavigationStatus
  │           ├── CheckStopConditions
  │           └── UpdateProgress
  └── CleanupFollowTask

BT_BOARDING:
  Sequence
  ├── SetupLocations
  ├── Retry(3) -> NavigateToPickup
  ├── BoardingSequence
  │   ├── Retry(2) -> DeployLadder
  │   ├── Retry(2) -> ExecuteBoarding
  │   └── RetractLadder
  ├── Retry(3) -> NavigateToDestination
  ├── AlightingSequence
  │   ├── Retry(2) -> DeployLadder
  │   ├── Retry(2) -> ExecuteAlighting
  │   └── RetractLadder
  └── Cleanup
```

### Blackboard

Thread-safe shared state container for inter-component communication:

```cpp
blackboard->fsm_state.current_state;         // Current FSM state
blackboard->navigation.status;               // Navigation status
blackboard->task_params.follow_speed;        // Follow speed parameter
```

## ROS2 Interfaces

### Services

| Service | Type | Description |
|---------|------|-------------|
| `/robot/follow` | `std_srvs/srv/Trigger` | Start follow mode |
| `/robot/stop` | `std_srvs/srv/Trigger` | Stop current task |
| `/robot/photo` | `std_srvs/srv/Trigger` | Take photo |
| `/robot/charge` | `std_srvs/srv/Trigger` | Start charging |
| `/robot/boarding` | `std_srvs/srv/Trigger` | Start boarding |
| `/robot/get_status_srv` | `std_srvs/srv/Trigger` | Get robot status (JSON) |

### Published Topics

| Topic | Type | Rate | Description |
|-------|------|------|-------------|
| `/robot/status_json` | `std_msgs/msg/String` | 1 Hz | Full status as JSON |
| `/robot/state` | `std_msgs/msg/String` | 1 Hz | Current function state |
| `/robot/events` | `std_msgs/msg/String` | Event-driven | Event notifications |

### Subscribed Topics

| Topic | Type | Description |
|-------|------|-------------|
| `/robot/command` | `std_msgs/msg/String` | Command input (intent string) |
| `/voice/command` | `std_msgs/msg/String` | Voice command input (JSON) |

## Supported Scenarios

| Scenario | Description | Behavior |
|----------|-------------|----------|
| **1. Follow Human** | Main follow task with perception | User starts follow → face recognition → navigation follows human → stop → IDLE |
| **2. Target Lost** | Robust tracking | Navigation monitors perception freshness → enters SEARCHING if target lost → times out to IDLE |
| **3. Parameter Update**| Real-time adjustment | User updates follow distance or speed via command during operation |

## Extending the System

### Adding a New Function

1. Add enum value to `FunctionType` in `include/robot_control/core/enums.hpp`
2. Create header and source in `include/robot_control/applications/functions/` and `src/applications/functions/`

```cpp
#include "robot_control/applications/framework/function_base.hpp"

class MyNewFunction : public robot_control::applications::framework::Function {
public:
    using Function::Function;

    core::FunctionType functionType() const override {
        return core::FunctionType::MY_NEW;
    }
    core::FunctionPriority priority() const override {
        return core::FunctionPriority::NORMAL;
    }
    
    // onEnter is called by the base class enter() method
    void onEnter(const std::optional<std::map<std::string, std::any>>& context) override { 
        // Subclass-specific initialization here.
        // Base class enter() already set status to INITIALIZING and cleared cmd_ prefixes.
    }
    
    std::optional<std::map<std::string, std::any>> onExit() override { return std::nullopt; }
    core::FunctionStatus postTick() override { return core::FunctionStatus::RUNNING; }
};
```

3. Register in `RobotController::_registerFunctions()`
4. Add to CMakeLists.txt source list

### Adding New BT Nodes

```cpp
#include "robot_control/applications/framework/bt_nodes.hpp"

class MyCustomAction : public robot_control::applications::framework::ActionNode {
public:
    using ActionNode::ActionNode;

    core::NodeStatus execute() override {
        // Your action logic
        return core::NodeStatus::SUCCESS;
    }
};
```

## Configuration

Edit `config/default.yaml` to customize:

```yaml
system:
  tick_rate: 20.0          # Control loop frequency (Hz)
  simulated: true          # Use simulated hardware

navigation:
  follow:
    default_distance: 1.5  # Follow distance (meters)
    default_speed: 0.5     # Follow speed (m/s)

battery:
  low_threshold: 20        # Low battery threshold (%)
```

## Code Style (clang-format)

This repository uses `.clang-format` (based on Google style) to format all C++ source/header files.

### Manual formatting

```bash
# From repo root
clang-format -i $(git ls-files '*.cpp' '*.cc' '*.cxx' '*.hpp' '*.hh' '*.h' | grep -v '^3rdparty/')
```

### Pre-commit hook

A project hook is provided at `.githooks/pre-commit`.

Install it to your local Git hooks:

```bash
cp .githooks/pre-commit .git/hooks/pre-commit
chmod +x .git/hooks/pre-commit
```

Hook behavior (for staged C++ files outside `3rdparty/`, including added/modified/deleted paths):

- **Yellow warning + allow commit**: `clang-format` is not installed in your environment; the hook shows a warning and waits for a key confirmation before continuing commit (falls back to auto-continue after a short wait in non-interactive environments).
- **Red warning + block commit**: style violations found; the hook auto-formats files in working tree, but does **not** update staged content. Review and stage intentionally, then commit again.
- **Green message + allow commit**: all staged C++ files already match `.clang-format`.

## Testing

```bash
# Build with tests
colcon build --packages-select robot_control --cmake-args -DBUILD_TESTING=ON

# Run tests
colcon test --packages-select robot_control
colcon test-result --verbose
```

## License

MIT License
