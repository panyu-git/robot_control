#pragma once

#include <cmath>
#include <memory>
#include <string>

namespace robot_control {
namespace services {

// =============================================================================
// ROS2 Message Types (Shared/Common)
// =============================================================================

enum class GoalStatus {
    UNKNOWN = 0,
    ACCEPTED = 1,
    EXECUTING = 2,
    CANCELING = 3,
    SUCCEEDED = 4,
    CANCELED = 5,
    ABORTED = 6
};

struct Quaternion {
    double x = 0.0;
    double y = 0.0;
    double z = 0.0;
    double w = 1.0;
};

struct Position {
    double x = 0.0;
    double y = 0.0;
    double z = 0.0;
};

struct Pose {
    Position position;
    Quaternion orientation;
};

struct Header {
    std::string frame_id = "odom";
    int64_t stamp_sec = 0;
    uint32_t stamp_nanosec = 0;
};

struct PoseStamped {
    Header header;
    Pose pose;
};

struct Pose2D {
    double x = 0.0;
    double y = 0.0;
    double theta = 0.0;

    PoseStamped toPoseStamped(const std::string& frame_id = "odom") const;
    static Pose2D fromPoseStamped(const PoseStamped& pose_stamped);
};

// =============================================================================
// ROS2 Interface Manager
// =============================================================================

class ROS2InterfaceManager {
   public:
    ROS2InterfaceManager(bool simulated = true);
    ~ROS2InterfaceManager();

    bool initialize();
    void shutdown();
};

}  // namespace services
}  // namespace robot_control
