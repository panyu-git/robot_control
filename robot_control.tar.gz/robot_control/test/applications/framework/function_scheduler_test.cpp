#include "robot_control/applications/framework/function_scheduler.hpp"

#include <gtest/gtest.h>

#include <memory>
#include <optional>
#include <string>

#include "robot_control/core/blackboard.hpp"

namespace robot_control::applications::framework::test {

class DummyScheduledFunction : public Function {
   public:
    DummyScheduledFunction(std::shared_ptr<core::Blackboard> blackboard, std::string name, int scheduler_priority,
                           core::FunctionType function_type = core::FunctionType::FOLLOW)
        : Function(std::move(blackboard)), _name(std::move(name)), _type(function_type) {
        setFunctionName(_name);
        setSchedulerPriority(scheduler_priority);
    }

    core::FunctionType functionType() const override {
        return _type;
    }

    core::FunctionPriority priority() const override {
        return core::FunctionPriority::NORMAL;
    }

    void onEnter(const std::optional<std::map<std::string, std::any>>& /*context*/) override {
        ++enter_count;
        setStatus(core::FunctionStatus::RUNNING);
    }

    std::optional<std::map<std::string, std::any>> onExit() override {
        ++exit_count;
        setStatus(core::FunctionStatus::IDLE);
        return std::nullopt;
    }

    std::optional<std::map<std::string, std::any>> onPause() override {
        ++pause_count;
        setStatus(core::FunctionStatus::PAUSED);
        return std::map<std::string, std::any>{{"paused_by", _name}};
    }

    void onResume(const std::map<std::string, std::any>& /*context*/) override {
        ++resume_count;
        setStatus(core::FunctionStatus::RUNNING);
    }

    core::FunctionStatus postTick() override {
        return status();
    }

    int enter_count{0};
    int exit_count{0};
    int pause_count{0};
    int resume_count{0};

   private:
    std::string _name;
    core::FunctionType _type;
};

class FunctionSchedulerTest : public ::testing::Test {
   protected:
    void SetUp() override {
        blackboard = std::make_shared<core::Blackboard>();
    }

    std::shared_ptr<DummyScheduledFunction> createFunction(const std::string& name, int priority,
                                                           core::FunctionType type = core::FunctionType::FOLLOW) {
        return std::make_shared<DummyScheduledFunction>(blackboard, name, priority, type);
    }

    void registerDummyFactories(FunctionScheduler& s, const std::vector<std::string>& names) {
        for (const auto& name : names) {
            s.registerFunctionFactory(name, [this, name](const nlohmann::json& data) {
                return createFunction(name, data.value("scheduler_priority", 0),
                                      core::fromString<core::FunctionType>(data.value("function_type", "IDLE")));
            });
        }
    }

    std::shared_ptr<core::Blackboard> blackboard;
};

TEST_F(FunctionSchedulerTest, ScenarioA_LowThenHighPriority_PreemptionHappens) {
    FunctionScheduler scheduler;
    auto low = createFunction("walk_low", 10);
    auto high = createFunction("raise_head_high", 20);

    ASSERT_TRUE(scheduler.submitFunction(low));
    ASSERT_TRUE(scheduler.submitFunction(high));

    ASSERT_NE(scheduler.currentFunction(), nullptr);
    EXPECT_EQ(scheduler.currentFunction()->functionName(), "raise_head_high");
    EXPECT_EQ(scheduler.currentFunction()->status(), core::FunctionStatus::RUNNING);
    EXPECT_EQ(low->status(), core::FunctionStatus::PAUSED);
    EXPECT_EQ(low->pause_count, 1);
    EXPECT_EQ(scheduler.pausedFunctionSize(), 1U);
    EXPECT_TRUE(scheduler.waitingFunctionNames().empty());
}

TEST_F(FunctionSchedulerTest, ScenarioB_StopContinuously_StackFallbackOrderIsCorrect) {
    FunctionScheduler scheduler;
    auto function_a = createFunction("function_a", 10);
    auto function_b = createFunction("function_b", 20);
    auto function_c = createFunction("function_c", 5);

    ASSERT_TRUE(scheduler.submitFunction(function_a));
    ASSERT_TRUE(scheduler.submitFunction(function_b));  // preempt a, push a to paused stack
    ASSERT_TRUE(scheduler.submitFunction(function_c));  // lower than b, goes to waiting queue

    ASSERT_NE(scheduler.currentFunction(), nullptr);
    EXPECT_EQ(scheduler.currentFunction()->functionName(), "function_b");
    EXPECT_EQ(scheduler.pausedFunctionNamesTopFirst(), std::vector<std::string>({"function_a"}));
    EXPECT_EQ(scheduler.waitingFunctionNames(), std::vector<std::string>({"function_c"}));

    // stop b -> highest between paused(a=10) and waiting(c=5) is a
    ASSERT_TRUE(scheduler.stopCurrentFunction());
    ASSERT_NE(scheduler.currentFunction(), nullptr);
    EXPECT_EQ(scheduler.currentFunction()->functionName(), "function_a");
    EXPECT_EQ(function_a->resume_count, 1);

    // stop a -> fallback to c
    ASSERT_TRUE(scheduler.stopCurrentFunction());
    ASSERT_NE(scheduler.currentFunction(), nullptr);
    EXPECT_EQ(scheduler.currentFunction()->functionName(), "function_c");
    EXPECT_EQ(function_c->enter_count, 1);
}

TEST_F(FunctionSchedulerTest, ScenarioC_SerializeDeserialize_DataConsistency) {
    FunctionScheduler scheduler;
    auto function_a = createFunction("function_a", 10);
    auto function_b = createFunction("function_b", 20);
    auto function_c = createFunction("function_c", 5);
    auto function_d = createFunction("function_d", 8);

    ASSERT_TRUE(scheduler.submitFunction(function_a));
    ASSERT_TRUE(scheduler.submitFunction(function_b));  // paused: a
    ASSERT_TRUE(scheduler.submitFunction(function_c));  // waiting: c
    ASSERT_TRUE(scheduler.submitFunction(function_d));  // waiting sorted: d, c

    const std::string dump = scheduler.dumpToJsonString();
    ASSERT_FALSE(dump.empty());

    FunctionScheduler restored;
    registerDummyFactories(restored, {"function_a", "function_b", "function_c", "function_d"});

    ASSERT_TRUE(restored.loadFromJsonString(dump));
    ASSERT_NE(restored.currentFunction(), nullptr);
    EXPECT_EQ(restored.currentFunction()->functionName(), "function_b");
    EXPECT_EQ(restored.currentFunction()->status(), core::FunctionStatus::RUNNING);
    EXPECT_EQ(restored.pausedFunctionNamesTopFirst(), std::vector<std::string>({"function_a"}));
    EXPECT_EQ(restored.waitingFunctionNames(), std::vector<std::string>({"function_d", "function_c"}));
}

TEST_F(FunctionSchedulerTest, DrainUntilOrEmpty_TargetIdle_StopsUntilIdleOrEmpty) {
    FunctionScheduler scheduler;
    auto idle = createFunction("idle", 100, core::FunctionType::IDLE);
    auto follow = createFunction("follow", 200, core::FunctionType::FOLLOW);
    auto wakeup = createFunction("wakeup", 250, core::FunctionType::WAKEUP);

    ASSERT_TRUE(scheduler.submitFunction(idle));
    ASSERT_TRUE(scheduler.submitFunction(follow));
    ASSERT_TRUE(scheduler.submitFunction(wakeup));
    ASSERT_NE(scheduler.currentFunction(), nullptr);
    EXPECT_EQ(scheduler.currentFunction()->functionType(), core::FunctionType::WAKEUP);

    ASSERT_TRUE(scheduler.drainUntilOrEmpty(core::FunctionType::IDLE));
    ASSERT_NE(scheduler.currentFunction(), nullptr);
    EXPECT_EQ(scheduler.currentFunction()->functionType(), core::FunctionType::IDLE);
    EXPECT_EQ(wakeup->exit_count, 1);
    EXPECT_EQ(follow->exit_count, 1);
}

TEST_F(FunctionSchedulerTest, BundleSubmit_SequentialCompletion_ExecutesFunctionsInOrder) {
    FunctionScheduler scheduler;
    auto function_a = createFunction("function_a", 10);
    auto function_b = createFunction("function_b", 30);
    auto function_c = createFunction("function_c", 20);

    ASSERT_TRUE(scheduler.submitFunctionBundle({function_a, function_b}));
    ASSERT_TRUE(scheduler.submitFunction(function_c));  // lower than bundle max(30), should wait

    ASSERT_NE(scheduler.currentFunction(), nullptr);
    EXPECT_EQ(scheduler.currentFunction()->functionName(), "function_a");
    EXPECT_EQ(scheduler.waitingBundleNames(), std::vector<std::string>({"{function_c}"}));

    ASSERT_TRUE(scheduler.completeCurrentFunction());
    ASSERT_NE(scheduler.currentFunction(), nullptr);
    EXPECT_EQ(scheduler.currentFunction()->functionName(), "function_b");
    EXPECT_EQ(function_b->enter_count, 1);
    EXPECT_EQ(scheduler.waitingBundleNames(), std::vector<std::string>({"{function_c}"}));

    ASSERT_TRUE(scheduler.completeCurrentFunction());
    ASSERT_NE(scheduler.currentFunction(), nullptr);
    EXPECT_EQ(scheduler.currentFunction()->functionName(), "function_c");
}

TEST_F(FunctionSchedulerTest, BundleSubmit_FailureSkipsRemainingFunctionsInBundle) {
    FunctionScheduler scheduler;
    auto function_a = createFunction("function_a", 40);
    auto function_b = createFunction("function_b", 10);
    auto function_c = createFunction("function_c", 20);

    ASSERT_TRUE(scheduler.submitFunctionBundle({function_a, function_b}));
    ASSERT_TRUE(scheduler.submitFunction(function_c));

    ASSERT_NE(scheduler.currentFunction(), nullptr);
    EXPECT_EQ(scheduler.currentFunction()->functionName(), "function_a");

    ASSERT_TRUE(scheduler.failCurrentFunction());
    ASSERT_NE(scheduler.currentFunction(), nullptr);
    EXPECT_EQ(scheduler.currentFunction()->functionName(), "function_c");
    EXPECT_EQ(function_b->enter_count, 0);
}

TEST_F(FunctionSchedulerTest, BundleScheduling_PriorityUsesMaxAndBundleActsAsWhole) {
    FunctionScheduler scheduler;
    auto function_a = createFunction("function_a", 10);
    auto function_b = createFunction("function_b", 80);
    auto function_c = createFunction("function_c", 70);
    auto function_d = createFunction("function_d", 60);

    ASSERT_TRUE(scheduler.submitFunctionBundle({function_a, function_b}));  // effective priority = 80
    ASSERT_TRUE(scheduler.submitFunctionBundle({function_c, function_d}));  // effective priority = 70

    ASSERT_NE(scheduler.currentFunction(), nullptr);
    EXPECT_EQ(scheduler.currentFunction()->functionName(), "function_a");
    EXPECT_EQ(scheduler.waitingBundleNames(), std::vector<std::string>({"{function_c+function_d}"}));

    ASSERT_TRUE(scheduler.completeCurrentFunction());
    ASSERT_NE(scheduler.currentFunction(), nullptr);
    EXPECT_EQ(scheduler.currentFunction()->functionName(), "function_b");
    EXPECT_TRUE(scheduler.waitingFunctionNames().size() == 1U);

    ASSERT_TRUE(scheduler.completeCurrentFunction());
    ASSERT_NE(scheduler.currentFunction(), nullptr);
    EXPECT_EQ(scheduler.currentFunction()->functionName(), "function_c");
}

TEST_F(FunctionSchedulerTest, BundleSerializeDeserialize_RestoresBundleState) {
    FunctionScheduler scheduler;
    auto function_a = createFunction("function_a", 10);
    auto function_b = createFunction("function_b", 30);
    auto function_c = createFunction("function_c", 20);

    ASSERT_TRUE(scheduler.submitFunctionBundle({function_a, function_b}));
    ASSERT_TRUE(scheduler.submitFunction(function_c));
    ASSERT_TRUE(scheduler.completeCurrentFunction());  // move running bundle to function_b

    const std::string dump = scheduler.dumpToJsonString();
    ASSERT_FALSE(dump.empty());

    FunctionScheduler restored;
    registerDummyFactories(restored, {"function_a", "function_b", "function_c"});

    ASSERT_TRUE(restored.loadFromJsonString(dump));
    ASSERT_NE(restored.currentFunction(), nullptr);
    EXPECT_EQ(restored.currentFunction()->functionName(), "function_b");
    EXPECT_EQ(restored.waitingBundleNames(), std::vector<std::string>({"{function_c}"}));
}

TEST_F(FunctionSchedulerTest, PriorityEvent_Validation_BlockedByRule) {
    FunctionScheduler scheduler;
    scheduler.registerValidation(
        core::FunctionType::FOLLOW,
        [](core::FunctionType /*target*/, core::FunctionType current_function) -> TransitionValidationResult {
            if (current_function == core::FunctionType::WAKEUP) {
                return {false, "Wakeup blocking Follow"};
            }
            return {true, ""};
        });

    auto res1 = scheduler.validate(core::FunctionType::FOLLOW, core::FunctionType::IDLE);
    EXPECT_TRUE(res1.allowed);

    auto res2 = scheduler.validate(core::FunctionType::FOLLOW, core::FunctionType::WAKEUP);
    EXPECT_FALSE(res2.allowed);
    EXPECT_EQ(res2.reject_message, "Wakeup blocking Follow");
}

}  // namespace robot_control::applications::framework::test
