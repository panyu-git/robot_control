#!/bin/bash
set -e

echo "构建 TopSun 消息接口包..."
cd ~/ros2_ws

# 清理旧的构建
rm -rf build/mcu_data_interface install/mcu_data_interface

# 构建
if colcon build --packages-select mcu_data_interface; then
    echo "✓ 构建成功"
    
    # 测试
    source install/setup.bash
    echo "生成的接口:"
    ros2 interface package mcu_data_interface
    
    echo "测试单个接口:"
    if ros2 interface show mcu_data_interface/msg/TopSunImuTopic >/dev/null 2>&1; then
        echo "✓ TopSunImuTopic 接口可用"
    else
        echo "✗ TopSunImuTopic 接口不可用"
    fi
else
    echo "✗ 构建失败"
    exit 1
fi
