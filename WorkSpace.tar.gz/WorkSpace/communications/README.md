# communications

本仓库从 `type_src/` 中的消息/服务/动作定义生成 C++ 与 Python 代码，并在 **Jetson Orin 本机（aarch64）** 上构建共享库与安装产物。

## Orin 本机构建

在 Orin 设备上，依赖与 `msg_tool` 需已安装在 **segar-workspace** 中。默认前缀为 `/opt/robot_lab/segar-workspace`，可通过环境变量覆盖：

```bash
export SEGAR_WORKSPACE=/opt/robot_lab/segar-workspace   # 可选，与默认相同则可省略
```

编译与安装（推荐封装脚本）：

```bash
./scripts/deploy_orin.sh              # 等价于 ./scripts/build.sh orin-native
./scripts/deploy_orin.sh -r           # 先删除 build_native_orin/ 再全量配置与编译
./scripts/deploy_orin.sh -h           # 帮助（与 build.sh 一致）
```

无需用 **root** 执行本脚本：CMake 与编译在用户目录下的 `build_native_orin/` 进行；只有拷贝到 `/opt/robot_lab/communication` 时，若无权限才会由 `build.sh` 对该步骤使用 `sudo`。

构建目录：`build_native_orin/`，安装前缀：`build_native_orin/output/`（不会写入 `/usr/local`）。构建结束后会把 **`output/` 下的全部内容同步到 `/opt/robot_lab/communication`**（与 `output` 一致；目标目录里多出来的旧文件会被删除）。若无写权限会自动使用 `sudo`。若要改目标路径，可设置环境变量 `COMM_SYSTEM_ROOT`。

常见输出：

- `output/lib/`：`libcommunications.so*` 等
- `output/msg_libs/`：带版本号的实文件 `libcommunications.so.*.*.*`
- `output/include/`：各消息包生成的头文件
- `output/communication_idl/`：生成的 IDL 树
- `output/python/`：生成的 Python 代码
- `output/communication_version.txt`：版本、Git、平台信息与 `lib`/`bin` 的 MD5 列表

## 依赖

FastDDS/FastCDR、`msg_tool`、`usr_msg` 等由 segar-workspace 预装；CMake 使用 `THIRD_PARTY_PREFIX`（构建脚本里与 `SEGAR_WORKSPACE` 一致），本仓库不在配置阶段下载依赖。

## 链接本库

本仓库生成的安装产物会把 `lib/cmake/com_msg/com_msgConfig.cmake` 安装到安装前缀下。

在消费项目中可以这样使用：

```cmake
list(APPEND CMAKE_PREFIX_PATH "/opt/robot_lab/communication")
find_package(com_msg CONFIG REQUIRED)

add_executable(myapp src/main.cpp)
target_link_libraries(myapp PRIVATE com_msg::com_msg)
```

如果你的安装前缀不同，请把 `CMAKE_PREFIX_PATH` 改成实际根目录；也可显式设置 `com_msg_DIR` 为 `<安装根>/lib/cmake/com_msg`。

## 修改类型 `type_src/`

修改或新增类型定义后，在 Orin 上重新执行 `./scripts/deploy_orin.sh` 即可重新生成并编译安装。
