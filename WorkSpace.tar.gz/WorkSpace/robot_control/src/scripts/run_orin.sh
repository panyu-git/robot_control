#!/usr/bin/env bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJ_DIR="$(dirname "$SCRIPT_DIR")"

SEGAR_SDK_PATH="/opt/robot_lab/segar-workspace"
COM_MSG_PATH="/opt/robot_lab/communications"
THIRD_PARTY_PATH="/opt/robot_lab/third_party/lib"

export LD_LIBRARY_PATH="$PROJ_DIR/lib:$COM_MSG_PATH/lib:$SEGAR_SDK_PATH/lib:$THIRD_PARTY_PATH:$LD_LIBRARY_PATH"

export SEGAR_PATH="$PROJ_DIR/etc"
export SEGAR_GLOBAL_PATH="$SEGAR_SDK_PATH"
export ROBOT_CONTROL_CONFIG_DIR="$PROJ_DIR/etc"

export SEGAR_MSG_LIB_PATH="$COM_MSG_PATH/lib:$SEGAR_SDK_PATH/share/msg_libs"

LOG_DIR="$PROJ_DIR/.segar/log"
mkdir -p "$LOG_DIR"

export GLOG_log_dir="$LOG_DIR"
export GLOG_alsologtostderr=1
export GLOG_colorlogtostderr=1
export GLOG_minloglevel=0

echo "=== robot_control ==="
echo "PROJ_DIR:          $PROJ_DIR"
echo "SEGAR_SDK_PATH:    $SEGAR_SDK_PATH"
echo "COM_MSG_PATH:      $COM_MSG_PATH"
echo "SEGAR_PATH:        $SEGAR_PATH"
echo "SEGAR_GLOBAL_PATH: $SEGAR_GLOBAL_PATH"
echo "LOG_DIR:           $LOG_DIR"
echo "========================"

cd "$PROJ_DIR"
./bin/robot_control_node