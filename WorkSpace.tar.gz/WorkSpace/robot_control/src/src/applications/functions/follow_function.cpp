#include "robot_control/applications/functions/follow_function.hpp"

#include <algorithm>
#include <chrono>
#include <iomanip>
#include <map>
#include <memory>
#include <sstream>
#include <string>

#include "robot_control/core/enums.hpp"
#include "robot_control/core/events.hpp"
#include "robot_control/core/robot_control_configs.hpp"
#include "robot_control/services/navigation_service.hpp"
#include "robot_control/services/perception_service.hpp"
#include "robot_control/utils/logic_utils.hpp"

namespace robot_control {
namespace applications {
namespace functions {

FollowFunction::FollowFunction(std::shared_ptr<core::Blackboard> blackboard, const interfaces::RobotContext& context)
    : Function(blackboard),
      _context(context),
      _activationResultPublished(false),
      _lastHeartbeat(std::chrono::steady_clock::now()) {}

core::FunctionType FollowFunction::functionType() const {
    return core::FunctionType::FOLLOW;
}

core::FunctionPriority FollowFunction::priority() const {
    return core::FunctionPriority::NORMAL;
}

core::PreemptionType FollowFunction::preemptionType() const {
    return core::PreemptionType::SOFT;
}

void FollowFunction::onEnter(const std::optional<std::map<std::string, std::any>>& context) {
    _activationResultPublished = context.has_value();
    _lastRetryTime.reset();

    _blackboard->set(core::BlackboardKeys::CMD_STOP_REQUEST, false);
    _blackboard->set("follow_phase", core::FollowPhase::ACTIVATION);
    _blackboard->deleteKey("follow_start_time");
    _blackboard->set("nav_status", static_cast<int>(core::NavigationStatus::IDLE));
    _blackboard->set("face_authenticated", false);

    if (_context.navigation) _context.navigation->resetFollowState();

    if (context) {
        for (const auto& [k, v] : *context) {
            _blackboard->set(k, v);
        }
        auto nav_context =
            _blackboard->get<std::map<std::string, std::string>>("navigation", std::map<std::string, std::string>{});
        if (_context.navigation) _context.navigation->resumeFollow(nav_context);
    } else {
        // Handle parameters from RobotController dispatch
        std::string requested_user = _blackboard->get<std::string>(core::BlackboardKeys::FOLLOW_REQUEST_USER_ID, "");
        if (requested_user.empty()) {
            requested_user = "default_user";
        }

        std::string requested_task = _blackboard->get<std::string>(core::BlackboardKeys::FOLLOW_REQUEST_TASK, "");
        if (requested_task.empty()) {
            requested_task = "FOLLOW_TASK";
        }

        std::string remote_pose = _blackboard->get<std::string>(core::BlackboardKeys::FOLLOW_REQUEST_REMOTE_POSE, "");

        _blackboard->set("follow_requested_user_id", requested_user);
        _blackboard->set("follow_requested_task", requested_task);
        _blackboard->set("follow_remote_pose", remote_pose);
        _blackboard->set("follow_activation_mode", std::string("face_only"));

        // Initialize levels based on current params
        double follow_speed = _blackboard->get<double>(core::BlackboardKeys::TASK_FOLLOW_SPEED, 1.0);
        double follow_distance = _blackboard->get<double>(core::BlackboardKeys::TASK_FOLLOW_DISTANCE, 1.0);
        int speed_idx = utils::LogicUtils::NearestLevelIndex(follow_speed, core::FollowConfigs::kSpeedLevels);
        int distance_idx = utils::LogicUtils::NearestLevelIndex(follow_distance, core::FollowConfigs::kDistanceLevels);

        _blackboard->set(core::BlackboardKeys::TASK_FOLLOW_SPEED, core::FollowConfigs::kSpeedLevels[speed_idx]);
        _blackboard->set(core::BlackboardKeys::TASK_FOLLOW_DISTANCE,
                         core::FollowConfigs::kDistanceLevels[distance_idx]);
        _blackboard->set("follow_speed_level_index", speed_idx);
        _blackboard->set("follow_distance_level_index", distance_idx);
    }
}

std::optional<std::map<std::string, std::any>> FollowFunction::onExit() {
    if (_context.navigation) _context.navigation->stopFollow();
    _status = core::FunctionStatus::IDLE;
    _activationResultPublished = false;
    _lastRetryTime.reset();
    _blackboard->set("follow_phase", core::FollowPhase::IDLE);
    return std::nullopt;
}

std::optional<std::map<std::string, std::any>> FollowFunction::onPause() {
    _status = core::FunctionStatus::PAUSED;

    // Create context to save
    std::map<std::string, std::string> nav_context;
    if (_context.navigation) nav_context = _context.navigation->pauseFollow();

    std::map<std::string, std::any> context;
    context["navigation"] = nav_context;
    context["progress"] = _localBlackboard.get<std::map<std::string, std::any>>("engine_progress", {});
    context["paused_at"] = utils::LogicUtils::GetCurrentTimeSec();

    return context;
}

void FollowFunction::onResume(const std::map<std::string, std::any>& context) {
    _status = core::FunctionStatus::INITIALIZING;
    _activationResultPublished = true;
    _lastRetryTime.reset();
    _blackboard->set("follow_phase", core::FollowPhase::ACTIVATION);

    auto nav_context_it = context.find("navigation");
    if (nav_context_it != context.end()) {
        try {
            auto nav_context = std::any_cast<std::map<std::string, std::string>>(nav_context_it->second);
            if (_context.navigation) _context.navigation->resumeFollow(nav_context);
        } catch (...) {
            // Fallback to empty context
            if (_context.navigation) _context.navigation->resumeFollow({});
        }
    }
}

core::FunctionStatus FollowFunction::preTick() {
    // 1. Monitor user commands first.
    // This ensures that if a command (like 'start follow') is issued, the service status
    // is updated BEFORE we sync it to the blackboard in the next step.
    auto cmd_status = _checkUserCommands();

    // 2. Mirror service status to Blackboard (Decoupled Monitoring)
    if (_context.navigation) {
        _context.navigation->update();
        _blackboard->set("nav_status", static_cast<int>(_context.navigation->navigationStatus()));
        // Sync the last result success flag directly from service to blackboard
        _blackboard->set("nav_last_result_success", _context.navigation->isNavigationSuccessful());

        // Only use target_timeout from navigation service
        auto timeout = _context.navigation->getTargetTimeout();
        if (timeout.has_value()) {
            _blackboard->set<double>("target_lost_duration", timeout.value());
            if (timeout.value() > 0.1) {
                LOG_INFO_NAMED("FollowFunction",
                               "Updating target_lost_duration on blackboard: " << timeout.value() << "s");
            }
        } else {
            _blackboard->deleteKey("target_lost_duration");
        }
    }

    if (_context.perception) {
        _blackboard->set("face_authenticated", _context.perception->faceAuthenticated());
    }

    // 3. Monitor system health (server online & data flowing)
    if (_context.checkHealth(functionType(), _sessionStartTime) == core::FunctionStatus::FAILED) {
        _status = core::FunctionStatus::FAILED;
        return _status;
    }

    return cmd_status;
}

core::FunctionStatus FollowFunction::postTick() {
    // 1. Update status from engine result
    // This will move from INITIALIZING to RUNNING on first engine tick
    auto prev_status = _status;
    updateStatusFromEngine();

    // 2. Handle internal commands from BT nodes IMMEDIATELY after they are issued.
    _handleInternalCommands();

    // 3. Success/Failure Leak Prevention:
    // If engine returns SUCCESS or FAILURE but we are not in IDLE phase, stay RUNNING.
    auto phase = _blackboard->get<core::FollowPhase>("follow_phase", core::FollowPhase::IDLE);
    if ((_status == core::FunctionStatus::COMPLETED || _status == core::FunctionStatus::FAILED) &&
        phase != core::FollowPhase::IDLE && phase != core::FollowPhase::FAULT) {
        if (_status != prev_status) {
            static auto last_leak_log_time = std::chrono::steady_clock::now();
            auto now = std::chrono::steady_clock::now();
            if (std::chrono::duration<double>(now - last_leak_log_time).count() >= 1.0) {
                LOG_INFO_NAMED("FollowFunction", "Status leak prevented, engine returned "
                                                     << core::toString(_status) << " but phase is "
                                                     << core::toString(phase) << ". Staying RUNNING.");
                last_leak_log_time = now;
            }
        }
        _status = core::FunctionStatus::RUNNING;
    }

    if (_status == core::FunctionStatus::FAILED && prev_status != core::FunctionStatus::FAILED) {
        LOG_WARN_NAMED("FollowFunction", "FAILED due to engine_status (BT Failure)");
    }

    // 4. Handle FAULT phase from engine (Improvement C)
    if (phase == core::FollowPhase::FAULT) {
        LOG_WARN_NAMED("FollowFunction", "FAILED due to FAULT phase on blackboard");
        _status = core::FunctionStatus::FAILED;
    }

    // 5. Update activation result if needed
    auto engine_status_int = _localBlackboard.get<int>("engine_status", static_cast<int>(core::NodeStatus::IDLE));
    auto engine_status = static_cast<core::NodeStatus>(engine_status_int);
    _maybePublishActivationResult(engine_status);

    // 6. Publish heartbeat if running
    _publishHeartbeatIfNeeded();

    return _status;
}

void FollowFunction::_publishHeartbeatIfNeeded() {
    if (!utils::LogicUtils::IsTimeoutMs(_lastHeartbeat, core::FollowConfigs::kHeartbeatIntervalMs)) {
        return;
    }

    core::Event heartbeat_event(core::EventType::FOLLOW_HEARTBEAT, "FollowFunction");

    auto phase = _blackboard->get<core::FollowPhase>("follow_phase", core::FollowPhase::IDLE);
    int session_id = _getActivationSessionId();

    heartbeat_event.data["session_id"] = std::to_string(session_id);
    heartbeat_event.data["phase"] = core::toString(phase);
    heartbeat_event.data["target_user_id"] = _blackboard->get<std::string>("follow_target_user_id", "");
    heartbeat_event.data["navigation_status"] =
        std::to_string(static_cast<int>(_blackboard->get<int>("nav_status", 0)));
    heartbeat_event.data["reason"] = _blackboard->get<std::string>("follow_activation_fail_reason", "");

    if (_context.navigation) {
        auto feedback = _context.navigation->getFeedback();
        heartbeat_event.data["task_state"] = feedback.count("task_state") ? feedback.at("task_state") : "";
        heartbeat_event.data["task_message"] = feedback.count("task_message") ? feedback.at("task_message") : "";

        auto pose = _context.navigation->currentPose();
        heartbeat_event.data["current_pose"] = _formatPosition(std::get<0>(pose), std::get<1>(pose), std::get<2>(pose));
    }

    core::EventBus::getInstance().publish(heartbeat_event);
    _lastHeartbeat = std::chrono::steady_clock::now();
}

core::FunctionStatus FollowFunction::_checkUserCommands() {
    if (_blackboard->get<bool>(core::BlackboardKeys::CMD_STOP_REQUEST, false)) {
        LOG_INFO_NAMED("FollowFunction", "COMPLETED due to cmd_stop_request on blackboard");
        _blackboard->set(core::BlackboardKeys::CMD_STOP_REQUEST, false);
        _blackboard->set("follow_phase", core::FollowPhase::IDLE);
        int session_id = _getActivationSessionId();

        core::Event feedback_event(core::EventType::FEEDBACK_FOLLOW_EXEC_EXIT, "FollowFunction");
        feedback_event.data["message"] = "停止跟随成功";
        feedback_event.data["session_id"] = std::to_string(session_id);
        core::EventBus::getInstance().publish(feedback_event);

        core::Event interaction_event(core::EventType::HMI_INTERACTION_REQUEST, "FollowFunction");
        interaction_event.data["message"] = "提醒用户停止跟随";
        interaction_event.data["session_id"] = std::to_string(session_id);
        core::EventBus::getInstance().publish(interaction_event);

        _status = core::FunctionStatus::COMPLETED;
    }

    if (_blackboard->get<bool>(core::BlackboardKeys::CMD_FOLLOW_SPEED_UP, false)) {
        _blackboard->set(core::BlackboardKeys::CMD_FOLLOW_SPEED_UP, false);
        _handleSpeedChange(1);
    }
    if (_blackboard->get<bool>(core::BlackboardKeys::CMD_FOLLOW_SPEED_DOWN, false)) {
        _blackboard->set(core::BlackboardKeys::CMD_FOLLOW_SPEED_DOWN, false);
        _handleSpeedChange(-1);
    }
    if (_blackboard->get<bool>(core::BlackboardKeys::CMD_FOLLOW_DISTANCE_NEAR, false)) {
        _blackboard->set(core::BlackboardKeys::CMD_FOLLOW_DISTANCE_NEAR, false);
        _handleDistanceChange(-1);
    }
    if (_blackboard->get<bool>(core::BlackboardKeys::CMD_FOLLOW_DISTANCE_FAR, false)) {
        _blackboard->set(core::BlackboardKeys::CMD_FOLLOW_DISTANCE_FAR, false);
        _handleDistanceChange(1);
    }

    std::string loc_request = _blackboard->get<std::string>(core::BlackboardKeys::CMD_FOLLOW_LOCATION_REQUEST, "");
    if (!loc_request.empty()) {
        _handleLocationChange(loc_request);
        _blackboard->set(core::BlackboardKeys::CMD_FOLLOW_LOCATION_REQUEST, std::string(""));
    }

    return _status;
}

void FollowFunction::_handleSpeedChange(int direction) {
    double current_speed = _blackboard->get<double>(core::BlackboardKeys::TASK_FOLLOW_SPEED, 1.0);
    int speed_idx =
        _blackboard->get<int>("follow_speed_level_index",
                              utils::LogicUtils::NearestLevelIndex(current_speed, core::FollowConfigs::kSpeedLevels));

    int new_idx = std::clamp(speed_idx + direction, 0, static_cast<int>(core::FollowConfigs::kSpeedLevels.size()) - 1);
    int session_id = _getActivationSessionId();

    if (new_idx == speed_idx) {
        std::string msg = (direction > 0) ? "提醒用户当前已是最高跟随速度" : "提醒用户当前已是最低跟随速度";
        core::Event interaction_event(core::EventType::HMI_INTERACTION_REQUEST, "FollowFunction");
        interaction_event.data["message"] = msg;
        interaction_event.data["session_id"] = std::to_string(session_id);
        core::EventBus::getInstance().publish(interaction_event);
        return;
    }

    double new_speed = core::FollowConfigs::kSpeedLevels[new_idx];
    _blackboard->set(core::BlackboardKeys::TASK_FOLLOW_SPEED, new_speed);
    _blackboard->set("follow_speed_level_index", new_idx);

    std::string hmi_msg;
    if (_status == core::FunctionStatus::RUNNING && _context.navigation) {
        _context.navigation->updateFollowParams(std::nullopt, new_speed);
        hmi_msg = (direction > 0) ? "提醒用户已加快跟随速度" : "提醒用户已降低跟随速度";
    } else {
        hmi_msg = "提醒用户已调整默认跟随速度";
    }

    core::Event interaction_event(core::EventType::HMI_INTERACTION_REQUEST, "FollowFunction");
    interaction_event.data["message"] = hmi_msg;
    interaction_event.data["session_id"] = std::to_string(session_id);
    core::EventBus::getInstance().publish(interaction_event);
}

void FollowFunction::_handleDistanceChange(int direction) {
    double current_distance = _blackboard->get<double>(core::BlackboardKeys::TASK_FOLLOW_DISTANCE, 1.0);
    int distance_idx = _blackboard->get<int>(
        "follow_distance_level_index",
        utils::LogicUtils::NearestLevelIndex(current_distance, core::FollowConfigs::kDistanceLevels));

    int new_idx =
        std::clamp(distance_idx + direction, 0, static_cast<int>(core::FollowConfigs::kDistanceLevels.size()) - 1);
    int session_id = _getActivationSessionId();

    if (new_idx == distance_idx) {
        std::string msg = (direction > 0) ? "提醒用户当前已是最远跟随距离" : "提醒用户当前已是最近跟随距离";
        core::Event interaction_event(core::EventType::HMI_INTERACTION_REQUEST, "FollowFunction");
        interaction_event.data["message"] = msg;
        interaction_event.data["session_id"] = std::to_string(session_id);
        core::EventBus::getInstance().publish(interaction_event);
        return;
    }

    double new_distance = core::FollowConfigs::kDistanceLevels[new_idx];
    _blackboard->set(core::BlackboardKeys::TASK_FOLLOW_DISTANCE, new_distance);
    _blackboard->set("follow_distance_level_index", new_idx);

    if (_status == core::FunctionStatus::RUNNING && _context.navigation) {
        std::string hmi_msg;
        if (_context.navigation->updateFollowParams(new_distance, std::nullopt)) {
            hmi_msg = (direction > 0) ? "提醒用户已调整为更远跟随" : "提醒用户已调整为更近跟随";
        } else {
            hmi_msg = "提醒用户跟随距离调整失败";
        }
        core::Event interaction_event(core::EventType::HMI_INTERACTION_REQUEST, "FollowFunction");
        interaction_event.data["message"] = hmi_msg;
        interaction_event.data["session_id"] = std::to_string(session_id);
        core::EventBus::getInstance().publish(interaction_event);
    }
}

void FollowFunction::_handleLocationChange(const std::string& location_raw) {
    std::string location = location_raw;
    std::transform(location.begin(), location.end(), location.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });

    int session_id = _getActivationSessionId();
    if (location != "left" && location != "right" && location != "back") {
        core::Event interaction_event(core::EventType::HMI_INTERACTION_REQUEST, "FollowFunction");
        interaction_event.data["message"] = "提醒用户仅支持左侧、右侧或后方跟随";
        interaction_event.data["session_id"] = std::to_string(session_id);
        core::EventBus::getInstance().publish(interaction_event);
        return;
    }

    _blackboard->set(core::BlackboardKeys::TASK_FOLLOW_MODE, location);

    if (_status == core::FunctionStatus::RUNNING && _context.navigation) {
        std::string hmi_msg;
        if (_context.navigation->updateFollowPosition(location)) {
            hmi_msg = "提醒用户已调整跟随方位";
        } else {
            hmi_msg = "提醒用户跟随方位调整失败";
        }
        core::Event interaction_event(core::EventType::HMI_INTERACTION_REQUEST, "FollowFunction");
        interaction_event.data["message"] = hmi_msg;
        interaction_event.data["session_id"] = std::to_string(session_id);
        core::EventBus::getInstance().publish(interaction_event);
    }
}

void FollowFunction::_maybePublishActivationResult(core::NodeStatus bt_status) {
    if (_activationResultPublished) return;

    int session_id = _getActivationSessionId();
    bool face_ok = _context.perception && _context.perception->faceAuthenticated();

    if (face_ok) {
        // 1. Internal result event
        core::Event event(core::EventType::FOLLOW_ACTIVATE_RESULT, "FollowFunction");
        event.data["result"] = "success";
        event.data["session_id"] = std::to_string(session_id);
        event.data["user_id"] = _blackboard->get<std::string>("follow_target_user_id", "");
        core::EventBus::getInstance().publish(event);

        // 2. HMI & Feedback
        core::Event interaction_event(core::EventType::HMI_INTERACTION_REQUEST, "FollowFunction");
        interaction_event.data["message"] = "提醒用户启动跟随成功，开始执行跟随";
        interaction_event.data["session_id"] = std::to_string(session_id);
        core::EventBus::getInstance().publish(interaction_event);

        core::Event feedback_event(core::EventType::FEEDBACK_FOLLOW_START_SUCCEED, "FollowFunction");
        feedback_event.data["message"] = "启动跟随成功";
        feedback_event.data["session_id"] = std::to_string(session_id);
        core::EventBus::getInstance().publish(feedback_event);

        _activationResultPublished = true;
    } else if (bt_status == core::NodeStatus::FAILURE) {
        std::string bb_reason = _blackboard->get<std::string>("follow_activation_fail_reason", "");
        core::FollowFailReason reason =
            bb_reason.empty()
                ? mapStatusToReason(
                      bt_status,
                      _context.navigation ? _context.navigation->navigationStatus() : core::NavigationStatus::IDLE,
                      _context.navigation ? _context.navigation->isNavServerOnline() : false,
                      _context.navigation ? _context.navigation->isReady() : false)
                : stringToReason(bb_reason);

        std::string hmi_msg = getHmiMessage(reason);

        // 1. Internal result event
        core::Event event(core::EventType::FOLLOW_ACTIVATE_RESULT, "FollowFunction");
        event.data["result"] = "fail";
        event.data["reason"] = reasonToString(reason);
        event.data["session_id"] = std::to_string(session_id);
        event.data["user_id"] = _blackboard->get<std::string>("follow_target_user_id", "");
        core::EventBus::getInstance().publish(event);

        // 2. HMI & Feedback
        core::Event interaction_event(core::EventType::HMI_INTERACTION_REQUEST, "FollowFunction");
        interaction_event.data["message"] = hmi_msg;
        interaction_event.data["session_id"] = std::to_string(session_id);
        core::EventBus::getInstance().publish(interaction_event);

        core::EventType feedback_type =
            (reason == core::FollowFailReason::NAV_UNAVAILABLE || reason == core::FollowFailReason::BT_LOAD_FAILED)
                ? core::EventType::FEEDBACK_FOLLOW_START_FAIL_NEED_CHECK
                : core::EventType::FEEDBACK_FOLLOW_START_FAIL_UNKNOWN;

        core::Event feedback_event(feedback_type, "FollowFunction");
        feedback_event.data["message"] = hmi_msg;
        feedback_event.data["session_id"] = std::to_string(session_id);
        core::EventBus::getInstance().publish(feedback_event);

        _activationResultPublished = true;
    }
}

std::string FollowFunction::_formatPosition(double x, double y, double z) {
    std::stringstream ss;
    ss << std::fixed << std::setprecision(2) << "(" << x << ", " << y << ", " << z << ")";
    return ss.str();
}

int FollowFunction::_getActivationSessionId() const {
    return _blackboard->get<int>("follow_activation_session_id", 0);
}

core::FollowFailReason FollowFunction::mapStatusToReason(core::NodeStatus bt_status, core::NavigationStatus nav_status,
                                                         bool nav_online, bool nav_ready) {
    if (bt_status != core::NodeStatus::FAILURE) {
        return core::FollowFailReason::NONE;
    }

    if (nav_status == core::NavigationStatus::FAILED || !nav_online) {
        return core::FollowFailReason::NAV_UNAVAILABLE;
    }

    if (!nav_ready) {
        return core::FollowFailReason::PERCEPTION_UNAVAILABLE;
    }

    return core::FollowFailReason::UNKNOWN;
}

std::string FollowFunction::getHmiMessage(core::FollowFailReason reason) {
    switch (reason) {
        case core::FollowFailReason::NAV_UNAVAILABLE:
            return "导航不可用，无法开启跟随";
        case core::FollowFailReason::PERCEPTION_UNAVAILABLE:
            return "感知服务不可用";
        case core::FollowFailReason::FACE_RECOG_TIMEOUT:
            return "人脸识别超时，退出跟随";
        case core::FollowFailReason::NO_FACE_DETECTED:
            return "提醒用户面向机器狗摄像头进行人脸识别";
        case core::FollowFailReason::BT_LOAD_FAILED:
            return "跟随行为树加载失败";
        case core::FollowFailReason::LOST_TIMEOUT:
            return "目标丢失超过一分钟，退出跟随";
        case core::FollowFailReason::RETRY_EXHAUSTED:
            return "跟随尝试多次失败，退出";
        default:
            return "跟随启动失败";
    }
}

core::FollowFailReason FollowFunction::stringToReason(const std::string& reason_str) {
    if (reason_str == "nav_unavailable") return core::FollowFailReason::NAV_UNAVAILABLE;
    if (reason_str == "perception_unavailable") return core::FollowFailReason::PERCEPTION_UNAVAILABLE;
    if (reason_str == "activation_timeout") return core::FollowFailReason::FACE_RECOG_TIMEOUT;
    if (reason_str == "no_face") return core::FollowFailReason::NO_FACE_DETECTED;
    if (reason_str == "face_id_missing" || reason_str == "voice_user_missing")
        return core::FollowFailReason::INVALID_USER;
    if (reason_str == "face_not_found") return core::FollowFailReason::WITHOUT_USER;
    if (reason_str == "bt_load_failed") return core::FollowFailReason::BT_LOAD_FAILED;
    return core::FollowFailReason::UNKNOWN;
}

std::string FollowFunction::reasonToString(core::FollowFailReason reason) {
    switch (reason) {
        case core::FollowFailReason::NAV_UNAVAILABLE:
            return "nav_unavailable";
        case core::FollowFailReason::PERCEPTION_UNAVAILABLE:
            return "perception_unavailable";
        case core::FollowFailReason::FACE_RECOG_TIMEOUT:
            return "activation_timeout";
        case core::FollowFailReason::NO_FACE_DETECTED:
            return "no_face";
        case core::FollowFailReason::INVALID_USER:
            return "invalid_user";
        case core::FollowFailReason::BT_LOAD_FAILED:
            return "bt_load_failed";
        default:
            return "unknown";
    }
}

void FollowFunction::_handleInternalCommands() {
    if (_blackboard->get<bool>("follow_cleanup_requested", false)) {
        _blackboard->set("follow_cleanup_requested", false);
        if (_context.navigation) _context.navigation->stopFollow();
        if (_context.perception) _context.perception->stopTracking();
    }

    std::string perception_cmd = _blackboard->get<std::string>("perception_cmd", "");
    if (!perception_cmd.empty()) {
        _blackboard->set("perception_cmd", std::string(""));
        if (perception_cmd == "start_activation_tracking" && _context.perception) {
            std::string target_user = _blackboard->get<std::string>("perception_target_user", "default_user");
            _context.perception->startActivationTracking(target_user);
        } else if (perception_cmd == "stop_tracking" && _context.perception) {
            _context.perception->stopTracking();
        }
    }

    std::string navigation_cmd = _blackboard->get<std::string>("navigation_cmd", "");
    if (!navigation_cmd.empty()) {
        _blackboard->set("navigation_cmd", std::string(""));
        if (navigation_cmd == "stop" && _context.navigation) {
            _context.navigation->stopFollow();
        } else if (navigation_cmd == "start_follow" && _context.navigation) {
            std::string mode = _blackboard->get<std::string>("navigation_follow_mode", "human");
            double distance = _blackboard->get<double>("navigation_follow_distance", 1.0);
            double speed = _blackboard->get<double>("navigation_follow_speed", 1.0);
            std::string user_id = _blackboard->get<std::string>("navigation_target_user", "");
            _context.navigation->startFollow(mode, distance, speed, user_id);
        }
    }
}

}  // namespace functions
}  // namespace applications
}  // namespace robot_control
