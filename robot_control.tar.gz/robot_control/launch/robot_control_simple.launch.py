"""
Robot Control System Simple Launch File (C++ Version)
机器人控制系统简化启动文件 (C++ 版本)

Usage:
    ros2 launch robot_control robot_control_simple.launch.py
    ros2 launch robot_control robot_control_simple.launch.py simulated:=false
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    # Declare launch arguments (声明启动参数)
    simulated_arg = DeclareLaunchArgument(
        'simulated',
        default_value='false',
        description='Whether to run in simulated mode (是否运行在仿真模式)'
    )
    skip_follow_activation_in_simulated_arg = DeclareLaunchArgument(
        'skip_follow_activation_in_simulated',
        default_value='true',
        description='Skip face activation when simulated=true'
    )

    start_nav_task_server_arg = DeclareLaunchArgument(
        'start_nav_task_server',
        default_value='true',
        description='Whether to start nav_task_request action server'
    )

    # Main robot controller node (主控制器节点)
    # C++ version integrates all services in one node
    robot_controller_node = Node(
        package='robot_control',
        executable='robot_control_node',
        name='robot_controller',
        output='screen',
        emulate_tty=True,
        parameters=[{
            'simulated': LaunchConfiguration('simulated'),
            'skip_follow_activation_in_simulated': LaunchConfiguration('skip_follow_activation_in_simulated'),
            'tick_rate': 20.0,
        }]
    )

    return LaunchDescription([
        # Launch arguments
        simulated_arg,
        skip_follow_activation_in_simulated_arg,

        # Main node
        robot_controller_node,
    ])
